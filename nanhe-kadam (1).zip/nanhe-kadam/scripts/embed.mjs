import {readFileSync,writeFileSync} from 'node:fs';
import {transform} from 'esbuild';
const files=['frontend/index.html','frontend/login.html','frontend/portal.html','frontend/style.css','frontend/public.js','frontend/login.js','frontend/portal.js','public/hero.jpg'];
const result={};for(const p of files){let text=readFileSync(p).toString(p.endsWith('.jpg')?'base64':'utf8');if(p.endsWith('.js'))text=(await transform(text,{minify:true,legalComments:'none',sourcemap:false,target:'es2022'})).code;result[p]=text}
writeFileSync('backend/src/assets.ts',`export const assets = ${JSON.stringify(result)} as const;\n`);
