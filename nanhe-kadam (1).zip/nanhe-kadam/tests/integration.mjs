import assert from 'node:assert/strict';
const base=process.env.TEST_BASE||'http://127.0.0.1:8787';
async function call(path,method='GET',body,auth,csrfOverride){let headers={};if(body!==undefined){headers['content-type']='application/json';headers.origin=base}if(auth?.cookie)headers.cookie=auth.cookie;if(csrfOverride!==undefined)headers['x-csrf-token']=csrfOverride;else if(auth?.csrf)headers['x-csrf-token']=auth.csrf;const r=await fetch(base+path,{method,headers,body:body===undefined?undefined:JSON.stringify(body),redirect:'manual'});let data;try{data=await r.json()}catch{data=null}return {status:r.status,data,cookie:r.headers.get('set-cookie')?.split(';')[0],headers:r.headers};}
const ok=async(path,method='GET',body,auth)=>{const r=await call(path,method,body,auth);assert.ok(r.status<300,`${path}: ${r.status} ${JSON.stringify(r.data)}`);return r};
async function anon(){let c=await ok('/api/csrf');return {cookie:c.cookie,csrf:c.data.csrf}}
async function login(username,password){const a=await anon();const r=await ok('/api/login','POST',{username,password},a);const auth={cookie:r.cookie};const m=await ok('/api/portal/me','GET',undefined,auth);auth.csrf=m.data.csrf;return auth}
assert.equal((await ok('/api/health')).data.ok,true);assert.equal((await ok('/api/public')).data.classes.length,6);
assert.equal((await call('/portal/dashboard')).status,302);assert.equal((await call('/portal.js')).status,401);assert.equal((await call('/api/admin/private')).status,401);assert.equal((await call('/api/admin/private','POST',{})).status,401);
const home=await (await fetch(base+'/public.js')).text();assert.ok(!home.includes('/api/portal/users'));assert.ok(!home.includes('teacher-form'));assert.ok(!home.includes('/api/portal/dashboard'));
assert.equal((await call('/api/login','POST',{username:'Rakesh@1',password:'rakesh@7632'})).status,403);
assert.equal((await call('/api/enquiries','POST',{parent_name:'P',child_name:'C',phone:'9559104341'})).status,403);
await ok('/api/enquiries','POST',{parent_name:'P',child_name:'C',phone:'9559104341'},await anon());
const admin=await login('Rakesh@1','rakesh@7632');
assert.equal((await ok('/api/portal/me','GET',undefined,admin)).data.user.must_change_password,1);
assert.equal((await call('/api/portal/dashboard','GET',undefined,admin)).status,403);
await ok('/api/portal/password','POST',{current_password:'rakesh@7632',password:'AdminPassword123!'},admin);
assert.equal((await call('/api/portal/settings','PUT',{school_name:'Oops'},{cookie:admin.cookie})).status,403);
await ok('/api/portal/users','POST',{role:'co_admin',username:'coadmin',password:'CoAdminPassword123!'},admin);
await ok('/api/portal/users','POST',{role:'teacher',username:'Teacher1',password:'TeacherPassword123!',name:'Test teacher'},admin);
const co=await login('coadmin','CoAdminPassword123!');const teacher=await login('Teacher1','TeacherPassword123!');
const dash=(await ok('/api/portal/dashboard','GET',undefined,admin)).data;const t=dash.teachers[0];const coid=dash.users[0].id;
assert.equal((await call('/api/portal/users/'+coid,'DELETE',{},co)).status,403);assert.equal((await call('/api/portal/users','POST',{role:'co_admin',username:'other',password:'AnotherPassword123!'},co)).status,403);
assert.equal((await call('/api/portal/salaries','POST',{teacher_id:t.id,amount:10,period:'2026-11'},teacher)).status,403);
assert.equal((await call('/api/portal/content/notices','POST',{title:'Update',body:'Hello',date:'2026-11-23',class_id:1},teacher)).status,403);
await ok('/api/portal/assignments','POST',{teacher_id:t.id,class_id:1},co);await ok('/api/portal/content/notices','POST',{title:'Assigned update',body:'Hello',date:'2026-11-23',class_id:1},teacher);await ok('/api/portal/salaries','POST',{teacher_id:t.id,amount:25000,period:'2026-11'},co);await ok('/api/portal/attendance','POST',{teacher_id:t.id,date:'2026-11-23',status:'present'},co);
const media=await ok('/api/portal/media','POST',{data:'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jRZkAAAAASUVORK5CYII='},teacher);await ok('/api/portal/content/gallery','POST',{section_id:1,title:'Test image',media_id:media.data.id,class_id:1},teacher);
assert.equal((await ok('/api/portal/dashboard','GET',undefined,admin)).data.total,25000);assert.equal((await ok('/api/search?q=Assigned')).data.notices.length,1);
await ok('/api/portal/users/'+t.user_id,'DELETE',{},co);assert.equal((await call('/api/portal/me','GET',undefined,teacher)).status,401);assert.equal((await fetch(base+'/api/media/'+media.data.id)).status,404);
const after=(await ok('/api/portal/dashboard','GET',undefined,admin)).data;assert.equal(after.total,0);assert.equal(after.teachers.length,0);assert.equal(after.assignments.length,0);assert.equal(after.attendance.length,0);assert.equal(after.salaries.length,0);assert.equal((await ok('/api/public')).data.gallery.length,0);
console.log('Integration passed: protected assets, CSRF, forced password change, RBAC and cascade.');
