# DATABASE GUIDE: NANHE KADAM PUBLIC SCHOOL

## Schema Overview
- `school_settings`: Identity, Opening Date (11 Nov 2026), Principal/Director (Placeholders).
- `theme_settings`: Colors, Mode, Font, Buttons (D1-backed theme layer).
- `homepage_sections`: Hero, Welcome, Principal, Director, Classes, Activities, Events, Notices, Gallery, Testimonials, Contact, Footer (JSON).
- `administrators`, `roles`, `permissions`, `admin_sessions`: RBAC & Auth.
- `media_assets`: R2 references (Alt, Caption, Dimensions, Size, Mime).
- `gallery_albums`, `gallery_images`: Gallery management.
- `classes`, `teachers`: School content.
- `notices`, `events`: Announcements.
- `admission_enquiries`: Form submissions.
- `map_settings`: Location, Marker, Zoom, Dimensions, Theme, Embed URL.
- `activity_logs`: Audit trail.

## Migrations
- `001_initial_schema.sql`: Initial tables and placeholder data.

## Bootstrap
- `bootstrap_admin.sql`: Initial Super Admin and Settings.

## Relationships
- `administrators.role_id` -> `roles.id`
- `admin_sessions.admin_id` -> `administrators.id`
- `gallery_images.album_id` -> `gallery_albums.id`
- `gallery_images.media_asset_id` -> `media_assets.id`
- `teachers.photo_asset_id` -> `media_assets.id`

## Integrity
- Foreign keys, indexes, constraints.
- Transactions for content/theme/map updates.
- Archival logic (Excluded for Student/Fee, but schema ready for future expansion).

## Backup & Restore
- **Export:** `wrangler d1 dump nanhe_kadam_db > backup.sql`
- **Restore:** `wrangler d1 execute nanhe_kadam_db < backup.sql`
- **R2:** Manual download or script (R2 API).

---
*Status: Database Guide Ready.*
