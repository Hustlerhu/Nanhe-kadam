# PHASE 4: ADMIN PANEL (MOBILE-FIRST)

## Scope
- Dashboard (Statistics).
- Live Theme Customizer (Primary, Secondary, Accent, Background, Card, Text, Heading, Button, Border, Footer, Link, Mode, Font).
- Homepage & Section Builder (Hero, Welcome, Principal, Director, Classes, Activities, Events, Notices, Gallery, Testimonials, Contact, Footer).
- Logo/Media Manager (Upload/Replace/Delete/Preview, R2).
- Map Editor (Leaflet.js, Search, Marker, Zoom, Dimensions, Theme, Embed URL, Instant Preview).
- Notices, Events, Gallery, Classes, Teachers, Admissions (CRUD).
- Roles & Activity Logs.
- Draft -> Preview -> Save -> Publish (Cache Purge).

## 2. Mobile-First Layout (320px-430px)
- Sidebar (Hamburger) / Bottom Nav (Thumb-friendly).
- Cards for each module (depth-card utility).
- Live Preview (Iframe or Side-by-Side on Desktop).

## 3. Implementation Details
- React/Next.js Admin App (protected by `/api/admin/login`).
- Server-side Auth (HttpOnly Cookies).
- RBAC enforcement on every API call.
- Instant Map Preview (Leaflet.js updates on input change).
- Theme Customizer (Live CSS Variable injection).

---
*Status: Phase 4 Specification Ready. Implementation in progress.*
