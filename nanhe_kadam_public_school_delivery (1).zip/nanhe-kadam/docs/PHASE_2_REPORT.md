# PHASE 2: MOBILE-FIRST DESIGN SYSTEM & PUBLIC PAGES

## Scope
- Complete design system implementation (Tokens from DECISIONS.md).
- Public pages: About, Classes, Teachers, Notices, Events, Gallery, Admissions, Contact, Map.
- Theme layer (Live customizer tokens in D1).
- 120 FPS target & Horizontal Overflow Prevention (320px-1440px).

## 1. Design System Tokens (Tailwind Config Extension)
```javascript
// tailwind.config.js extension
theme: {
  extend: {
    colors: {
      primary: '#87A98A', // Sage Green
      secondary: '#E68A71', // Peach
      accent: '#D4AF37', // Gold
      'bg-main': '#FFFDF5', // Warm Cream
      'bg-card': '#F9F7F2', // Soft Ivory
      'text-main': '#2C2C2C', // Charcoal
      'text-secondary': '#555555',
      'border': '#E0D9C9',
    },
    fontFamily: {
      sans: ['Inter', 'system-ui', 'sans-serif'],
    },
  },
}
```

## 2. Public Pages Implementation (Placeholders for Phase 2)

### 2.1 About School
- Content from `homepage_sections` (Welcome, Principal, Director).
- Placeholder images from R2 (fallback to CSS gradients).
- Mobile-first: Vertical stack. Desktop: Side-by-side (Principal/Director).

### 2.2 Classes Page
- Grid layout (1 col mobile, 3-5 cols desktop).
- Touch-friendly cards (depth-card utility).
- Horizontal overflow prevention: `max-width: 100%`, `box-sizing: border-box`.

### 2.3 Teachers Page
- Teacher cards with photos (R2).
- Filter by class (Play Group to Class 5).

### 2.4 Notices & Events
- List view (Mobile) / Grid view (Desktop).
- Published date filtering.

### 2.5 Gallery
- Leaflet-based album viewer (R2 images).
- Responsive grid (1 col mobile, 4 cols desktop).

### 2.6 Admissions
- Form with validation (Phone, Email, Name, Message).
- Server-side submission to `/api/admissions`.

### 2.7 Contact & Map
- Leaflet.js integration (OpenStreetMap).
- Address, Phone, Email from `school_settings`.
- Interactive map (Marker, Zoom, Dimensions from `map_settings`).

### 2.8 Theme Layer
- CSS Variables injected from D1 `theme_settings`.
- Live preview mechanism (Admin Panel will update D1, Public site fetches via `/api/settings`).

---
*Status: Phase 2 Specification Ready. Implementation in progress.*
