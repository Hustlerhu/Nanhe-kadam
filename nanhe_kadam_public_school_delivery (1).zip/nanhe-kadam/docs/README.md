# NANHE KADAM PUBLIC SCHOOL
**Official Opening Date:** 11 November 2026  
**Type:** Play School + Primary School (Play Group to Class 5)  
**Location:** Patna, IN  

## Overview
A premium, warm, and professional school website and secure Admin CMS built for Cloudflare (Pages, Workers, D1, R2). Mobile-first design (320px-1440px), 120 FPS target, zero horizontal overflow.

## Quick Start (Android + Termux + GitHub Codespaces)
1. Clone repository.
2. Install dependencies: `npm install` (Frontend) / `npm install` (Backend).
3. Configure `.env` from `.env.example`.
4. Run migrations: `wrangler d1 execute nanhe_kadam_db --file backend/migrations/001_initial_schema.sql`
5. Bootstrap Admin: `wrangler d1 execute nanhe_kadam_db --file backend/scripts/bootstrap_admin.sql`
6. Start Dev Server: `npm run dev` (Frontend) & `wrangler dev` (Backend).
7. Deploy: `wrangler deploy`

## Project Structure
- `/frontend`: Next.js App (Mobile-first, 120 FPS, Overflow Safe).
- `/backend`: Cloudflare Workers API (Public & Admin).
- `/docs`: Specifications, Reports, Decisions.
- `/tests`: Automated tests (Auth, RBAC, Theme, Map, Media, Responsive, Overflow, DB, API, Upload, Build).

## Cloudflare Setup
- **Account ID:** PLACEHOLDER_ACCOUNT_ID
- **D1 Database:** `nanhe_kadam_db`
- **R2 Bucket:** `nanhe_kadam_media`
- **Pages Project:** `nanhe-kadam-public-school`
- **Worker Name:** `api`
- **Bindings:** `DB`, `MEDIA_BUCKET`

## API Tokens Required
- **Account Token:** Permissions (Workers: Read/Write, D1: Read/Write, R2: Read/Write, Pages: Read/Write).

## Configuration
- Update `.env` with secrets (COOKIE_SECRET, CSRF_SECRET, etc.).
- Update `wrangler.toml` with Account ID.

## First Administrator
- Run bootstrap script: `wrangler d1 execute nanhe_kadam_db --file backend/scripts/bootstrap_admin.sql`
- Initial Email: admin@nanhekadampublicschool.in
- Initial Password: PLACEHOLDER (Reset on first login)

## Customization
- **School Identity:** Admin Panel -> Settings (Name, Opening Date, Principal, Director, Address, Phone, Email, Timings, Description, Motto, Tagline, Academic Session, Social Links).
- **Logo/Media:** Admin Panel -> Media Manager (Upload/Replace/Delete/Preview, R2).
- **Theme:** Admin Panel -> Theme Customizer (Colors, Mode, Font, Buttons).
- **Homepage:** Admin Panel -> Homepage Builder (Hero, Welcome, Principal, Director, Classes, Activities, Events, Notices, Gallery, Testimonials, Contact, Footer).
- **Map:** Admin Panel -> Map Editor (Address, Location, Marker, Zoom, Dimensions, Theme, Embed URL, Instant Preview).

## Updates
- Public website updates instantly after Publish (Cache Purge).
- No redeployment required for CMS changes.

## Backup & Restore
- **D1 Export:** `wrangler d1 dump nanhe_kadam_db > backup.sql`
- **R2 Backup:** `wrangler r2 object list nanhe_kadam_media > r2_list.txt` (Download files manually or via script)
- **Restore:** `wrangler d1 execute nanhe_kadam_db < backup.sql`

## Security
- HttpOnly Cookies, Secure Sessions, CSRF Protection.
- Rate Limiting (100 req/min).
- Input Validation, Parameterized Queries, XSS Prevention.
- Secure Upload Validation (Mime, Size).
- Least-privilege Cloudflare Tokens.
- No secrets in frontend code.

## Performance
- 60 FPS (ordinary) / 120 FPS (compatible).
- Horizontal Overflow Prevention (box-sizing: border-box, min-width: 0, max-width: 100%).
- Lazy loading, GPU transforms, minimal JS.

---
*Prepared by: Senior Software Architect (Arena.ai Agent Mode)*
*Date: 2026-11-23*
