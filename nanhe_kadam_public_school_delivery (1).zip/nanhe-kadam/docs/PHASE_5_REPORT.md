# PHASE 5: TESTS & QUALITY ASSURANCE

## Scope
- Authentication & Authorization (RBAC).
- Theme/Logo/Identity Replacement (Instant update).
- Map Publish (Instant update).
- Media Lifecycle (Upload/Delete/Sync).
- Responsive Width & Horizontal Overflow (320px, 360px, 375px, 390px, 393px, 412px, 430px, 680px, 768px, 1024px, 1440px).
- Database Integrity (Foreign keys, constraints, transactions).
- API Security (CSRF, Rate Limiting, Input Validation).
- File Upload Security (R2 validation).
- Production Build & Cloudflare Bindings.

## 1. Automated Test Suite (Playwright/Vitest)
- `test/auth.spec.ts`: Verify login, session, RBAC.
- `test/theme.spec.ts`: Verify color/identity replacement updates public site.
- `test/map.spec.ts`: Verify map publish updates public site.
- `test/media.spec.ts`: Verify upload/delete syncs D1/R2.
- `test/responsive.spec.ts`: Verify document width <= viewport width at all breakpoints.
- `test/overflow.spec.ts`: Verify no horizontal scroll on vertical movement.
- `test/db.spec.ts`: Verify foreign keys, transactions.
- `test/api.spec.ts`: Verify CSRF, rate limiting, input validation.
- `test/upload.spec.ts`: Verify R2 validation (mime, size).
- `test/build.spec.ts`: Verify Wrangler build & Cloudflare bindings.

## 2. Horizontal Overflow Test Logic
```typescript
// test/responsive.spec.ts
test('no horizontal overflow at all breakpoints', async ({ page }) => {
  const breakpoints = [320, 360, 375, 390, 393, 412, 430, 680, 768, 1024, 1440];
  for (const width of breakpoints) {
    await page.setViewportSize({ width, height: 800 });
    const scrollWidth = await page.evaluate(() => document.documentElement.scrollWidth);
    const clientWidth = await page.evaluate(() => document.documentElement.clientWidth);
    expect(scrollWidth).toBeLessThanOrEqual(clientWidth);
  }
});
```

## 3. Data Integrity Test Logic
- Verify Student/Fee exclusion (not implemented, but schema check).
- Verify Archival logic (if added later).
- Verify Foreign Key constraints in D1.

---
*Status: Phase 5 Specification Ready. Implementation in progress.*
