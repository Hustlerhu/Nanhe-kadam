# PHASE 3: WORKERS API (PUBLIC & ADMIN)

## Scope
- Public GET endpoints (already scaffolded in Phase 1).
- Authenticated Admin endpoints (POST/PUT/DELETE).
- Server-side Auth (HttpOnly Cookies, Secure Sessions, Argon2).
- RBAC (Super, Principal, Director, Staff).
- Draft -> Preview -> Save -> Publish workflow.
- Cache Invalidation (Cloudflare Purge).

## 1. Authentication Middleware
```typescript
// backend/src/middleware/auth.ts
import { Hono } from 'hono';
import { jwt } from 'hono/jwt';

const auth = new Hono();

auth.use('*', async (c, next) => {
  const cookie = c.req.cookie('session_id');
  if (!cookie) return c.json({ error: 'Unauthorized' }, 401);
  
  const session = await c.env.DB.prepare(
    'SELECT * FROM admin_sessions WHERE id = ? AND expiry_at > datetime("now")'
  ).bind(cookie).first();
  
  if (!session) return c.json({ error: 'Session expired' }, 401);
  
  const admin = await c.env.DB.prepare(
    'SELECT * FROM administrators WHERE id = ? AND is_active = 1'
  ).bind(session.admin_id).first();
  
  if (!admin) return c.json({ error: 'Admin not found' }, 401);
  
  c.set('admin', admin);
  await next();
});

export default auth;
```

## 2. Admin API Endpoints (Scaffold)

### 2.1 Settings (Identity, Theme, Opening Date)
- `PUT /api/admin/settings`: Update `school_settings`, `theme_settings`.
- `POST /api/admin/publish`: Draft -> Publish (Cache Purge).

### 2.2 Homepage Builder
- `PUT /api/admin/homepage/:section_key`: Update `homepage_sections`.

### 2.3 Media Manager (R2)
- `POST /api/admin/media/upload`: Upload to R2, insert into `media_assets`.
- `DELETE /api/admin/media/:id`: Delete from R2 and `media_assets`.

### 2.4 Map Editor
- `PUT /api/admin/map`: Update `map_settings`.

### 2.5 Content Management
- `POST /api/admin/classes`, `PUT /api/admin/classes/:id`, `DELETE /api/admin/classes/:id`
- `POST /api/admin/teachers`, `PUT /api/admin/teachers/:id`, `DELETE /api/admin/teachers/:id`
- `POST /api/admin/notices`, `PUT /api/admin/notices/:id`, `DELETE /api/admin/notices/:id`
- `POST /api/admin/events`, `PUT /api/admin/events/:id`, `DELETE /api/admin/events/:id`
- `POST /api/admin/gallery`, `PUT /api/admin/gallery/:id`, `DELETE /api/admin/gallery/:id`
- `POST /api/admin/enquiries`, `PUT /api/admin/enquiries/:id`, `DELETE /api/admin/enquiries/:id`

### 2.6 RBAC Checks
- Super Admin: All.
- Principal Admin: Content, Identity, Media.
- Director Admin: Identity, Theme, Map, Media.
- Staff Admin: Content, Media.

---
*Status: Phase 3 Specification Ready. Implementation in progress.*
