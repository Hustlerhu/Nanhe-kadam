# BACKUP & RESTORE GUIDE: NANHE KADAM PUBLIC SCHOOL

## Database (D1)
### Export
```bash
wrangler d1 dump nanhe_kadam_db > backup.sql
```
### Restore
```bash
wrangler d1 execute nanhe_kadam_db < backup.sql
```

## Media (R2)
### Export (List)
```bash
wrangler r2 object list nanhe_kadam_media > r2_list.txt
```
### Download (Manual or Script)
- Use Cloudflare Dashboard or R2 API to download objects.
### Restore
- Upload objects back to R2 bucket `nanhe_kadam_media`.
- Update `media_assets` table in D1 with new R2 keys.

## Frequency Recommendations
- **Daily:** Automated D1 export (via Worker cron).
- **Weekly:** R2 asset backup (Manual or Script).
- **Monthly:** Full verification (Restore to test environment).

## Recovery Procedure
1. Restore D1 from `backup.sql`.
2. Restore R2 assets to bucket.
3. Update `.env` with new secrets if needed.
4. Redeploy Workers/Pages if code changed.
5. Verify Public Site and Admin Panel.

---
*Status: Backup & Restore Guide Ready.*
