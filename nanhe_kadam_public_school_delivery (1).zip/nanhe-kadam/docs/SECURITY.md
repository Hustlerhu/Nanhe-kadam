# SECURITY GUIDE: NANHE KADAM PUBLIC SCHOOL

## Security Principles
1. Server-side Auth & Authorization only.
2. HttpOnly Cookies & Secure Sessions.
3. CSRF Protection (Token-based).
4. Rate Limiting (100 req/min per IP).
5. Input Validation & Parameterized Queries (D1).
6. XSS Prevention (Output encoding).
7. Secure Upload Validation (Mime, Size, R2).
8. Least-privilege Cloudflare Tokens.
9. Secret Management (Environment Variables).
10. Audit Logs (Activity Logs in D1).

## Risks & Mitigations
1. **Horizontal Overflow:** `box-sizing: border-box`, `min-width: 0`, `max-width: 100%`, automated tests (320px-1440px).
2. **Performance Degradation:** CSS transforms, lazy loading, minimal JS, WebGL fallback.
3. **Data Loss:** D1 export, R2 asset backup, Database restoration instructions.
4. **Cloudflare Limits:** Optimize queries, compress images, use caching.
5. **Unauthorized Access:** Server-side RBAC, HttpOnly Cookies, Secure Sessions.
6. **Injection/XSS:** Parameterized queries, output encoding.
7. **File Upload:** Mime/Size validation, R2 isolation.

## Secrets Management
- Never hardcode secrets in frontend code.
- Use Environment Variables (`.env`).
- Use Cloudflare Secrets Store for production.

## Audit Logs
- All Admin actions logged in `activity_logs` table (D1).
- IP address, timestamp, action, details.

---
*Status: Security Guide Ready.*
