# DEPLOYMENT GUIDE: NANHE KADAM PUBLIC SCHOOL

## Prerequisites
- Cloudflare Account (Free Tier sufficient).
- Wrangler CLI installed (`npm install -g wrangler`).
- Node.js 18+ (for Next.js Frontend).

## Step 1: Cloudflare Setup
1. Create Cloudflare Pages Project: `nanhe-kadam-public-school`.
2. Create D1 Database: `nanhe_kadam_db`.
3. Create R2 Bucket: `nanhe_kadam_media`.
4. Create Worker: `api`.
5. Bind D1 and R2 to Worker.
6. Get Account ID, API Token, D1 ID, R2 Access Key/Secret.

## Step 2: Environment Configuration
1. Copy `.env.example` to `.env`.
2. Fill in secrets:
   - `CLOUDFLARE_ACCOUNT_ID`
   - `CLOUDFLARE_API_TOKEN`
   - `D1_DATABASE_ID`
   - `R2_BUCKET_NAME` (nanhe_kadam_media)
   - `R2_ACCESS_KEY_ID`
   - `R2_SECRET_ACCESS_KEY`
   - `R2_ACCOUNT_ID`
   - `COOKIE_SECRET` (32 chars)
   - `CSRF_SECRET` (32 chars)
   - `BASE_URL` (https://nanhe-kadam.pages.dev)

## Step 3: Database Migration & Bootstrap
1. Run migration:
   ```bash
   wrangler d1 execute nanhe_kadam_db --file backend/migrations/001_initial_schema.sql
   ```
2. Run bootstrap:
   ```bash
   wrangler d1 execute nanhe_kadam_db --file backend/scripts/bootstrap_admin.sql
   ```

## Step 4: Development
1. Start Frontend: `cd frontend && npm run dev`
2. Start Backend: `cd backend && wrangler dev`
3. Access: `http://localhost:3000`

## Step 5: Deployment
1. Build Frontend: `cd frontend && npm run build`
2. Deploy to Cloudflare Pages: `wrangler pages publish ./frontend/out`
3. Deploy Workers: `wrangler deploy`

## Step 6: First Administrator Login
1. Email: admin@nanhekadampublicschool.in
2. Password: PLACEHOLDER (Reset on first login via Admin Panel)
3. URL: `https://nanhe-kadam.pages.dev/admin`

---
*Status: Deployment Guide Ready.*
