import { classes } from '@/lib/data'; // Placeholder for API fetch

export default function ClassesSection({ classes }) {
  // Mobile-First: 1 per row (320px-430px)
  // Desktop: Grid (1024px-1440px)
  return (
    <section className="py-12 px-4 overflow-safe bg-[var(--bg-main)]">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-2xl md:text-4xl font-bold text-[var(--text-main)] mb-8 text-center overflow-safe">
          Our Classes
        </h2>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6 overflow-safe">
          {classes?.map((cls) => (
            <div key={cls.id} className="depth-card p-6 overflow-safe gpu-transform">
              <h3 className="text-[var(--primary)] font-bold text-lg mb-2 overflow-safe">
                {cls.name || 'Play Group'}
              </h3>
              <p className="text-[var(--text-secondary)] text-sm overflow-safe">
                {cls.description || 'Professional education tailored for young minds.'}
              </p>
              <button className="mt-4 text-[var(--accent)] font-medium hover:underline overflow-safe">
                View Details
              </button>
            </div>
          ))}
          
          {/* Placeholder if empty (Phase 1 scaffold) */}
          {(!classes || classes.length === 0) && (
            [
              'Play Group', 'Nursery', 'LKG', 'UKG', 'Class 1', 'Class 2', 'Class 3', 'Class 4', 'Class 5'
            ].map((name, i) => (
              <div key={i} className="depth-card p-6 overflow-safe gpu-transform">
                <h3 className="text-[var(--primary)] font-bold text-lg mb-2 overflow-safe">{name}</h3>
                <p className="text-[var(--text-secondary)] text-sm overflow-safe">Placeholder description for {name}.</p>
                <button className="mt-4 text-[var(--accent)] font-medium hover:underline overflow-safe">View Details</button>
              </div>
            ))
          )}
        </div>
      </div>
    </section>
  );
}
