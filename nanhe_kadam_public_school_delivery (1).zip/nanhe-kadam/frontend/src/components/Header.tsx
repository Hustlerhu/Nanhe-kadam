import Link from 'next/link';

// NEW: Inline Social Icons (SVG Assets from /home/user/nanhe-kadam/frontend/src/assets/social_icons.svg)
const SocialIcon = ({ type, onClick, href, label }) => {
  const icons = {
    whatsapp: '/assets/social_icons.svg#icon-whatsapp',
    instagram: '/assets/social_icons.svg#icon-instagram',
    youtube: '/assets/social_icons.svg#icon-youtube',
    facebook: '/assets/social_icons.svg#icon-facebook'
  };
  return (
    <a 
      href={href || '#'} 
      onClick={onClick}
      className="inline-block w-8 h-8 overflow-safe gpu-transform transition-transform duration-200 hover:scale-110"
      aria-label={label}
      title={label}
    >
      <svg className="w-full h-full">
        <use href={icons[type]} />
      </svg>
    </a>
  );
};

export default function Header({ schoolName, onWhatsAppClick }) {
  // Admin-backed settings (Placeholder for Phase 3/4 integration)
  // In production, these come from /api/settings
  const socialLinks = {
    whatsapp: '', // Phone number from D1 school_settings
    instagram: '#',
    youtube: '#',
    facebook: '#'
  };

  return (
    <header className="sticky top-0 z-50 bg-[var(--bg-main)] border-b border-[var(--border)] shadow-[0_2px_8px_var(--shadow)] overflow-safe">
      <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
        {/* Mobile Hamburger (Placeholder for Phase 2 implementation) */}
        <button className="p-2 text-[var(--text-main)] md:hidden overflow-safe" aria-label="Menu">
          ☰
        </button>

        {/* Logo & Name (Placeholder Logo) */}
        <Link href="/" className="flex items-center gap-2 font-bold text-xl text-[var(--text-main)] overflow-safe">
          <div className="w-8 h-8 bg-[var(--primary)] rounded-full gpu-transform depth-card" />
          <span className="truncate overflow-safe">{schoolName}</span>
        </Link>

        {/* Top Info Bar Social Icons (NEW) */}
        <div className="hidden md:flex gap-2 items-center overflow-safe">
          <SocialIcon type="whatsapp" onClick={(e) => onWhatsAppClick && onWhatsAppClick(e)} href={socialLinks.whatsapp ? `https://wa.me/${socialLinks.whatsapp}` : '#'} label="WhatsApp" />
          <SocialIcon type="instagram" href={socialLinks.instagram} label="Instagram" />
          <SocialIcon type="youtube" href={socialLinks.youtube} label="YouTube" />
          <SocialIcon type="facebook" href={socialLinks.facebook} label="Facebook" />
        </div>

        {/* Desktop Nav (Placeholder) */}
        <nav className="hidden md:flex gap-6 text-[var(--text-main)] font-medium overflow-safe">
          <Link href="/" className="hover:text-[var(--primary)] transition">Home</Link>
          <Link href="/about" className="hover:text-[var(--primary)] transition">About</Link>
          <Link href="/classes" className="hover:text-[var(--primary)] transition">Classes</Link>
          <Link href="/admissions" className="hover:text-[var(--primary)] transition">Admissions</Link>
        </nav>

        {/* Admission Button */}
        <Link href="/admissions" className="bg-[var(--primary)] text-white px-4 py-2 rounded-lg font-medium hover:bg-[var(--secondary)] transition gpu-transform overflow-safe">
          Admission Open
        </Link>

        {/* Mobile WhatsApp Toggle Button */}
        <button 
          onClick={(e) => onWhatsAppClick && onWhatsAppClick(e)}
          className="md:hidden p-2 bg-[var(--primary)] text-white rounded-full gpu-transform depth-card overflow-safe"
          aria-label="WhatsApp Enquiry"
        >
          <svg className="w-6 h-6" viewBox="0 0 100 100"><use href="/assets/social_icons.svg#icon-whatsapp" /></svg>
        </button>
      </div>
    </header>
  );
}
