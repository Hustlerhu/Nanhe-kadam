import Image from 'next/image';

export default function Hero({ content, settings }) {
  const heroData = content ? JSON.parse(content) : {
    heading: "Welcome to Nanhe Kadam Public School",
    description: "Established 11 November 2026 | Play Group to Class 5",
    button_text: "Admission Open"
  };

  const schoolName = settings?.school_name || 'Nanhe Kadam Public School';
  const openingDate = settings?.opening_date || '2026-11-11';

  return (
    <section className="relative overflow-safe bg-[var(--bg-main)] py-12 md:py-24 px-4">
      <div className="max-w-5xl mx-auto text-center">
        {/* 3D Depth Card (Contained) */}
        <div className="depth-card p-8 md:p-12 rounded-2xl bg-[var(--bg-card)] border border-[var(--border)] gpu-transform relative overflow-safe">
          {/* Subtle 3D Illustration Placeholder (CSS-based) */}
          <div className="absolute -top-4 -right-4 w-32 h-32 bg-[var(--primary)]/10 rounded-full blur-3xl gpu-transform" />
          
          <h1 className="text-3xl md:text-5xl font-bold text-[var(--text-main)] mb-4 overflow-safe">
            {heroData.heading}
          </h1>
          <p className="text-[var(--text-secondary)] text-lg md:text-xl mb-8 overflow-safe">
            {heroData.description} <br/>
            <span className="font-semibold text-[var(--accent)]">Established {openingDate}</span>
          </p>
          
          <Link href="/admissions" className="inline-block bg-[var(--primary)] text-white px-8 py-3 rounded-full font-bold hover:bg-[var(--secondary)] transition gpu-transform shadow-[0_4px_12px_var(--shadow)]">
            {heroData.button_text}
          </Link>
        </div>
      </div>
      
      {/* Placeholder School Image (R2 Fallback) */}
      <div className="absolute inset-0 z-0 pointer-events-none overflow-hidden">
        <div className="absolute inset-0 bg-[var(--primary)]/5 mix-blend-multiply" />
        {/* Image component will use R2 URL from settings in Phase 2 */}
        <div className="w-full h-full bg-cover bg-center opacity-20" style={{ backgroundImage: 'url(/placeholder-school.jpg)' }} />
      </div>
    </section>
  );
}
