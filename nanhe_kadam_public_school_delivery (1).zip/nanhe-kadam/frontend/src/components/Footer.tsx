import Link from 'next/link';

// NEW: Inline Social Icons (SVG Assets from /home/user/nanhe-kadam/frontend/src/assets/social_icons.svg)
const SocialIcon = ({ type, onClick, href, label }) => {
  const icons = {
    whatsapp: '/assets/social_icons.svg#icon-whatsapp',
    instagram: '/assets/social_icons.svg#icon-instagram',
    youtube: '/assets/social_icons.svg#icon-youtube',
    facebook: '/assets/social_icons.svg#icon-facebook'
  };
  return (
    <a 
      href={href || '#'} 
      onClick={onClick}
      className="inline-block w-8 h-8 overflow-safe gpu-transform transition-transform duration-200 hover:scale-110"
      aria-label={label}
      title={label}
    >
      <svg className="w-full h-full">
        <use href={icons[type]} />
      </svg>
    </a>
  );
};

export default function Footer({ schoolName, openingDate }) {
  const currentYear = new Date().getFullYear();
  
  // Admin-backed settings (Placeholder for Phase 3/4 integration)
  const socialLinks = {
    whatsapp: '', // Phone number from D1 school_settings
    instagram: '#',
    youtube: '#',
    facebook: '#'
  };

  return (
    <footer className="bg-[var(--bg-card)] border-t border-[var(--border)] py-8 px-4 text-center text-[var(--text-secondary)] text-sm overflow-safe">
      <div className="max-w-7xl mx-auto">
        <p className="mb-2 overflow-safe">
          <strong>{schoolName}</strong> | Established {openingDate}
        </p>
        <p className="overflow-safe">
          Play School + Primary School (Play Group to Class 5) | Patna, IN
        </p>
        
        {/* NEW: Follow Us Section */}
        <div className="mt-6 flex justify-center gap-4 overflow-safe">
          <span className="text-[var(--text-secondary)] overflow-safe">Follow Us:</span>
          <SocialIcon type="whatsapp" href={socialLinks.whatsapp ? `https://wa.me/${socialLinks.whatsapp}` : '#'} label="WhatsApp" />
          <SocialIcon type="instagram" href={socialLinks.instagram} label="Instagram" />
          <SocialIcon type="youtube" href={socialLinks.youtube} label="YouTube" />
          <SocialIcon type="facebook" href={socialLinks.facebook} label="Facebook" />
        </div>

        <p className="mt-4 overflow-safe">
          &copy; {currentYear} {schoolName}. All rights reserved.
        </p>
      </div>
    </footer>
  );
}
