import Head from 'next/head';
import Header from '../components/Header';
import Hero from '../components/Hero';
import ClassesSection from '../components/ClassesSection';
import Footer from '../components/Footer';
import { useEffect, useState } from 'react';

// NEW: Social Toggle Component Logic (Inline for Phase 2 update)
const SocialToggle = ({ schoolName, settings }) => {
  const [isOpen, setIsOpen] = useState(false);
  const whatsappNumber = settings?.phone || ''; // From D1 school_settings
  const whatsappMessage = encodeURIComponent(`Hello ${schoolName}, I want to enquire about admission...`);
  const whatsappUrl = whatsappNumber ? `https://wa.me/${whatsappNumber}?text=${whatsappMessage}` : '';

  const handleToggle = (e) => {
    e.preventDefault();
    const el = document.getElementById('whatsapp-toggle-content');
    if (el) {
      const open = el.style.transform === 'translate3d(0, 0, 0)';
      // Ultra-Smooth Top-to-Bottom Toggle Animation (60-120 FPS)
      // GPU-accelerated: transform: translate3d, opacity
      el.style.transition = 'transform 0.15s cubic-bezier(0.25, 0.8, 0.25, 1), opacity 0.15s ease';
      el.style.transform = open ? 'translate3d(0, -100%, 0)' : 'translate3d(0, 0, 0)';
      el.style.opacity = open ? '0' : '1';
      setIsOpen(!open);
      
      // Valid Link Behavior (Admin Panel Configured)
      if (whatsappUrl && !open) {
        setTimeout(() => window.open(whatsappUrl, '_blank'), 150);
      }
    }
  };

  return (
    <div id="whatsapp-toggle-content" className="fixed top-0 left-0 w-full h-screen bg-[var(--bg-main)]/95 z-[100] overflow-safe pointer-events-none transition-transform duration-150 ease-out transform -translate-y-full opacity-0" style={{ willChange: 'transform, opacity' }}>
      <div className="pointer-events-auto absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 p-6 bg-[var(--bg-card)] border border-[var(--border)] rounded-2xl shadow-[0_12px_32px_var(--shadow)] depth-card gpu-transform overflow-safe">
        <h3 className="text-[var(--text-main)] font-bold mb-2 overflow-safe">WhatsApp Enquiry</h3>
        <p className="text-[var(--text-secondary)] text-sm mb-4 overflow-safe">
          {whatsappNumber ? `Opening chat with ${schoolName}...` : 'Configure WhatsApp number in Admin Panel.'}
        </p>
        {whatsappUrl && (
          <a href={whatsappUrl} target="_blank" rel="noopener noreferrer" className="block bg-[var(--primary)] text-white text-center py-2 rounded-lg font-medium hover:bg-[var(--secondary)] transition gpu-transform overflow-safe">
            Open WhatsApp
          </a>
        )}
        <button onClick={() => setIsOpen(false)} className="mt-4 text-[var(--text-secondary)] text-xs hover:text-[var(--text-main)] overflow-safe">
          Close
        </button>
      </div>
    </div>
  );
};

export default function Home({ settings, homepageSections, classes }) {
  const [theme, setTheme] = useState('system');

  useEffect(() => {
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    if (theme === 'system' && prefersDark) {
      document.documentElement.classList.add('dark');
    } else if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    }
  }, [theme]);

  const schoolName = settings?.school_name || 'Nanhe Kadam Public School';
  const openingDate = settings?.opening_date || '2026-11-11';

  return (
    <div className="overflow-safe min-h-screen flex flex-col">
      <Head>
        <title>{schoolName} | Established {openingDate}</title>
        <meta name="description" content="Nanhe Kadam Public School - Play Group to Class 5. Premium, warm, and professional education." />
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <Header schoolName={schoolName} onWhatsAppClick={handleToggle} />

      <main className="flex-grow overflow-safe">
        <Hero content={homepageSections.find(s => s.section_key === 'hero')?.content} settings={settings} />
        <ClassesSection classes={classes} />
      </main>

      <Footer schoolName={schoolName} openingDate={openingDate} />
    </div>
  );
}

export async function fetchSettings() {
  const res = await fetch(`${process.env.BASE_URL || 'http://localhost:3000'}/api/settings`);
  return res.json();
}

export async function fetchHomepage() {
  const res = await fetch(`${process.env.BASE_URL || 'http://localhost:3000'}/api/homepage`);
  return res.json();
}

export async function fetchClasses() {
  const res = await fetch(`${process.env.BASE_URL || 'http://localhost:3000'}/api/classes`);
  return res.json();
}

export default async function Page() {
  const [settings, homepageSections, classes] = await Promise.all([
    fetchSettings(),
    fetchHomepage(),
    fetchClasses()
  ]);

  return <Home settings={settings} homepageSections={homepageSections} classes={classes} />;
}
