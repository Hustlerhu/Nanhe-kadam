-- Nanhe Kadam Public School D1 Migrations
-- Phase 1: Initial Schema
-- Phase 2 Update: Social Media Links & Dynamic Settings

-- 1. School Settings (Identity & Opening Date)
CREATE TABLE IF NOT EXISTS school_settings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    school_name TEXT NOT NULL DEFAULT 'Nanhe Kadam Public School',
    opening_date TEXT NOT NULL DEFAULT '2026-11-11',
    principal_name TEXT NOT NULL DEFAULT 'Amita Kumari',
    director_name TEXT NOT NULL DEFAULT 'R. K. Jha',
    logo_url TEXT,
    favicon_url TEXT,
    address TEXT,
    phone TEXT, -- Used for WhatsApp Dynamic Link
    email TEXT,
    timings TEXT,
    description TEXT,
    motto TEXT,
    tagline TEXT,
    academic_session TEXT,
    social_links TEXT, -- JSON: {"instagram": "", "youtube": "", "facebook": ""}
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 2. Theme Settings
CREATE TABLE IF NOT EXISTS theme_settings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    primary_color TEXT DEFAULT '#87A98A', -- Sage Green
    secondary_color TEXT DEFAULT '#E68A71', -- Peach
    accent_color TEXT DEFAULT '#D4AF37', -- Gold
    background_color TEXT DEFAULT '#FFFDF5', -- Ivory
    card_background TEXT DEFAULT '#F9F7F2',
    text_color TEXT DEFAULT '#2C2C2C', -- Charcoal
    heading_color TEXT DEFAULT '#2C2C2C',
    button_color TEXT DEFAULT '#87A98A',
    button_text_color TEXT DEFAULT '#FFFDF5',
    border_color TEXT DEFAULT '#E0D9C9',
    footer_color TEXT DEFAULT '#2C2C2C',
    link_color TEXT DEFAULT '#87A98A',
    theme_mode TEXT DEFAULT 'system', -- light, dark, system
    font_family TEXT DEFAULT 'Inter, system-ui, sans-serif',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 3. Homepage Sections (JSON storage for flexibility)
CREATE TABLE IF NOT EXISTS homepage_sections (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    section_key TEXT UNIQUE NOT NULL, -- hero, welcome, principal, director, classes, activities, events, notices, gallery, testimonials, contact, footer
    content TEXT, -- JSON
    is_enabled BOOLEAN DEFAULT 1,
    display_order INTEGER DEFAULT 0,
    background_color TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 4. Administrators & Roles
CREATE TABLE IF NOT EXISTS roles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL, -- Super Admin, Principal Admin, Director Admin, Staff Admin
    permissions TEXT -- JSON
);

CREATE TABLE IF NOT EXISTS administrators (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    role_id INTEGER,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    name TEXT,
    is_active BOOLEAN DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (role_id) REFERENCES roles(id)
);

-- 5. Admin Sessions
CREATE TABLE IF NOT EXISTS admin_sessions (
    id TEXT PRIMARY KEY,
    admin_id INTEGER,
    expiry_at DATETIME,
    ip_address TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (admin_id) REFERENCES administrators(id)
);

-- 6. Media Assets (R2 References)
CREATE TABLE IF NOT EXISTS media_assets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    r2_key TEXT UNIQUE NOT NULL,
    alt_text TEXT,
    caption TEXT,
    dimensions TEXT, -- e.g., "1920x1080"
    file_size INTEGER,
    mime_type TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 7. Gallery
CREATE TABLE IF NOT EXISTS gallery_albums (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS gallery_images (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    album_id INTEGER,
    media_asset_id INTEGER,
    display_order INTEGER DEFAULT 0,
    FOREIGN KEY (album_id) REFERENCES gallery_albums(id),
    FOREIGN KEY (media_asset_id) REFERENCES media_assets(id)
);

-- 8. Content Tables
CREATE TABLE IF NOT EXISTS classes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL, -- Play Group, Nursery, etc.
    description TEXT,
    teacher_name TEXT,
    display_order INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS teachers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    designation TEXT,
    bio TEXT,
    photo_asset_id INTEGER,
    FOREIGN KEY (photo_asset_id) REFERENCES media_assets(id)
);

CREATE TABLE IF NOT EXISTS notices (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    content TEXT,
    publish_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    is_published BOOLEAN DEFAULT 1
);

CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    content TEXT,
    event_date DATETIME,
    location TEXT,
    is_published BOOLEAN DEFAULT 1
);

-- 9. Admissions
CREATE TABLE IF NOT EXISTS admission_enquiries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    phone TEXT NOT NULL,
    email TEXT,
    message TEXT,
    status TEXT DEFAULT 'pending', -- pending, contacted, enrolled, rejected
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 10. Map Settings
CREATE TABLE IF NOT EXISTS map_settings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    address TEXT,
    latitude REAL,
    longitude REAL,
    marker_icon_url TEXT,
    zoom_level INTEGER DEFAULT 15,
    dimensions TEXT DEFAULT '100%x400px',
    theme TEXT DEFAULT 'light',
    embed_url TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 11. Activity Logs
CREATE TABLE IF NOT EXISTS activity_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    admin_id INTEGER,
    action TEXT NOT NULL,
    details TEXT,
    ip_address TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (admin_id) REFERENCES administrators(id)
);

-- Initial Data Insertion
INSERT OR IGNORE INTO roles (id, name, permissions) VALUES 
(1, 'Super Admin', '{"all": true}'),
(2, 'Principal Admin', '{"content": true, "identity": true, "media": true}'),
(3, 'Director Admin', '{"identity": true, "theme": true, "map": true, "media": true}'),
(4, 'Staff Admin', '{"content": true, "media": true}');

-- Initial School Settings
INSERT OR IGNORE INTO school_settings (id, school_name, opening_date, principal_name, director_name) VALUES 
(1, 'Nanhe Kadam Public School', '2026-11-11', 'Amita Kumari', 'R. K. Jha');

-- Initial Theme Settings
INSERT OR IGNORE INTO theme_settings (id) VALUES (1);

-- Initial Map Settings
INSERT OR IGNORE INTO map_settings (id) VALUES (1);

-- Initial Homepage Sections (Placeholders)
INSERT OR IGNORE INTO homepage_sections (section_key, content, display_order) VALUES 
('hero', '{"heading": "Welcome to Nanhe Kadam Public School", "description": "Established 11 November 2026 | Play Group to Class 5", "button_text": "Admission Open"}', 1),
('welcome', '{"text": "Warm, natural, premium education for every child."}', 2),
('principal', '{"name": "Amita Kumari", "designation": "Principal", "bio": "Placeholder"}', 3),
('director', '{"name": "R. K. Jha", "designation": "Director", "bio": "Placeholder"}', 4),
('classes', '{"description": "Play Group to Class 5"}', 5),
('activities', '{"description": "Learning through play"}', 6),
('events', '{"description": "Upcoming school events"}', 7),
('notices', '{"description": "Latest announcements"}', 8),
('gallery', '{"description": "School life"}', 9),
('testimonials', '{"description": "What parents say"}', 10),
('contact', '{"description": "Get in touch"}', 11),
('footer', '{"copyright": "© 2026 Nanhe Kadam Public School"}', 12);
