-- Bootstrap Script for Nanhe Kadam Public School
-- Run via Wrangler D1 execute after migration

-- 1. Create Initial Super Admin
-- Password hash placeholder (Argon2/Bcrypt)
INSERT OR IGNORE INTO administrators (id, role_id, email, password_hash, name, is_active)
VALUES (1, 1, 'admin@nanhekadampublicschool.in', '$2b$12$PLACEHOLDER_HASH_FOR_INITIAL_PASSWORD', 'Super Admin', 1);

-- 2. Create Initial Admin Session (Optional, for first login)
-- INSERT INTO admin_sessions ...

-- 3. Log Bootstrap Action
INSERT INTO activity_logs (admin_id, action, details)
VALUES (1, 'SYSTEM_BOOTSTRAP', 'Initial database schema and settings created on 2026-11-23');

SELECT 'Bootstrap completed successfully' AS status;
