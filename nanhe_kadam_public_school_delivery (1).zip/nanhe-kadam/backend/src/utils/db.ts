import { createClient } from '@supabase/supabase-js'; // Placeholder for D1 client logic or use native fetch
// In Cloudflare Workers, we use native fetch to D1 binding.

export const getSchoolSettings = async (env: Env) => {
  const res = await env.DB.prepare(
    'SELECT * FROM school_settings LIMIT 1'
  ).first();
  return res;
};

export const getThemeSettings = async (env: Env) => {
  const res = await env.DB.prepare(
    'SELECT * FROM theme_settings LIMIT 1'
  ).first();
  return res;
};

export const getMapSettings = async (env: Env) => {
  const res = await env.DB.prepare(
    'SELECT * FROM map_settings LIMIT 1'
  ).first();
  return res;
};

// Media helper: Get R2 URL
export const getMediaUrl = (env: Env, r2Key: string) => {
  // In production, use R2 signed URL or public URL
  return `${env.BASE_URL}/media/${r2Key}`;
};
