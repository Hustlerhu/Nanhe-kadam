import { Hono } from 'hono';
import { D1Database } from '@cloudflare/workers-types';
import { cors } from 'hono/cors';
import { jwt } from 'hono/jwt';

const app = new Hono();

// Bindings (will be injected by Wrangler)
declare global {
  interface Bindings {
    DB: D1Database;
    MEDIA_BUCKET: R2Bucket;
    COOKIE_SECRET: string;
    CSRF_SECRET: string;
    BASE_URL: string;
  }
}

// Middleware
app.use('*', cors());

// --- PUBLIC API (GET) ---

// 1. Settings (Identity & Opening Date)
app.get('/api/settings', async (c) => {
  const res = await c.env.DB.prepare(
    'SELECT * FROM school_settings, theme_settings, map_settings LIMIT 1'
  ).first();
  return c.json(res);
});

// 2. Homepage Sections
app.get('/api/homepage', async (c) => {
  const res = await c.env.DB.prepare(
    'SELECT * FROM homepage_sections ORDER BY display_order ASC'
  ).all();
  return c.json(res.results);
});

// 3. Classes
app.get('/api/classes', async (c) => {
  const res = await c.env.DB.prepare(
    'SELECT * FROM classes ORDER BY display_order ASC'
  ).all();
  return c.json(res.results);
});

// 4. Teachers
app.get('/api/teachers', async (c) => {
  const res = await c.env.DB.prepare(
    'SELECT t.*, m.r2_key as photo_url FROM teachers t LEFT JOIN media_assets m ON t.photo_asset_id = m.id'
  ).all();
  return c.json(res.results);
});

// 5. Notices
app.get('/api/notices', async (c) => {
  const res = await c.env.DB.prepare(
    'SELECT * FROM notices WHERE is_published = 1 ORDER BY publish_date DESC'
  ).all();
  return c.json(res.results);
});

// 6. Events
app.get('/api/events', async (c) => {
  const res = await c.env.DB.prepare(
    'SELECT * FROM events WHERE is_published = 1 ORDER BY event_date DESC'
  ).all();
  return c.json(res.results);
});

// 7. Gallery
app.get('/api/gallery', async (c) => {
  const res = await c.env.DB.prepare(
    'SELECT a.*, i.media_asset_id, m.r2_key FROM gallery_albums a LEFT JOIN gallery_images i ON a.id = i.album_id LEFT JOIN media_assets m ON i.media_asset_id = m.id'
  ).all();
  return c.json(res.results);
});

// 8. Admissions
app.post('/api/admissions', async (c) => {
  const body = await c.req.json();
  const { name, phone, email, message } = body;
  await c.env.DB.prepare(
    'INSERT INTO admission_enquiries (name, phone, email, message) VALUES (?, ?, ?, ?)'
  ).bind(name, phone, email, message).run();
  return c.json({ success: true });
});

// 9. Map
app.get('/api/map', async (c) => {
  const res = await c.env.DB.prepare(
    'SELECT * FROM map_settings LIMIT 1'
  ).first();
  return c.json(res);
});

// --- ADMIN API (AUTHENTICATED) ---
// Note: Full implementation of auth/RBAC/endpoints follows in Phase 3.
// Placeholder for Phase 1 scaffold.

export default app;
