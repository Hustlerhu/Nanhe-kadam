-- ===========================================================================
--  Nanhe Kadam — post-deploy media verification
--  Run after 0001_reset.sql:
--    npx wrangler d1 execute nanhe-kadam-db --remote --file=migrations/0002_media_seed.sql
--
--  Consolidates the bundled "Grand Opening – 11 Nov 2026" gallery so a fresh
--  database always shows the three real ceremony photos. Safe to re-run.
-- ===========================================================================

INSERT OR IGNORE INTO galleries (slug, title, subtitle, sort_order)
VALUES ('grand-opening', 'Grand Opening – 11 Nov 2026', 'Puja, guests and the full stage on our very first day', 1);

INSERT OR REPLACE INTO media_index (id, shard_id, storage_key, mime, size_bytes, chunk_count, label, gallery_id, created_at)
VALUES
  ('static:opening1.jpg', 0, 'opening1.jpg', 'image/jpeg', 314146, 0, 'Puja ceremony at the opening',    1, '2026-11-11T09:00:00Z'),
  ('static:opening2.jpg', 0, 'opening2.jpg', 'image/jpeg', 286495, 0, 'Director, Principal and guests', 1, '2026-11-11T09:30:00Z'),
  ('static:opening3.jpg', 0, 'opening3.jpg', 'image/jpeg', 353037, 0, 'Full stage group photo',          1, '2026-11-11T10:00:00Z');

INSERT INTO gallery_items (gallery_id, media_id, caption, sort_order, created_at)
SELECT 1, 'static:opening1.jpg', 'Puja ceremony — Grand Opening, 11 Nov 2026', 1, '2026-11-11T09:00:00Z'
WHERE NOT EXISTS (SELECT 1 FROM gallery_items WHERE media_id = 'static:opening1.jpg');

INSERT INTO gallery_items (gallery_id, media_id, caption, sort_order, created_at)
SELECT 1, 'static:opening2.jpg', 'Our Director, Principal and honoured guests', 2, '2026-11-11T09:30:00Z'
WHERE NOT EXISTS (SELECT 1 FROM gallery_items WHERE media_id = 'static:opening2.jpg');

INSERT INTO gallery_items (gallery_id, media_id, caption, sort_order, created_at)
SELECT 1, 'static:opening3.jpg', 'The full team on our opening day', 3, '2026-11-11T10:00:00Z'
WHERE NOT EXISTS (SELECT 1 FROM gallery_items WHERE media_id = 'static:opening3.jpg');

INSERT INTO events (title, date, description, media_id, is_featured)
SELECT 'Grand Opening of Nanhe Kadam Public School', '2026-11-11',
       'Puja ceremony followed by the formal inauguration with our Director, Principal and honoured guests.',
       'static:opening3.jpg', 1
WHERE NOT EXISTS (SELECT 1 FROM events WHERE date = '2026-11-11');

INSERT OR IGNORE INTO settings (key, value) VALUES
  ('logo_media_id',  'static:logo.jpg'),
  ('hero_media_id',  'static:hero.jpg'),
  ('about_media_id', 'static:about.jpg');
