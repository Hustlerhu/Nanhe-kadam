-- ===========================================================================
--  Nanhe Kadam Public School — schema, defaults and seed data
--  Run with:
--    npx wrangler d1 execute nanhe-kadam-db --remote --file=migrations/0001_reset.sql
--
--  SECURITY NOTE: the Super Admin password below is hashed with EXACTLY
--  100,000 PBKDF2-SHA256 iterations (Cloudflare Workers rejects higher counts).
--    username: Rakesh@1
--    password: rakesh@7632      (must_change_password = 1)
--  Generate a new hash with:  node scripts/hash-password.mjs "your password"
-- ===========================================================================

-- FOREIGN KEYS OFF FOR THE TEARDOWN -----------------------------------------
-- Dropping parents before children would otherwise raise
-- "FOREIGN KEY constraint failed" on a live database. We therefore switch FK
-- enforcement off for the drop phase (children first anyway, for clarity),
-- then switch it back on before any data is inserted.
PRAGMA foreign_keys = OFF;

DROP TABLE IF EXISTS media_chunks;
DROP TABLE IF EXISTS media;
DROP TABLE IF EXISTS media_index;
DROP TABLE IF EXISTS gallery_items;
DROP TABLE IF EXISTS galleries;
DROP TABLE IF EXISTS events;
DROP TABLE IF EXISTS notices;
DROP TABLE IF EXISTS teacher_assignments;
DROP TABLE IF EXISTS teacher_salaries;
DROP TABLE IF EXISTS teacher_attendance;
DROP TABLE IF EXISTS teachers;
DROP TABLE IF EXISTS enquiries;
DROP TABLE IF EXISTS sessions;
DROP TABLE IF EXISTS rate_limits;
DROP TABLE IF EXISTS audit_log;
DROP TABLE IF EXISTS classes;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS settings;

PRAGMA foreign_keys = ON;

-- ---------------------------------------------------------------------------
-- School configuration (key/value, everything editable from the portal)
-- ---------------------------------------------------------------------------
CREATE TABLE settings (
  key   TEXT PRIMARY KEY,
  value TEXT NOT NULL DEFAULT ''
);

INSERT OR IGNORE INTO settings (key, value) VALUES
  ('school_name',    'Nanhe Kadam Public School'),
  ('short_name',     'Nanhe Kadam'),
  ('tagline',        'Public School'),
  ('hero_headline',  'A Great Start for a Bright Future'),
  ('hero_sub',       'A safe, caring and creative environment where every child''s first steps into education feel joyful.'),
  ('about_title',    'About Our School'),
  ('about_text',     'Nanhe Kadam Public School is a nurturing space where young minds begin their journey of learning with joy, confidence and care. Guided by experienced teachers and a disciplined, values-first culture, we help children from Play Class to Class 5 grow academically, socially and emotionally — right here in Chorawa Icha, beside the well-known schools of the area.'),
  ('address',        'Near Sudha Factory, Chorawa Icha, Bihar'),
  ('map_embed',      'https://www.google.com/maps?q=Chorawa+Icha+Bihar&output=embed'),
  ('map_directions', 'https://www.google.com/maps/search/?api=1&query=Chorawa+Icha+Bihar'),
  ('phone',          '+91 95591 04341'),
  ('email',          'nanhekadam@gmail.com'),
  ('opening_date',   '2026-11-11'),
  ('principal',      'Amita Kumari'),
  ('director',       'R K'),
  ('play_learn_grow','Play • Learn • Grow'),
  ('logo_media_id',  'static:logo.jpg'),
  ('hero_media_id',  'static:hero.jpg'),
  ('about_media_id', 'static:about.jpg'),
  ('admissions_open','1'),
  ('admissions_note','Admissions open for Play Class to Class 5. Limited seats per section.'),
  ('whatsapp_number','919559104341'),
  ('whatsapp_message','Namaste! I would like to know more about admission at Nanhe Kadam Public School.'),
  ('whatsapp_enabled','1'),
  ('instagram_url',  'https://instagram.com/'),
  ('instagram_handle','@nanhekadam'),
  ('instagram_enabled','1'),
  ('facebook_url',   'https://facebook.com/'),
  ('facebook_handle','/nanhekadam'),
  ('facebook_enabled','1'),
  ('youtube_url',    'https://youtube.com/'),
  ('youtube_handle', '@nanhekadam'),
  ('youtube_enabled','1'),
  ('footer_note',    'Dream Big… Learn Big…'),
  ('vault_2_url',    ''),
  ('vault_2_secret', ''),
  ('vault_3_url',    ''),
  ('vault_3_secret', ''),
  ('vault_4_url',    ''),
  ('vault_4_secret', '');

-- ---------------------------------------------------------------------------
-- Users (Super Admin / Co-Admin / Teacher)
-- ---------------------------------------------------------------------------
CREATE TABLE users (
  id                   INTEGER PRIMARY KEY AUTOINCREMENT,
  username             TEXT NOT NULL UNIQUE,
  password_hash        TEXT NOT NULL,
  role                 TEXT NOT NULL CHECK (role IN ('super_admin', 'co_admin', 'teacher')),
  full_name            TEXT NOT NULL DEFAULT '',
  must_change_password INTEGER NOT NULL DEFAULT 1,
  active               INTEGER NOT NULL DEFAULT 1,
  created_at           TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX idx_users_role ON users(role);

-- Super Admin — Rakesh@1 / rakesh@7632 — 100,000 PBKDF2-SHA256 iterations.
INSERT INTO users (username, password_hash, role, full_name, must_change_password, active)
VALUES (
  'Rakesh@1',
  'pbkdf2$sha256$100000$FvYYlwapC7Wk4rbV6j8t0Q==$qF5FzobGR/ooUVuTW1/l3E8LgrJEiRrMpO2TfhFVxvs=',
  'super_admin',
  'Rakesh Kumar',
  1,
  1
);

-- ---------------------------------------------------------------------------
-- Sessions (server-side, HMAC-signed cookie points here)
-- ---------------------------------------------------------------------------
CREATE TABLE sessions (
  id         TEXT PRIMARY KEY,
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  ip         TEXT NOT NULL DEFAULT '',
  user_agent TEXT NOT NULL DEFAULT ''
);
CREATE INDEX idx_sessions_user ON sessions(user_id);
CREATE INDEX idx_sessions_expiry ON sessions(expires_at);

-- ---------------------------------------------------------------------------
-- Rate limiting (D1-backed fixed window)
-- ---------------------------------------------------------------------------
CREATE TABLE rate_limits (
  key        TEXT PRIMARY KEY,
  count      INTEGER NOT NULL DEFAULT 0,
  expires_at TEXT NOT NULL
);
CREATE INDEX idx_rate_expiry ON rate_limits(expires_at);

-- ---------------------------------------------------------------------------
-- Audit log
-- ---------------------------------------------------------------------------
CREATE TABLE audit_log (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id    INTEGER,
  action     TEXT NOT NULL,
  target     TEXT NOT NULL DEFAULT '',
  ip         TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL
);
CREATE INDEX idx_audit_created ON audit_log(created_at);

-- ---------------------------------------------------------------------------
-- Classes — Play Class to Class 5 (9 classes)
-- ---------------------------------------------------------------------------
CREATE TABLE classes (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  slug          TEXT NOT NULL UNIQUE,
  name          TEXT NOT NULL,
  age_group     TEXT NOT NULL DEFAULT '',
  summary       TEXT NOT NULL DEFAULT '',
  image_media_id TEXT NOT NULL DEFAULT '',
  sort_order    INTEGER NOT NULL DEFAULT 0,
  active        INTEGER NOT NULL DEFAULT 1
);

INSERT OR IGNORE INTO classes (slug, name, age_group, summary, sort_order) VALUES
  ('play-class', 'Play Class', '2.5 – 3.5 yrs', 'First friends, first songs, first smiles.',              1),
  ('nursery',    'Nursery',    '3 – 4 yrs',     'Rhymes, colours and confident little steps.',              2),
  ('lkg',        'LKG',        '4 – 5 yrs',     'Letters, numbers and lots of hands-on play.',              3),
  ('ukg',        'UKG',        '5 – 6 yrs',     'Reading readiness and school discipline.',                 4),
  ('class-1',    'Class 1',    '6 – 7 yrs',     'Strong foundations in English, Hindi and Maths.',          5),
  ('class-2',    'Class 2',    '7 – 8 yrs',     'Curiosity, comprehension and neat handwriting.',           6),
  ('class-3',    'Class 3',    '8 – 9 yrs',     'Project work, reading fluency and reasoning.',             7),
  ('class-4',    'Class 4',    '9 – 10 yrs',    'Independent study habits and confidence.',                 8),
  ('class-5',    'Class 5',    '10 – 11 yrs',   'CBSE-ready learners, ready for the next big step.',        9);

-- ---------------------------------------------------------------------------
-- Teachers, assignments, salary, attendance
-- ---------------------------------------------------------------------------
CREATE TABLE teachers (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id        INTEGER REFERENCES users(id) ON DELETE SET NULL,
  full_name      TEXT NOT NULL,
  designation    TEXT NOT NULL DEFAULT 'Teacher',
  phone          TEXT NOT NULL DEFAULT '',
  email          TEXT NOT NULL DEFAULT '',
  qualification  TEXT NOT NULL DEFAULT '',
  joined_on      TEXT NOT NULL DEFAULT '',
  monthly_salary INTEGER NOT NULL DEFAULT 0,
  active         INTEGER NOT NULL DEFAULT 1,
  created_at     TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX idx_teachers_user ON teachers(user_id);

CREATE TABLE teacher_assignments (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  teacher_id INTEGER NOT NULL REFERENCES teachers(id) ON DELETE CASCADE,
  class_id   INTEGER NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
  subject    TEXT NOT NULL DEFAULT 'All subjects'
);
CREATE INDEX idx_assign_teacher ON teacher_assignments(teacher_id);
CREATE INDEX idx_assign_class ON teacher_assignments(class_id);

CREATE TABLE teacher_salaries (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  teacher_id INTEGER NOT NULL REFERENCES teachers(id) ON DELETE CASCADE,
  month      TEXT NOT NULL,
  amount     INTEGER NOT NULL DEFAULT 0,
  paid_on    TEXT NOT NULL DEFAULT '',
  note       TEXT NOT NULL DEFAULT ''
);
CREATE INDEX idx_salary_teacher ON teacher_salaries(teacher_id);

CREATE TABLE teacher_attendance (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  teacher_id INTEGER NOT NULL REFERENCES teachers(id) ON DELETE CASCADE,
  day        TEXT NOT NULL,
  status     TEXT NOT NULL DEFAULT 'present' CHECK (status IN ('present', 'absent', 'leave')),
  note       TEXT NOT NULL DEFAULT '',
  UNIQUE (teacher_id, day)
);
CREATE INDEX idx_att_teacher ON teacher_attendance(teacher_id);

-- ---------------------------------------------------------------------------
-- Notices (3 realistic seeds)
-- ---------------------------------------------------------------------------
CREATE TABLE notices (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  title      TEXT NOT NULL,
  body       TEXT NOT NULL DEFAULT '',
  date       TEXT NOT NULL,
  is_new     INTEGER NOT NULL DEFAULT 0,
  pinned     INTEGER NOT NULL DEFAULT 0,
  audience   TEXT NOT NULL DEFAULT 'all' CHECK (audience IN ('all', 'public', 'staff', 'class')),
  author_id  INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX idx_notices_date ON notices(date);

INSERT INTO notices (title, body, date, is_new, pinned, audience) VALUES
  ('School will remain closed on 25th November 2026',
   'Dear parents, the school will remain closed on Wednesday, 25th November 2026 on account of a local holiday. Regular classes resume on 26th November 2026 at the usual time. Please ensure your child carries their diary and water bottle from the next working day.',
   '2026-11-23', 1, 1, 'all'),
  ('Annual Function Practice from 24th Nov',
   'Annual Function practice for all classes (Play Class to Class 5) begins on 24th November 2026. Practice will be held from 9:00 AM to 11:00 AM daily. Kindly send your child in comfortable clothes and school shoes. Parents will be informed about the final performance schedule through the class teacher.',
   '2026-11-20', 1, 0, 'all'),
  ('Winter Dress is Compulsory from 1st December',
   'From 1st December 2026, the school winter uniform is compulsory for all students — navy blue sweater or cardigan with the school monogram, along with the regular uniform. Please label your child''s belongings with their name and class. Classes will continue as usual.',
   '2026-11-18', 0, 0, 'all');

-- ---------------------------------------------------------------------------
-- Galleries + media index (Shard 0 = bundled artwork, 1..4 = storage pool)
-- ---------------------------------------------------------------------------
CREATE TABLE galleries (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  slug       TEXT NOT NULL UNIQUE,
  title      TEXT NOT NULL,
  subtitle   TEXT NOT NULL DEFAULT '',
  sort_order INTEGER NOT NULL DEFAULT 0
);

INSERT OR IGNORE INTO galleries (slug, title, subtitle, sort_order) VALUES
  ('grand-opening',  'Grand Opening – 11 Nov 2026', 'Puja, guests and the full stage on our very first day', 1),
  ('campus-life',    'Campus Life',                 'Classrooms, play area and everyday learning',           2),
  ('activities',     'Activities & Celebrations',   'Festivals, games and happy moments',                    3);

CREATE TABLE media_index (
  id          TEXT PRIMARY KEY,
  shard_id    INTEGER NOT NULL DEFAULT 1,
  storage_key TEXT NOT NULL,
  mime        TEXT NOT NULL DEFAULT 'image/jpeg',
  size_bytes  INTEGER NOT NULL DEFAULT 0,
  chunk_count INTEGER NOT NULL DEFAULT 0,
  label       TEXT NOT NULL DEFAULT '',
  gallery_id  INTEGER REFERENCES galleries(id) ON DELETE SET NULL,
  teacher_id  INTEGER REFERENCES teachers(id) ON DELETE CASCADE,
  uploaded_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at  TEXT NOT NULL
);
CREATE INDEX idx_media_shard ON media_index(shard_id);
CREATE INDEX idx_media_teacher ON media_index(teacher_id);
CREATE INDEX idx_media_gallery ON media_index(gallery_id);

CREATE TABLE gallery_items (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  gallery_id INTEGER NOT NULL REFERENCES galleries(id) ON DELETE CASCADE,
  media_id   TEXT NOT NULL,
  caption    TEXT NOT NULL DEFAULT '',
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX idx_gitems_gallery ON gallery_items(gallery_id);

-- Shard-1 chunk storage (also used by the primary D1 for Shard 1 uploads).
CREATE TABLE media (
  id          TEXT PRIMARY KEY,
  mime        TEXT NOT NULL,
  size_bytes  INTEGER NOT NULL,
  chunk_count INTEGER NOT NULL,
  created_at  TEXT NOT NULL
);

-- 512 KB raw chunks => 683 KB base64 rows: safely under the 1 MB D1 row limit
-- and under the 700 KB chunk budget. Never triggers SQLITE_TOOBIG.
CREATE TABLE media_chunks (
  media_id    TEXT NOT NULL,
  chunk_index INTEGER NOT NULL,
  data        TEXT NOT NULL,
  PRIMARY KEY (media_id, chunk_index)
);
CREATE INDEX idx_chunks_media ON media_chunks(media_id);

-- Opening ceremony photos are bundled static artwork (Shard 0) so they appear
-- live immediately after deploy, and stay fully editable/deletable in Admin.
INSERT INTO media_index (id, shard_id, storage_key, mime, size_bytes, chunk_count, label, gallery_id, created_at) VALUES
  ('static:opening1.jpg', 0, 'opening1.jpg', 'image/jpeg', 314146, 0, 'Puja ceremony at the opening',      1, '2026-11-11T09:00:00Z'),
  ('static:opening2.jpg', 0, 'opening2.jpg', 'image/jpeg', 286495, 0, 'Director, Principal and guests',   1, '2026-11-11T09:30:00Z'),
  ('static:opening3.jpg', 0, 'opening3.jpg', 'image/jpeg', 353037, 0, 'Full stage group photo',            1, '2026-11-11T10:00:00Z');

INSERT INTO gallery_items (gallery_id, media_id, caption, sort_order, created_at) VALUES
  (1, 'static:opening1.jpg', 'Puja ceremony — Grand Opening, 11 Nov 2026', 1, '2026-11-11T09:00:00Z'),
  (1, 'static:opening2.jpg', 'Our Director, Principal and honoured guests', 2, '2026-11-11T09:30:00Z'),
  (1, 'static:opening3.jpg', 'The full team on our opening day',            3, '2026-11-11T10:00:00Z');

-- ---------------------------------------------------------------------------
-- Events (opening day pre-seeded)
-- ---------------------------------------------------------------------------
CREATE TABLE events (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  title       TEXT NOT NULL,
  date        TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  media_id    TEXT NOT NULL DEFAULT '',
  is_featured INTEGER NOT NULL DEFAULT 0
);

INSERT INTO events (title, date, description, media_id, is_featured) VALUES
  ('Grand Opening of Nanhe Kadam Public School', '2026-11-11',
   'Puja ceremony followed by the formal inauguration with our Director, Principal and honoured guests.',
   'static:opening3.jpg', 1),
  ('Annual Function Practice Begins', '2026-11-24',
   'Daily practice for all classes from Play Class to Class 5.', '', 0),
  ('Winter Uniform Compulsory', '2026-12-01',
   'School winter uniform becomes compulsory for all students.', '', 0);

-- ---------------------------------------------------------------------------
-- Admission enquiries
-- ---------------------------------------------------------------------------
CREATE TABLE enquiries (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  parent_name      TEXT NOT NULL,
  child_name       TEXT NOT NULL,
  class_interested TEXT NOT NULL,
  phone            TEXT NOT NULL,
  email            TEXT NOT NULL DEFAULT '',
  message          TEXT NOT NULL DEFAULT '',
  status           TEXT NOT NULL DEFAULT 'new',
  created_at       TEXT NOT NULL,
  ip               TEXT NOT NULL DEFAULT ''
);
CREATE INDEX idx_enquiries_status ON enquiries(status);
