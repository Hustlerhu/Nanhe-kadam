/**
 * Minimal ambient declarations for the Cloudflare Workers runtime surface we
 * actually use. Keeping them local (instead of pulling a global types package)
 * lets the same sources typecheck under both the Workers and Node runtimes,
 * and means `npm run typecheck` needs zero extra typings installed.
 */
interface D1MetaLike {
  duration?: number;
  changes?: number;
  last_row_id?: number;
  rows_read?: number;
  rows_written?: number;
}

interface D1ResultLike<T = unknown> {
  results?: T[];
  success: boolean;
  meta?: D1MetaLike;
}

interface D1StatementLike {
  bind(...values: unknown[]): D1StatementLike;
  first<T = unknown>(colName?: string): Promise<T | null>;
  all<T = unknown>(): Promise<D1ResultLike<T>>;
  run<T = unknown>(): Promise<D1ResultLike<T>>;
}

interface D1DatabaseLike {
  prepare(query: string): D1StatementLike;
  batch<T = unknown>(statements: D1StatementLike[]): Promise<D1ResultLike<T>[]>;
  exec(query: string): Promise<{ count: number; duration: number }>;
}

interface ExecutionContextLike {
  waitUntil(promise: Promise<unknown>): void;
  passThroughOnException(): void;
}
