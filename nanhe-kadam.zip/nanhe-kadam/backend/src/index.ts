/**
 * Nanhe Kadam Public School — single Primary Worker.
 *
 *   GET  /                     server-rendered homepage (instantly painted from D1)
 *   GET  /style.css            design system
 *   GET  /public.js            public interaction layer (bubble sweep, drawers, forms)
 *   GET  /img/:file            bundled artwork
 *   GET  /api/media/:id        streamed from whichever of the 4 shards holds it
 *   POST /api/enquiries        public admission enquiry (rate limited + validated)
 *   GET  /api/notices          public notice JSON
 *   GET  /portal               login (bunny mascot)
 *   POST /api/login            sign in (PBKDF2 100k, D1 rate limiting, CSRF)
 *   GET  /portal/dashboard     server-gated dashboard (401/redirect if not signed in)
 *   POST /api/admin/:action    authenticated, role-checked mutations
 *
 * Storage is D1-ONLY. There is no R2 binding anywhere in this project.
 */
import type { Env } from './env.js';
import {
  errorPage,
  fail,
  html,
  isSameOrigin,
  json,
  ok,
  redirect,
  withSecurity,
  readJson,
  clientIp,
} from './lib/http.js';
import { escapeHtml, randomHex } from './lib/crypto.js';
import { canManageContent, canUploadMedia, checkCsrf, loadSession, issueCsrf } from './lib/auth.js';
import { dashboardData, mediaUrl, publicData } from './lib/data.js';
import { getSettings, listGalleries, listClasses } from './lib/db.js';
import { findMedia } from './lib/media.js';
import { deleteTeacherCascade } from './lib/db.js';
import { renderDashboard } from './views/dashboard.js';
import { renderLogin, renderPasswordGate } from './views/login.js';
import { renderFallback, renderHome } from './views/public.js';
import { handleAdmin } from './routes/admin.js';
import { handleLogin, handleLogout, handlePasswordChange } from './routes/auth.js';
import { handleEnquiry, handlePublicNotices } from './routes/public.js';
import { handleMediaDelete, handleMediaGet, handleMediaUpload } from './routes/media.js';
// Asset text is inlined by scripts/embed.mjs into frontend/embedded.ts.
// (Generated, not imported as a runtime module, so the Worker needs zero
// static-asset bindings and no R2 bucket.)
import * as ASSETS from '../../frontend/embedded.js';
const css = ASSETS.STYLE_CSS;
const publicJs = ASSETS.PUBLIC_JS;
const portalJs = ASSETS.PORTAL_JS;          // sign-in page only (public, minified)
const portalAppJs = ASSETS.PORTAL_APP_JS;   // dashboard only (edge-gated, mangled)
const portalCss = ASSETS.PORTAL_CSS;        // sign-in page styles (public)
const dashboardCss = ASSETS.DASHBOARD_CSS;  // app-shell styles (edge-gated)

/* ----------------------------- static assets ----------------------------- */

const BUNDLED_IMAGES: Record<string, string> = {
  'logo.jpg': 'image/jpeg',
  'hero.jpg': 'image/jpeg',
  'about.jpg': 'image/jpeg',
  'opening1.jpg': 'image/jpeg',
  'opening2.jpg': 'image/jpeg',
  'opening3.jpg': 'image/jpeg',
  'play-class.jpg': 'image/jpeg',
  'nursery.jpg': 'image/jpeg',
  'lkg.jpg': 'image/jpeg',
  'ukg.jpg': 'image/jpeg',
  'class-1.jpg': 'image/jpeg',
  'class-2.jpg': 'image/jpeg',
  'class-3.jpg': 'image/jpeg',
  'class-4.jpg': 'image/jpeg',
  'class-5.jpg': 'image/jpeg',
};
for (let i = 1; i <= 9; i++) BUNDLED_IMAGES[`class${i}.jpg`] = 'image/jpeg';

/**
 * Bundled artwork is embedded as base64 at build time by scripts/embed.mjs,
 * which writes frontend/embedded.ts (or leaves this empty when unavailable).
 */
const EMBEDDED: Record<string, string> = ASSETS.EMBEDDED_IMAGES;

function serveImage(file: string): Response {
  const name = file.replace(/^\/+/, '');
  if (!BUNDLED_IMAGES[name]) return new Response('Not found', { status: 404 });
  const dataUrl = EMBEDDED[name];
  if (!dataUrl) {
    return new Response('Asset not embedded — run `npm run embed` before deploying.', {
      status: 503,
      headers: { 'Content-Type': 'text/plain', 'Cache-Control': 'no-store' },
    });
  }
  const comma = dataUrl.indexOf(',');
  const bytes = Uint8Array.from(atob(dataUrl.slice(comma + 1)), (c) => c.charCodeAt(0));
  return new Response(bytes as unknown as BodyInit, {
    status: 200,
    headers: {
      'Content-Type': BUNDLED_IMAGES[name],
      'Content-Length': String(bytes.length),
      'Cache-Control': 'public, max-age=31536000, immutable',
      ETag: `"nk-${name}-${bytes.length}"`,
      'X-Content-Type-Options': 'nosniff',
    },
  });
}

/** Rewrites `/img/play-class.jpg` style class slugs onto the bundled class art. */
function classImageAlias(name: string): string | null {
  const map: Record<string, string> = {
    'play-class': 'class1.jpg',
    nursery: 'class2.jpg',
    lkg: 'class3.jpg',
    ukg: 'class4.jpg',
    'class-1': 'class5.jpg',
    'class-2': 'class6.jpg',
    'class-3': 'class7.jpg',
    'class-4': 'class8.jpg',
    'class-5': 'class9.jpg',
  };
  return map[name] ?? null;
}

/* --------------------------------- router -------------------------------- */

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url);
    const path = url.pathname.replace(/\/+$/, '') || '/';
    const method = request.method.toUpperCase();

    try {
      /* ---------------------------- security ---------------------------- */
      if (method === 'OPTIONS') {
        return new Response(null, { status: 204, headers: withSecurity({ Allow: 'GET, POST, DELETE, OPTIONS' }) });
      }

      /* --------------------------- static files ------------------------- */
      if (path === '/style.css' && method === 'GET') {
        return new Response(css, {
          headers: withSecurity({
            'Content-Type': 'text/css; charset=utf-8',
            'Cache-Control': 'public, max-age=3600',
          }),
        });
      }

      if (path === '/portal.css' && method === 'GET') {
        return new Response(portalCss, {
          headers: withSecurity({
            'Content-Type': 'text/css; charset=utf-8',
            'Cache-Control': 'public, max-age=3600',
          }),
        });
      }

      if (path === '/dashboard.css') {
        // GATED: app-shell design tokens reveal the admin layout, so they are
        // treated exactly like the dashboard bundle — session required.
        const session = await loadSession(env, request);
        if (!session) {
          const wantsCss = (request.headers.get('Accept') || '').includes('text/css');
          return wantsCss ? fail('Authentication required', 401) : redirect('/portal', 302);
        }
        return new Response(dashboardCss, {
          headers: withSecurity({
            'Content-Type': 'text/css; charset=utf-8',
            'Cache-Control': 'private, max-age=0, no-store',
            'X-Robots-Tag': 'noindex, nofollow',
          }),
        });
      }

      if (path === '/public.js' && method === 'GET') {
        return new Response(publicJs, {
          headers: withSecurity({
            'Content-Type': 'application/javascript; charset=utf-8',
            'Cache-Control': 'public, max-age=3600',
          }),
        });
      }

      if (path === '/portal.js' && method === 'GET') {
        // Public sign-in bundle: contains only the bunny + login forms.
        return new Response(portalJs, {
          headers: withSecurity({
            'Content-Type': 'application/javascript; charset=utf-8',
            'Cache-Control': 'private, max-age=0, no-store',
            'X-Robots-Tag': 'noindex, nofollow',
          }),
        });
      }

      if (path === '/portal-app.js') {
        // GATED: not one byte leaves the edge without a valid D1-backed session.
        const session = await loadSession(env, request);
        if (!session) {
          const wantsScript = (request.headers.get('Accept') || '').includes('javascript');
          return wantsScript ? fail('Authentication required', 401) : redirect('/portal', 302);
        }
        return new Response(portalAppJs, {
          headers: withSecurity({
            'Content-Type': 'application/javascript; charset=utf-8',
            'Cache-Control': 'private, max-age=0, no-store',
            'X-Robots-Tag': 'noindex, nofollow',
          }),
        });
      }

      if (path.startsWith('/img/') && method === 'GET') {
        const file = decodeURIComponent(path.slice(5));
        const alias = classImageAlias(file.replace(/\.jpg$/, ''));
        return serveImage(alias ?? file);
      }

      if (path === '/favicon.ico') return serveImage('logo.jpg');

      // Advertise no contact surface beyond the school email address.
      if (path === '/.well-known/security.txt') {
        return new Response(
          'Contact: mailto:nanhekadam@gmail.com\nExpires: 2027-11-11T00:00:00.000Z\nPreferred-Languages: en, hi\n',
          {
            headers: withSecurity({
              'Content-Type': 'text/plain; charset=utf-8',
              'Cache-Control': 'public, max-age=86400',
            }),
          },
        );
      }
      if (path === '/robots.txt') {
        return new Response('User-agent: *\nAllow: /\nDisallow: /portal\nDisallow: /api/\n', {
          headers: withSecurity({
            'Content-Type': 'text/plain; charset=utf-8',
            'Cache-Control': 'public, max-age=86400',
          }),
        });
      }

      /* ------------------------------ public ---------------------------- */
      if (path === '/' && method === 'GET') {
        try {
          const data = await publicData(env);
          const nonce = randomHex(16);
          return html(renderHome(data), 200, nonce, {
            'Cache-Control': 'public, max-age=60, stale-while-revalidate=600',
          });
        } catch (e) {
          return html(
            renderFallback('Database is not ready yet', 'Run migrations/0001_reset.sql then reload this page.'),
            503,
            randomHex(16),
          );
        }
      }

      /* ------------------------------ media ----------------------------- */
      const mediaMatch = /^\/api\/media\/([A-Za-z0-9_.%:-]{4,120})$/.exec(path);
      if (mediaMatch) {
        const mediaId = decodeURIComponent(mediaMatch[1]);
        if (method === 'GET') return await handleMediaGet(env, mediaId, request);
        if (method === 'DELETE') {
          const session = await loadSession(env, request);
          if (!session) return fail('Sign in to delete photos', 401);
          if (!isSameOrigin(request, env.BASE_URL ?? request.url)) return fail('Cross-origin request blocked', 403);
          const body = (await readJson<{ csrf?: string }>(request)) ?? {};
          if (!(await checkCsrf(env, request, body.csrf, session.sid))) return fail('Security token expired', 419);
          return await handleMediaDelete(env, request, session.user, mediaId);
        }
      }

      if (path === '/api/media' && method === 'POST') {
        const session = await loadSession(env, request);
        if (!session) return fail('Sign in to upload photos', 401);
        if (!canUploadMedia(session.user.role)) return fail('Not allowed', 403);
        if (!isSameOrigin(request, env.BASE_URL ?? request.url)) return fail('Cross-origin request blocked', 403);
        const raw = await request.clone().text();
        let parsed: { csrf?: string } = {};
        try {
          parsed = raw ? JSON.parse(raw) : {};
        } catch {
          return fail('Invalid JSON body', 400);
        }
        if (!(await checkCsrf(env, request, parsed.csrf, session.sid))) return fail('Security token expired', 419);
        const replay = new Request(request.url, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: raw,
        });
        return await handleMediaUpload(env, replay, session.user);
      }

      /* ----------------------------- public API ------------------------- */
      if (path === '/api/enquiries' && method === 'POST') {
        if (!isSameOrigin(request, env.BASE_URL ?? request.url)) return fail('Cross-origin request blocked', 403);
        return await handleEnquiry(env, request);
      }

      if (path === '/api/notices' && method === 'GET') return await handlePublicNotices(env);

      if (path === '/api/health') {
        const row = await env.DB.prepare('SELECT COUNT(*) AS n FROM settings').first<{ n: number }>().catch(() => null);
        return ok({ status: 'ok', db: row ? 'connected' : 'unavailable', time: new Date().toISOString() });
      }

      /* ------------------------------- auth ----------------------------- */
      if (path === '/api/login' && method === 'POST') return await handleLogin(env, request);
      if (path === '/api/logout' && method === 'POST') return await handleLogout(env, request);
      if (path === '/api/password' && method === 'POST') return await handlePasswordChange(env, request);

      /* ------------------------------ portal ---------------------------- */
      if (path === '/portal' || path === '/portal/login') {
        const session = await loadSession(env, request);
        if (session) {
          return redirect(session.user.must_change_password ? '/portal/password' : '/portal/dashboard');
        }
        const settings = await getSettings(env);
        const logo = mediaUrl(settings.logo_media_id) || '/img/logo.jpg';
        const csrf = await issueCsrf(env, 'anon');
        return html(
          renderLogin({
            logo,
            schoolName: settings.school_name,
            tagline: settings.tagline,
            csrf,
          }),
          200,
          randomHex(16),
          { 'X-Robots-Tag': 'noindex, nofollow' },
        );
      }

      if (path === '/portal/password') {
        const session = await loadSession(env, request);
        if (!session) return redirect('/portal');
        if (!session.user.must_change_password) return redirect('/portal/dashboard');
        const settings = await getSettings(env);
        const logo = mediaUrl(settings.logo_media_id) || '/img/logo.jpg';
        const csrf = await issueCsrf(env, session.sid);
        return html(
          renderPasswordGate({ logo, schoolName: settings.school_name, username: session.user.username, csrf }),
          200,
          randomHex(16),
          { 'X-Robots-Tag': 'noindex, nofollow' },
        );
      }

      if (path === '/portal/dashboard') {
        const session = await loadSession(env, request);
        if (!session) {
          // Unauthenticated: hard 302 to the login page (no dashboard bytes leak).
          return redirect('/portal', 302, { 'Cache-Control': 'no-store', 'X-Robots-Tag': 'noindex, nofollow' });
        }
        if (session.user.must_change_password) return redirect('/portal/password');
        const data = await dashboardData(env, session.user);
        const csrf = await issueCsrf(env, session.sid);
        return html(
          renderDashboard({ ...data, csrf }),
          200,
          randomHex(16),
          { 'Cache-Control': 'no-store, no-cache, must-revalidate', 'X-Robots-Tag': 'noindex, nofollow' },
        );
      }

      /* ---------------------------- admin API --------------------------- */
      const adminMatch = /^\/api\/admin\/([a-z.]+)$/.exec(path);
      if (adminMatch) {
        if (method !== 'POST') return fail('Method not allowed', 405);
        const session = await loadSession(env, request);
        if (!session) return fail('Authentication required', 401);
        if (!isSameOrigin(request, env.BASE_URL ?? request.url)) return fail('Cross-origin request blocked', 403);
        // Read once, then hand each handler a clone carrying the same body.
        const raw = await request.clone().text();
        let parsed: { csrf?: string } = {};
        try {
          parsed = raw ? JSON.parse(raw) : {};
        } catch {
          return fail('Invalid JSON body', 400);
        }
        if (!(await checkCsrf(env, request, parsed.csrf, session.sid))) {
          return fail('Security token expired — refresh the page.', 419);
        }
        const replay = new Request(request.url, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: raw,
        });
        const action = adminMatch[1];

        // Teacher role is limited to content actions it owns.
        if (session.user.role === 'teacher') {
          const teacherAllowed = new Set(['notice.create', 'notice.delete', 'notice.toggle', 'stats', 'session.probe']);
          if (!teacherAllowed.has(action)) return fail('Teachers cannot perform this action', 403);
        }
        if (!canManageContent(session.user.role) && session.user.role !== 'teacher') return fail('Not allowed', 403);
        return await handleAdmin(env, replay, session.user, action);
      }

      if (path === '/api/session' && method === 'GET') {
        const session = await loadSession(env, request);
        if (!session) return json({ ok: true, data: { authenticated: false } });
        return ok({
          authenticated: true,
          user: session.user,
          csrf: await issueCsrf(env, session.sid),
        });
      }

      /* ----------------------------- 404 ------------------------------- */
      if (path === '/dashboard') return redirect('/portal/dashboard');
      if (path === '/login') return redirect('/portal');

      const notFound = errorPage(404);
      return html(renderFallback(notFound.title, notFound.detail), 404, randomHex(16));
    } catch (error) {
      // Log internally, return nothing revealing to the client.
      const message = error instanceof Error ? error.message : String(error);
      console.error('[nk] unhandled error:', message);
      if (path.startsWith('/api/')) return fail(message, 500);
      const err = errorPage(500);
      return html(renderFallback(err.title, err.detail), 500, randomHex(16));
    }
  },
};

/** Exported for the test suite + dev server re-use. */
export const __internals = {
  handleAdmin,
  handleLogin,
  handleEnquiry,
  deleteTeacherCascade,
  listGalleries,
  listClasses,
  findMedia,
  escapeHtml,
  clientIp,
};
