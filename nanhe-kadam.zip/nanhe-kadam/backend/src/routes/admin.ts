/**
 * Authenticated admin API. Every branch re-checks the role on the SERVER —
 * the UI hiding a button is never treated as authorisation.
 */
import type { Env, Role, SessionUser } from '../env.js';
import { clientIp, fail, ok, readJson } from '../lib/http.js';
import { pbkdf2Hash } from '../lib/crypto.js';
import { nowIso, toInt } from '../lib/util.js';
import {
  audit,
  createSession,
  dashboardStats,
  deleteTeacherCascade,
  findUserByUsername,
  getSettings,
  listAssignments,
  listNotices,
  setSettings,
} from '../lib/db.js';
import type { Session } from '../env.js';

const SETTING_KEYS = new Set([
  'school_name', 'short_name', 'tagline', 'hero_headline', 'hero_sub', 'about_title', 'about_text',
  'address', 'map_embed', 'map_directions', 'phone', 'email', 'opening_date', 'principal', 'director',
  'play_learn_grow', 'admissions_open', 'admissions_note', 'footer_note',
  'whatsapp_number', 'whatsapp_message', 'whatsapp_enabled',
  'instagram_url', 'instagram_handle', 'instagram_enabled',
  'facebook_url', 'facebook_handle', 'facebook_enabled',
  'youtube_url', 'youtube_handle', 'youtube_enabled',
  'logo_media_id', 'hero_media_id', 'about_media_id',
]);

type Body = Record<string, unknown>;

function bad(msg: string, code = 422) {
  return fail(msg, code);
}

function str(body: Body, key: string, max = 500): string {
  return String(body[key] ?? '').trim().slice(0, max);
}

function int(body: Body, key: string, fallback = 0): number {
  const n = Number(body[key]);
  return Number.isFinite(n) ? Math.trunc(n) : fallback;
}

export async function handleAdmin(
  env: Env,
  request: Request,
  user: SessionUser,
  action: string,
): Promise<Response> {
  const ip = clientIp(request);
  const isSuper = user.role === 'super_admin';
  const isContent = user.role === 'super_admin' || user.role === 'co_admin';
  const body = (await readJson<Body>(request)) ?? {};

  // Vault configuration lives in the storage module (needs the media pool).
  if (action.startsWith('vault')) {
    const { handleVaultConfig } = await import('./media.js');
    return await handleVaultConfig(env, request, user);
  }

  switch (action) {
    /* ------------------------------ settings ---------------------------- */
    case 'settings': {
      if (!isContent) return fail('Not allowed', 403);
      const patch: Record<string, string> = {};
      for (const [k, v] of Object.entries(body)) {
        if (!SETTING_KEYS.has(k)) continue;
        patch[k] = String(v ?? '').slice(0, 4000);
      }
      if (!Object.keys(patch).length) return bad('Nothing to update');
      await setSettings(env, patch);
      await audit(env, user.id, 'settings.update', Object.keys(patch).join(','), ip);
      return ok({ updated: Object.keys(patch).length });
    }

    /* ------------------------------ notices ----------------------------- */
    case 'notice.create': {
      const title = str(body, 'title', 180);
      if (title.length < 3) return bad('Notice title is too short');
      const audience = ['all', 'public', 'staff', 'class'].includes(str(body, 'audience'))
        ? str(body, 'audience')
        : 'all';
      const result = await env.DB.prepare(
        `INSERT INTO notices (title, body, date, is_new, pinned, audience, author_id, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      )
        .bind(
          title,
          str(body, 'body', 4000),
          str(body, 'date', 10) || nowIso().slice(0, 10),
          int(body, 'is_new', 1) ? 1 : 0,
          int(body, 'pinned', 0) ? 1 : 0,
          audience,
          user.id,
          nowIso(),
        )
        .run();
      await audit(env, user.id, 'notice.create', title, ip);
      return ok({ id: result.meta?.last_row_id ?? 0 });
    }

    case 'notice.delete': {
      const id = int(body, 'id');
      if (!id) return bad('Missing notice id');
      await env.DB.prepare('DELETE FROM notices WHERE id = ?').bind(id).run();
      await audit(env, user.id, 'notice.delete', String(id), ip);
      return ok({ deleted: id });
    }

    case 'notice.toggle': {
      const id = int(body, 'id');
      const field = str(body, 'field');
      if (!id || !['is_new', 'pinned'].includes(field)) return bad('Invalid toggle');
      await env.DB.prepare(`UPDATE notices SET ${field} = ? WHERE id = ?`)
        .bind(int(body, 'value', 1) ? 1 : 0, id)
        .run();
      return ok({ id });
    }

    /* ------------------------------ classes ----------------------------- */
    case 'class.update': {
      if (!isContent) return fail('Not allowed', 403);
      const id = int(body, 'id');
      if (!id) return bad('Missing class id');
      await env.DB.prepare('UPDATE classes SET name = ?, age_group = ?, summary = ?, active = ? WHERE id = ?')
        .bind(
          str(body, 'name', 60) || 'Class',
          str(body, 'age_group', 40),
          str(body, 'summary', 400),
          int(body, 'active', 1) ? 1 : 0,
          id,
        )
        .run();
      await audit(env, user.id, 'class.update', String(id), ip);
      return ok({ id });
    }

    /* ------------------------------ teachers ---------------------------- */
    case 'teacher.create': {
      if (!isContent) return fail('Not allowed', 403);
      const fullName = str(body, 'full_name', 80);
      if (fullName.length < 3) return bad('Teacher name is too short');
      const username = str(body, 'username', 40);
      const password = str(body, 'password', 200);
      let userId: number | null = null;

      if (username) {
        if (!/^[A-Za-z0-9._@-]{3,40}$/.test(username)) return bad('Username may use letters, numbers, . _ - @ only');
        if (password.length < 8) return bad('Temporary password must be at least 8 characters');
        if (await findUserByUsername(env, username)) return bad('That username is already taken', 409);
        const hash = await pbkdf2Hash(password);
        const res = await env.DB.prepare(
          `INSERT INTO users (username, password_hash, role, full_name, must_change_password, active, created_at)
           VALUES (?, ?, 'teacher', ?, 1, 1, ?)`,
        )
          .bind(username, hash, fullName, nowIso())
          .run();
        userId = Number(res.meta?.last_row_id ?? 0) || null;
      }

      const tRes = await env.DB.prepare(
        `INSERT INTO teachers (user_id, full_name, designation, phone, email, qualification, joined_on, monthly_salary, active, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?)`,
      )
        .bind(
          userId,
          fullName,
          str(body, 'designation', 60) || 'Teacher',
          str(body, 'phone', 20),
          str(body, 'email', 120),
          str(body, 'qualification', 120),
          str(body, 'joined_on', 10) || nowIso().slice(0, 10),
          int(body, 'monthly_salary', 0),
          nowIso(),
        )
        .run();
      const teacherId = Number(tRes.meta?.last_row_id ?? 0);

      const classIds = Array.isArray(body.class_ids) ? (body.class_ids as unknown[]).map((c) => toInt(c)).filter(Boolean) : [];
      for (const cid of classIds) {
        await env.DB.prepare(
          'INSERT INTO teacher_assignments (teacher_id, class_id, subject) VALUES (?, ?, ?)',
        )
          .bind(teacherId, cid, str(body, 'subject', 60) || 'All subjects')
          .run();
      }
      await audit(env, user.id, 'teacher.create', `${fullName} #${teacherId}`, ip);
      return ok({ id: teacherId, user_id: userId }, 201);
    }

    case 'teacher.delete': {
      if (!isContent) return fail('Not allowed', 403);
      const id = int(body, 'id');
      if (!id) return bad('Missing teacher id');
      await deleteTeacherCascade(env, id);
      await audit(env, user.id, 'teacher.delete.cascade', String(id), ip);
      return ok({ deleted: id });
    }

    case 'assignment.create': {
      if (!isContent) return fail('Not allowed', 403);
      const teacherId = int(body, 'teacher_id');
      const classId = int(body, 'class_id');
      if (!teacherId || !classId) return bad('Teacher and class are required');
      const exists = await env.DB.prepare(
        'SELECT id FROM teacher_assignments WHERE teacher_id = ? AND class_id = ? AND subject = ?',
      )
        .bind(teacherId, classId, str(body, 'subject', 60) || 'All subjects')
        .first<{ id: number }>();
      if (exists) return bad('That assignment already exists', 409);
      const res = await env.DB.prepare('INSERT INTO teacher_assignments (teacher_id, class_id, subject) VALUES (?, ?, ?)')
        .bind(teacherId, classId, str(body, 'subject', 60) || 'All subjects')
        .run();
      return ok({ id: res.meta?.last_row_id ?? 0 }, 201);
    }

    case 'assignment.delete': {
      if (!isContent) return fail('Not allowed', 403);
      const id = int(body, 'id');
      await env.DB.prepare('DELETE FROM teacher_assignments WHERE id = ?').bind(id).run();
      return ok({ deleted: id });
    }

    /* ------------------------------- salary ----------------------------- */
    case 'salary.create': {
      if (!isContent) return fail('Not allowed', 403);
      const teacherId = int(body, 'teacher_id');
      const amount = int(body, 'amount');
      if (!teacherId) return bad('Choose a teacher');
      if (amount <= 0) return bad('Amount must be greater than zero');
      const res = await env.DB.prepare(
        'INSERT INTO teacher_salaries (teacher_id, month, amount, paid_on, note) VALUES (?, ?, ?, ?, ?)',
      )
        .bind(teacherId, str(body, 'month', 7) || nowIso().slice(0, 7), amount, str(body, 'paid_on', 10) || nowIso().slice(0, 10), str(body, 'note', 200))
        .run();
      await audit(env, user.id, 'salary.create', `teacher=${teacherId} ₹${amount}`, ip);
      return ok({ id: res.meta?.last_row_id ?? 0 }, 201);
    }

    case 'salary.delete': {
      if (!isContent) return fail('Not allowed', 403);
      await env.DB.prepare('DELETE FROM teacher_salaries WHERE id = ?').bind(int(body, 'id')).run();
      return ok({ deleted: int(body, 'id') });
    }

    case 'attendance.create': {
      if (!isContent) return fail('Not allowed', 403);
      const teacherId = int(body, 'teacher_id');
      const day = str(body, 'day', 10);
      if (!teacherId || !day) return bad('Teacher and date are required');
      const status = ['present', 'absent', 'leave'].includes(str(body, 'status')) ? str(body, 'status') : 'present';
      await env.DB.prepare(
        `INSERT INTO teacher_attendance (teacher_id, day, status, note) VALUES (?, ?, ?, ?)
         ON CONFLICT(teacher_id, day) DO UPDATE SET status = excluded.status, note = excluded.note`,
      )
        .bind(teacherId, day, status, str(body, 'note', 200))
        .run();
      return ok({ saved: true }, 201);
    }

    case 'attendance.delete': {
      if (!isContent) return fail('Not allowed', 403);
      await env.DB.prepare('DELETE FROM teacher_attendance WHERE id = ?').bind(int(body, 'id')).run();
      return ok({ deleted: int(body, 'id') });
    }

    /* ------------------------------ galleries --------------------------- */
    case 'gallery.create': {
      if (!isContent) return fail('Not allowed', 403);
      const title = str(body, 'title', 120);
      if (title.length < 3) return bad('Section title is too short');
      const max = await env.DB.prepare('SELECT COALESCE(MAX(sort_order), 0) AS m FROM galleries').first<{ m: number }>();
      const res = await env.DB.prepare(
        'INSERT INTO galleries (slug, title, subtitle, sort_order) VALUES (?, ?, ?, ?)',
      )
        .bind(`g-${Date.now().toString(36)}`, title, str(body, 'subtitle', 200), Number(max?.m ?? 0) + 1)
        .run();
      await audit(env, user.id, 'gallery.create', title, ip);
      return ok({ id: res.meta?.last_row_id ?? 0 }, 201);
    }

    case 'gallery.delete': {
      if (!isSuper) return fail('Only the Super Admin can delete a gallery section', 403);
      const id = int(body, 'id');
      const items = await env.DB.prepare('SELECT media_id FROM gallery_items WHERE gallery_id = ?').bind(id).all<{ media_id: string }>();
      const { deleteMedia } = await import('../lib/media.js');
      for (const it of items.results ?? []) await deleteMedia(env, it.media_id).catch(() => undefined);
      await env.DB.prepare('DELETE FROM gallery_items WHERE gallery_id = ?').bind(id).run();
      await env.DB.prepare('DELETE FROM galleries WHERE id = ?').bind(id).run();
      return ok({ deleted: id });
    }

    case 'event.create': {
      if (!isContent) return fail('Not allowed', 403);
      const title = str(body, 'title', 140);
      if (title.length < 3) return bad('Event title is too short');
      const res = await env.DB.prepare(
        'INSERT INTO events (title, date, description, media_id, is_featured) VALUES (?, ?, ?, ?, 0)',
      )
        .bind(title, str(body, 'date', 10) || nowIso().slice(0, 10), str(body, 'description', 600), str(body, 'media_id', 60))
        .run();
      return ok({ id: res.meta?.last_row_id ?? 0 }, 201);
    }

    case 'event.delete': {
      if (!isContent) return fail('Not allowed', 403);
      await env.DB.prepare('DELETE FROM events WHERE id = ?').bind(int(body, 'id')).run();
      return ok({ deleted: int(body, 'id') });
    }

    /* ------------------------------ enquiries --------------------------- */
    case 'enquiry.delete': {
      if (!isContent) return fail('Not allowed', 403);
      await env.DB.prepare('DELETE FROM enquiries WHERE id = ?').bind(int(body, 'id')).run();
      await audit(env, user.id, 'enquiry.delete', String(int(body, 'id')), ip);
      return ok({ deleted: int(body, 'id') });
    }

    case 'enquiry.status': {
      if (!isContent) return fail('Not allowed', 403);
      const status = ['new', 'contacted', 'admitted', 'closed'].includes(str(body, 'status')) ? str(body, 'status') : 'new';
      await env.DB.prepare('UPDATE enquiries SET status = ? WHERE id = ?').bind(status, int(body, 'id')).run();
      return ok({ id: int(body, 'id'), status });
    }

    /* ------------------------------- users ------------------------------ */
    case 'user.create': {
      if (!isSuper) return fail('Only the Super Admin can create logins', 403);
      const username = str(body, 'username', 40);
      const password = str(body, 'password', 200);
      const roleInput = str(body, 'role');
      const role: Role = roleInput === 'teacher' ? 'teacher' : 'co_admin';
      if (!/^[A-Za-z0-9._@-]{3,40}$/.test(username)) return bad('Username may use letters, numbers, . _ - @ only');
      if (password.length < 8) return bad('Password must be at least 8 characters');
      if (await findUserByUsername(env, username)) return bad('That username is already taken', 409);

      const hash = await pbkdf2Hash(password);
      const res = await env.DB.prepare(
        `INSERT INTO users (username, password_hash, role, full_name, must_change_password, active, created_at)
         VALUES (?, ?, ?, ?, 1, 1, ?)`,
      )
        .bind(username, hash, role, str(body, 'full_name', 80) || username, nowIso())
        .run();
      const userId = Number(res.meta?.last_row_id ?? 0);

      if (role === 'teacher') {
        const tRes = await env.DB.prepare(
          `INSERT INTO teachers (user_id, full_name, designation, phone, email, qualification, joined_on, monthly_salary, active, created_at)
           VALUES (?, ?, 'Teacher', ?, '', '', ?, ?, 1, ?)`,
        )
          .bind(userId, str(body, 'full_name', 80) || username, str(body, 'phone', 20), nowIso().slice(0, 10), int(body, 'monthly_salary', 0), nowIso())
          .run();
        const teacherId = Number(tRes.meta?.last_row_id ?? 0);
        const classIds = Array.isArray(body.class_ids) ? (body.class_ids as unknown[]).map((c) => toInt(c)).filter(Boolean) : [];
        for (const cid of classIds) {
          await env.DB.prepare('INSERT INTO teacher_assignments (teacher_id, class_id, subject) VALUES (?, ?, ?)')
            .bind(teacherId, cid, 'All subjects')
            .run();
        }
      }
      await audit(env, user.id, 'user.create', `${role}:${username}`, ip);
      return ok({ id: userId, role }, 201);
    }

    case 'user.delete': {
      if (!isSuper) return fail('Only the Super Admin can delete logins', 403);
      const id = int(body, 'id');
      const target = await env.DB.prepare('SELECT id, role FROM users WHERE id = ?').bind(id).first<{ id: number; role: Role }>();
      if (!target) return bad('Account not found', 404);
      if (target.role === 'super_admin') return fail('The Super Admin account cannot be deleted', 403);
      if (target.id === user.id) return fail('You cannot delete your own account', 400);
      if (target.role === 'teacher') {
        const t = await env.DB.prepare('SELECT id FROM teachers WHERE user_id = ?').bind(id).first<{ id: number }>();
        if (t) await deleteTeacherCascade(env, t.id);
      }
      await env.DB.prepare('DELETE FROM sessions WHERE user_id = ?').bind(id).run();
      await env.DB.prepare('DELETE FROM users WHERE id = ? AND role <> ?').bind(id, 'super_admin').run();
      await audit(env, user.id, 'user.delete', String(id), ip);
      return ok({ deleted: id });
    }

    case 'user.reset': {
      if (!isSuper) return fail('Only the Super Admin can reset passwords', 403);
      const id = int(body, 'id');
      const password = str(body, 'password') || `Nk@${Math.random().toString(36).slice(2, 10)}`;
      if (password.length < 8) return bad('Password must be at least 8 characters');
      const hash = await pbkdf2Hash(password);
      await env.DB.prepare('UPDATE users SET password_hash = ?, must_change_password = 1 WHERE id = ?').bind(hash, id).run();
      await env.DB.prepare('DELETE FROM sessions WHERE user_id = ?').bind(id).run();
      await audit(env, user.id, 'user.reset', String(id), ip);
      return ok({ id, temporary_password: password });
    }

    /* ----------------------------- dashboard ---------------------------- */
    case 'stats': {
      const stats = await dashboardStats(env);
      const notices = await listNotices(env, { audience: ['all', 'public', 'staff', 'class'], limit: 10 });
      const assignments = await listAssignments(env, user.role === 'teacher' ? user.teacher_id ?? -1 : undefined);
      return ok({ stats, notices: notices.map((n) => ({ id: n.id, title: n.title, date: n.date })), assignments });
    }

    case 'session.probe': {
      const settings = await getSettings(env);
      return ok({ school: settings.short_name, role: user.role });
    }

    default:
      return fail(`Unknown action: ${action}`, 404);
  }
}

/** Create a session row for tests / dev tooling (never exposed as a route). */
export async function seedSession(env: Env, session: Session): Promise<void> {
  await createSession(env, session.sid, session.user.id, '127.0.0.1', 'seed', 1);
}
