/** Public API endpoints: enquiry submission + notice lookup. */
import type { Env } from '../env.js';
import { clientIp, fail, ok, rateLimit, readJson } from '../lib/http.js';
import { getSettings, listNotices } from '../lib/db.js';

const PHONE_RE = /^[6-9]\d{9}$|^\+?[1-9]\d{7,14}$/;

export async function handleEnquiry(env: Env, request: Request): Promise<Response> {
  const ip = clientIp(request);
  const limit = await rateLimit(env.DB, `enquiry:${ip}`, 5, 600);
  if (!limit.allowed) {
    return fail('Too many enquiries from this connection. Please try again in a few minutes.', 429);
  }

  const body = await readJson<Record<string, unknown>>(request);
  if (!body) return fail('Invalid request body', 400);

  const parentName = String(body.parent_name ?? '').trim().slice(0, 80);
  const childName = String(body.child_name ?? '').trim().slice(0, 80);
  const phoneRaw = String(body.phone ?? '').replace(/[\s\-()]/g, '');
  const classInterested = String(body.class_interested ?? '').trim().slice(0, 40);
  const message = String(body.message ?? '').trim().slice(0, 600);
  const email = String(body.email ?? '').trim().slice(0, 120);

  if (parentName.length < 2) return fail("Please enter the parent's name.", 422);
  if (childName.length < 2) return fail("Please enter the child's name.", 422);
  if (!PHONE_RE.test(phoneRaw)) return fail('Please enter a valid 10-digit mobile number.', 422);

  const classes = await env.DB.prepare('SELECT name FROM classes WHERE active = 1').all<{ name: string }>();
  const validClasses = (classes.results ?? []).map((c) => c.name);
  if (!validClasses.includes(classInterested)) return fail('Please choose a class from the list.', 422);

  // Light duplicate guard: same phone + class within 10 minutes.
  const duplicate = await env.DB.prepare(
    'SELECT id FROM enquiries WHERE phone = ? AND class_interested = ? AND created_at > ? LIMIT 1',
  )
    .bind(phoneRaw, classInterested, new Date(Date.now() - 600_000).toISOString())
    .first<{ id: number }>();
  if (duplicate) {
    return ok({ duplicate: true, message: 'We already have your enquiry — our team will call you soon.' });
  }

  await env.DB.prepare(
    `INSERT INTO enquiries (parent_name, child_name, class_interested, phone, email, message, status, created_at, ip)
     VALUES (?, ?, ?, ?, ?, ?, 'new', ?, ?)`,
  )
    .bind(parentName, childName, classInterested, phoneRaw, email, message, new Date().toISOString(), ip)
    .run();

  const settings = await getSettings(env);
  return ok({
    received: true,
    message: `Thank you, ${parentName}! Your enquiry for ${classInterested} is with ${settings.short_name}. We will call you on ${phoneRaw} soon.`,
  });
}

export async function handlePublicNotices(env: Env): Promise<Response> {
  const notices = await listNotices(env, { audience: ['all', 'public'], limit: 40 });
  return ok(
    notices.map((n) => ({
      id: n.id,
      title: n.title,
      body: n.body,
      date: n.date,
      isNew: !!n.is_new,
      pinned: !!n.pinned,
    })),
  );
}
