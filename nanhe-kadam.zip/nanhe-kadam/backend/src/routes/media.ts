/** Public + admin media endpoints (upload, stream, delete). */
import type { Env, SessionUser } from '../env.js';
import { fail, ok, readJson, clientIp } from '../lib/http.js';
import { randomHex, safeUrl } from '../lib/crypto.js';
import { MAX_UPLOAD_BYTES, deleteMedia, findMedia, readMedia, shardPool, testVault } from '../lib/media.js';
import { audit, getSettings, setSettings } from '../lib/db.js';
import { canUploadMedia, canManageContent } from '../lib/auth.js';
import { storeMedia } from '../lib/media.js';

const ALLOWED_MIME = new Set(['image/webp', 'image/jpeg', 'image/png', 'image/avif']);

function dataUrlToBytes(dataUrl: string): { mime: string; bytes: Uint8Array } | null {
  const match = /^data:([a-z0-9.+/-]+);base64,(.+)$/i.exec(dataUrl.trim());
  if (!match) return null;
  const mime = match[1].toLowerCase();
  const bin = atob(match[2]);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return { mime, bytes };
}

/** GET /api/media/:id — stream from whichever shard holds the bytes. */
export async function handleMediaGet(env: Env, id: string, request: Request): Promise<Response> {
  const rec = await findMedia(env, id);
  if (!rec) return new Response('Not found', { status: 404, headers: { 'Content-Type': 'text/plain' } });

  if (rec.shard_id === 0) {
    // Bundled static artwork: redirect to the immutable asset route.
    return new Response(null, {
      status: 302,
      headers: { Location: `/img/${encodeURIComponent(rec.storage_key)}`, 'Cache-Control': 'public, max-age=86400' },
    });
  }

  const data = await readMedia(env, rec);
  if (!data) return new Response('Media unavailable', { status: 503, headers: { 'Content-Type': 'text/plain' } });

  const etag = `"${rec.id}-${rec.size_bytes}"`;
  if (request.headers.get('If-None-Match') === etag) {
    return new Response(null, { status: 304, headers: { ETag: etag } });
  }

  return new Response(data.bytes as unknown as BodyInit, {
    status: 200,
    headers: {
      'Content-Type': data.mime || rec.mime || 'application/octet-stream',
      'Content-Length': String(data.bytes.length),
      'Cache-Control': 'public, max-age=3600',
      ETag: etag,
      'X-Content-Type-Options': 'nosniff',
      'Content-Disposition': 'inline',
      'Cross-Origin-Resource-Policy': 'same-origin',
    },
  });
}

export interface UploadResult {
  id: string;
  url: string;
  shard: number;
  bytes: number;
  chunks: number;
}

/** POST /api/media — accepts a base64 data URL already resized client-side. */
export async function handleMediaUpload(
  env: Env,
  request: Request,
  user: SessionUser,
): Promise<Response> {
  if (!canUploadMedia(user.role)) return fail('Not allowed', 403);
  const body = await readJson<{
    data?: string;
    label?: string;
    gallery_id?: number;
    kind?: string;
    replace_id?: string;
  }>(request);
  if (!body || typeof body.data !== 'string') return fail('Missing image payload', 400);

  const parsed = dataUrlToBytes(body.data);
  if (!parsed) return fail('Image must be a base64 data URL', 400);
  if (!ALLOWED_MIME.has(parsed.mime)) return fail(`Unsupported image type: ${parsed.mime}`, 415);
  if (parsed.bytes.length > MAX_UPLOAD_BYTES) {
    return fail(`Photo is ${(parsed.bytes.length / 1048576).toFixed(2)} MB — the maximum is 3 MB.`, 413);
  }
  if (parsed.bytes.length < 64) return fail('Image appears to be empty', 400);

  const kind = String(body.kind ?? 'gallery');
  const id = `m_${Date.now().toString(36)}${randomHex(4)}`;
  const galleryId = body.gallery_id ? Number(body.gallery_id) : null;

  const stored = await storeMedia(env, {
    id,
    mime: parsed.mime,
    bytes: parsed.bytes,
    ownerUserId: user.id,
    teacherId: user.teacher_id,
    galleryId,
    label: String(body.label ?? '').slice(0, 160),
  });
  if (!stored) {
    return fail('All four storage vaults are full (2,000 MB used). Free space or add another vault.', 507);
  }

  // Brand image slots are referenced by settings, so point them at the new asset.
  if (kind === 'logo' || kind === 'hero' || kind === 'about') {
    await setSettings(env, { [`${kind}_media_id`]: stored.id });
    const previous = await getSettings(env);
    void previous;
  }

  // Attach to a gallery section when requested.
  if (kind === 'gallery' && galleryId) {
    const maxOrder = await env.DB.prepare(
      'SELECT COALESCE(MAX(sort_order), 0) AS m FROM gallery_items WHERE gallery_id = ?',
    )
      .bind(galleryId)
      .first<{ m: number }>();
    await env.DB.prepare(
      'INSERT INTO gallery_items (gallery_id, media_id, caption, sort_order, created_at) VALUES (?, ?, ?, ?, ?)',
    )
      .bind(galleryId, stored.id, String(body.label ?? '').slice(0, 160), Number(maxOrder?.m ?? 0) + 1, new Date().toISOString())
      .run();
  }

  await audit(env, user.id, 'media.upload', `${stored.id} shard=${stored.shardId} ${stored.bytes}b`, clientIp(request));
  const result: UploadResult = {
    id: stored.id,
    url: `/api/media/${stored.id}`,
    shard: stored.shardId,
    bytes: stored.bytes,
    chunks: stored.chunks,
  };
  return ok(result, 201);
}

/** DELETE /api/media/:id */
export async function handleMediaDelete(env: Env, request: Request, user: SessionUser, id: string): Promise<Response> {
  if (!canManageContent(user.role) && user.role !== 'teacher') return fail('Not allowed', 403);
  const rec = await findMedia(env, id);
  if (!rec) return fail('Photo not found', 404);
  // Teachers may only remove assets they uploaded.
  if (user.role === 'teacher' && rec.uploaded_by !== user.id) return fail('You can only delete your own uploads', 403);

  await env.DB.prepare('DELETE FROM gallery_items WHERE media_id = ?').bind(id).run();
  await deleteMedia(env, id);

  // Clear any brand slot still pointing at the removed asset.
  const settings = await getSettings(env);
  const patch: Record<string, string> = {};
  for (const key of ['logo_media_id', 'hero_media_id', 'about_media_id']) {
    if (settings[key] === id) patch[key] = '';
  }
  if (Object.keys(patch).length) await setSettings(env, patch);

  await audit(env, user.id, 'media.delete', id, clientIp(request));
  return ok({ deleted: id });
}

/** POST /api/admin/vaults — save vault URLs + secrets, or test them. */
export async function handleVaultConfig(env: Env, request: Request, user: SessionUser): Promise<Response> {
  if (user.role !== 'super_admin') return fail('Only the Super Admin can manage storage vaults', 403);
  const body = await readJson<{ action?: string; vaults?: Record<string, string> }>(request);
  if (!body) return fail('Invalid payload', 400);

  if (body.action === 'test') {
    const s = await getSettings(env);
    const results = [];
    for (const n of [2, 3, 4]) {
      const url = safeUrl(body.vaults?.[`vault_${n}_url`] ?? s[`vault_${n}_url`] ?? '', '');
      const secret = body.vaults?.[`vault_${n}_secret`] ?? s[`vault_${n}_secret`] ?? '';
      if (!url || !secret) {
        results.push({ vault: n, ok: false, message: 'Not configured' });
        continue;
      }
      const r = await testVault(url, secret);
      results.push({ vault: n, ...r });
    }
    return ok({ results });
  }

  const patch: Record<string, string> = {};
  for (const n of [2, 3, 4]) {
    const url = body.vaults?.[`vault_${n}_url`];
    const secret = body.vaults?.[`vault_${n}_secret`];
    if (typeof url === 'string') patch[`vault_${n}_url`] = safeUrl(url, '');
    if (typeof secret === 'string') patch[`vault_${n}_secret`] = secret.slice(0, 200);
  }
  await setSettings(env, patch);
  await audit(env, user.id, 'vault.configure', Object.keys(patch).join(','), clientIp(request));
  const shards = await shardPool(env);
  return ok({ shards });
}
