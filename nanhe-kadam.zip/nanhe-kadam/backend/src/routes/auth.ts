/** Authentication endpoints: login, logout, password change. */
import type { Env } from '../env.js';
import { fail, ok, readJson, clientIp, isSameOrigin } from '../lib/http.js';
import { pbkdf2Hash, pbkdf2Verify } from '../lib/crypto.js';
import { audit, findUserByUsername, findUserById } from '../lib/db.js';
import { checkCsrf, endSession, loadSession, startSession, timingNoise } from '../lib/auth.js';

const LOGIN_LIMIT = 8;
const LOGIN_WINDOW_SECONDS = 600;

export async function handleLogin(env: Env, request: Request): Promise<Response> {
  const ip = clientIp(request);
  if (!isSameOrigin(request, env.BASE_URL ?? request.url)) return fail('Cross-origin login blocked', 403);

  const body = await readJson<{ username?: string; password?: string; role?: string; csrf?: string }>(request);
  if (!body) return fail('Invalid request', 400);

  if (!(await checkCsrf(env, request, body.csrf))) return fail('Security token expired — please refresh the page.', 419);

  // D1-backed brute-force limiter: per IP and per username.
  const ipKey = `login:ip:${ip}`;
  const userKey = `login:u:${String(body.username ?? '').toLowerCase().slice(0, 40)}`;
  const [ipLimit, userLimit] = await Promise.all([
    env.DB.prepare(
      `INSERT INTO rate_limits (key, count, expires_at) VALUES (?, 1, ?)
       ON CONFLICT(key) DO UPDATE SET count = count + 1`,
    )
      .bind(`${ipKey}:${Math.floor(Date.now() / (LOGIN_WINDOW_SECONDS * 1000))}`, new Date(Date.now() + 900_000).toISOString())
      .run()
      .catch(() => undefined)
      .then(() =>
        env.DB.prepare('SELECT count FROM rate_limits WHERE key = ?')
          .bind(`${ipKey}:${Math.floor(Date.now() / (LOGIN_WINDOW_SECONDS * 1000))}`)
          .first<{ count: number }>(),
      ),
    env.DB.prepare(
      `INSERT INTO rate_limits (key, count, expires_at) VALUES (?, 1, ?)
       ON CONFLICT(key) DO UPDATE SET count = count + 1`,
    )
      .bind(`${userKey}:${Math.floor(Date.now() / (LOGIN_WINDOW_SECONDS * 1000))}`, new Date(Date.now() + 900_000).toISOString())
      .run()
      .catch(() => undefined)
      .then(() =>
        env.DB.prepare('SELECT count FROM rate_limits WHERE key = ?')
          .bind(`${userKey}:${Math.floor(Date.now() / (LOGIN_WINDOW_SECONDS * 1000))}`)
          .first<{ count: number }>(),
      ),
  ]);

  if (Number(ipLimit?.count ?? 0) > 20 || Number(userLimit?.count ?? 0) > LOGIN_LIMIT) {
    await audit(env, null, 'login.ratelimited', ip, ip);
    return fail('Too many attempts. Please wait 10 minutes before trying again.', 429);
  }

  const username = String(body.username ?? '').trim();
  const password = String(body.password ?? '');
  if (!username || !password) return fail('Username and password are required.', 422);

  const user = await findUserByUsername(env, username);
  const valid = user ? await pbkdf2Verify(password, user.password_hash) : false;

  if (!user || !valid || !user.active) {
    await timingNoise();
    await audit(env, user?.id ?? null, 'login.failed', username.slice(0, 40), ip);
    return fail('Invalid username or password.', 401);
  }

  const requestedRole = String(body.role ?? '');
  if (requestedRole && requestedRole !== user.role) {
    return fail(`This account signs in as ${user.role.replace('_', ' ')}. Please pick the matching tab.`, 403);
  }

  const teacherRow = await env.DB.prepare('SELECT id FROM teachers WHERE user_id = ? LIMIT 1')
    .bind(user.id)
    .first<{ id: number }>();
  void teacherRow;
  const cookie = await startSession(env, request, user);
  await audit(env, user.id, 'login.success', user.username, ip);

  return new Response(
    JSON.stringify({
      ok: true,
      data: {
        role: user.role,
        full_name: user.full_name,
        must_change_password: !!user.must_change_password,
        redirect: user.must_change_password ? '/portal/password' : '/portal/dashboard',
      },
    }),
    {
      status: 200,
      headers: {
        'Content-Type': 'application/json; charset=utf-8',
        'Cache-Control': 'no-store',
        'Set-Cookie': cookie,
      },
    },
  );
}

export async function handleLogout(env: Env, request: Request): Promise<Response> {
  const session = await loadSession(env, request);
  const cookie = await endSession(env, session?.sid ?? null);
  if (session) await audit(env, session.user.id, 'logout', session.user.username, clientIp(request));
  const headers = new Headers({ 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  headers.append('Set-Cookie', cookie);
  return new Response(JSON.stringify({ ok: true, data: { redirect: '/portal' } }), { status: 200, headers });
}

export async function handlePasswordChange(env: Env, request: Request): Promise<Response> {
  const session = await loadSession(env, request);
  if (!session) return fail('Session expired — please sign in again.', 401);

  const body = await readJson<{ current_password?: string; new_password?: string; csrf?: string }>(request);
  if (!body) return fail('Invalid request', 400);
  if (!(await checkCsrf(env, request, body.csrf, session.sid))) return fail('Security token expired — refresh and retry.', 419);

  const newPassword = String(body.new_password ?? '');
  if (newPassword.length < 8) return fail('New password must be at least 8 characters.', 422);
  if (newPassword.length > 200) return fail('Password is too long.', 422);

  const user = await findUserById(env, session.user.id);
  if (!user) return fail('Account not found', 404);

  // First-run users may set the password without re-entering the temporary one.
  if (!session.user.must_change_password) {
    const current = String(body.current_password ?? '');
    if (!(await pbkdf2Verify(current, user.password_hash))) {
      return fail('Current password is incorrect.', 403);
    }
  }

  const hash = await pbkdf2Hash(newPassword);
  await env.DB.prepare('UPDATE users SET password_hash = ?, must_change_password = 0 WHERE id = ?')
    .bind(hash, user.id)
    .run();
  await env.DB.prepare('DELETE FROM sessions WHERE user_id = ? AND id <> ?').bind(user.id, session.sid).run();
  await audit(env, user.id, 'password.change', user.username, clientIp(request));

  return ok({ updated: true, message: 'Password updated. Other devices have been signed out.' });
}
