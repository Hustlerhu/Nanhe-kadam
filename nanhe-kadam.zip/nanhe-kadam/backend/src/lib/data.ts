/** Assemblers that build the exact view-model shapes the renderers consume. */
import type { Env, SessionUser } from '../env.js';
import {
  dashboardStats,
  getSettings,
  listAssignments,
  listAttendance,
  listClasses,
  listEnquiries,
  listEvents,
  listGalleries,
  listGalleryItems,
  listNotices,
  listSalaries,
  listTeachers,
  listUsers,
} from './db.js';
import { findMedia, poolSummary } from './media.js';
import type { HomeData } from '../views/public.js';
import type { DashboardProps, MediaItemView, UserView } from '../views/dashboard.js';

/** Bundled artwork is addressed with a `static:` prefix so it never needs D1. */
export function mediaUrl(mediaId: string | null | undefined): string {
  const id = String(mediaId ?? '');
  if (!id) return '';
  if (id.startsWith('static:')) return `/img/${id.slice(7)}`;
  return `/api/media/${encodeURIComponent(id)}`;
}

export async function publicData(env: Env): Promise<HomeData> {
  const [settings, classes, notices, galleries, galleryItems, events] = await Promise.all([
    getSettings(env),
    listClasses(env),
    listNotices(env, { audience: ['all', 'public'], limit: 30 }),
    listGalleries(env),
    listGalleryItems(env),
    listEvents(env),
  ]);

  return {
    settings,
    classes,
    notices,
    events,
    galleries: galleries.map((g) => ({
      ...g,
      items: galleryItems.filter((it) => it.gallery_id === g.id),
    })),
    mediaUrl,
  };
}

async function mediaView(env: Env, id: string | undefined | null): Promise<MediaItemView | null> {
  const key = String(id ?? '');
  if (!key) return null;
  if (key.startsWith('static:')) {
    return { id: key, caption: key.slice(7), url: mediaUrl(key), shard: 0, bytes: 0 };
  }
  const rec = await findMedia(env, key);
  if (!rec) return null;
  return { id: rec.id, caption: rec.label, url: mediaUrl(rec.id), shard: rec.shard_id, bytes: rec.size_bytes };
}

export async function dashboardData(env: Env, user: SessionUser): Promise<DashboardProps> {
  const settings = await getSettings(env);
  const [classes, notices, galleries, galleryItems, events, stats] = await Promise.all([
    listClasses(env),
    listNotices(env, {
      audience: user.role === 'teacher' ? ['all', 'public', 'staff', 'class'] : ['all', 'public', 'staff', 'class'],
      limit: 80,
    }),
    listGalleries(env),
    listGalleryItems(env),
    listEvents(env),
    dashboardStats(env),
  ]);

  const isStaff = user.role === 'super_admin' || user.role === 'co_admin';
  const [teachers, assignments, salaries, attendance, users, enquiries, pool] = await Promise.all([
    isStaff ? listTeachers(env) : Promise.resolve([]),
    listAssignments(env, user.role === 'teacher' && user.teacher_id ? user.teacher_id : undefined),
    user.role === 'teacher' ? listSalaries(env, user.teacher_id ?? -1) : listSalaries(env),
    user.role === 'teacher'
      ? listAttendance(env, user.teacher_id ?? -1, 60)
      : isStaff
        ? listAttendance(env, undefined, 120)
        : Promise.resolve([]),
    user.role === 'super_admin' ? listUsers(env) : Promise.resolve([]),
    isStaff || user.role === 'teacher' ? listEnquiries(env) : Promise.resolve([]),
    user.role === 'super_admin' ? poolSummary(env) : Promise.resolve(null),
  ]);

  // Teacher salary aggregate must only reflect their own records.
  const statsForRole =
    user.role === 'teacher'
      ? {
          ...stats,
          salaryTotal: salaries.reduce((a, s) => a + Number(s.amount), 0),
          salaryThisMonth: salaries
            .filter((s) => String(s.month).startsWith(new Date().toISOString().slice(0, 7)))
            .reduce((a, s) => a + Number(s.amount), 0),
        }
      : stats;

  const usersView: UserView[] = (users as Array<UserView & { teacher_id?: number | null }>).map((u) => ({
    id: u.id,
    username: u.username,
    full_name: u.full_name,
    role: u.role,
    active: u.active,
    must_change_password: u.must_change_password,
    teacher_id: u.teacher_id ?? null,
    created_at: u.created_at,
  }));

  const [logo, hero, about] = await Promise.all([
    mediaView(env, settings.logo_media_id),
    mediaView(env, settings.hero_media_id),
    mediaView(env, settings.about_media_id),
  ]);

  return {
    user,
    schoolName: settings.school_name,
    shortName: settings.short_name,
    tagline: settings.tagline,
    logo: logo?.url || '/img/logo.jpg',
    csrf: '',
    settings,
    classes,
    notices,
    events,
    galleries: galleries.map((g) => ({ ...g, items: galleryItems.filter((it) => it.gallery_id === g.id) })),
    teachers,
    assignments,
    salaries,
    attendance,
    users: usersView,
    enquiries: user.role === 'teacher' ? [] : enquiries,
    stats: statsForRole,
    pool,
    mediaUrl,
    schoolMedia: { logo, hero, about },
  };
}
