/**
 * Cryptography & token helpers.
 *
 * IMPORTANT: Cloudflare Workers rejects PBKDF2 iteration counts above 100,000.
 * Every hash in this project (runtime, migration seed, deploy script) therefore
 * uses EXACTLY 100_000 iterations of PBKDF2-SHA256. Never raise this value.
 */

export const PBKDF2_ITERATIONS = 100_000;
const SALT_BYTES = 16;
const KEY_BITS = 256;

const enc = new TextEncoder();

export function toBase64(bytes: Uint8Array): string {
  let bin = '';
  for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
  return btoa(bin);
}

export function fromBase64(b64: string): Uint8Array {
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

export function randomHex(bytes = 32): string {
  const buf = new Uint8Array(bytes);
  crypto.getRandomValues(buf);
  return Array.from(buf, (b) => b.toString(16).padStart(2, '0')).join('');
}

export function randomBytes(n: number): Uint8Array {
  const buf = new Uint8Array(n);
  crypto.getRandomValues(buf);
  return buf;
}

/** Constant-time comparison for equal-length strings. */
export function safeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

export async function pbkdf2Hash(
  password: string,
  salt?: Uint8Array,
  iterations = PBKDF2_ITERATIONS,
): Promise<string> {
  const saltBytes = salt ?? randomBytes(SALT_BYTES);
  const keyMaterial = await crypto.subtle.importKey(
    'raw',
    enc.encode(password),
    'PBKDF2',
    false,
    ['deriveBits'],
  );
  const bits = await crypto.subtle.deriveBits(
    { name: 'PBKDF2', salt: saltBytes as unknown as BufferSource, iterations, hash: 'SHA-256' },
    keyMaterial,
    KEY_BITS,
  );
  return `pbkdf2$sha256$${iterations}$${toBase64(saltBytes)}$${toBase64(new Uint8Array(bits))}`;
}

export async function pbkdf2Verify(password: string, stored: string): Promise<boolean> {
  if (!stored) return false;
  const parts = stored.split('$');
  if (parts.length !== 5 || parts[0] !== 'pbkdf2') return false;
  const iterations = Number(parts[2]);
  if (!Number.isFinite(iterations) || iterations <= 0) return false;
  // Workers hard-caps PBKDF2 at 100,000 — never attempt a larger count.
  if (iterations > PBKDF2_ITERATIONS) return false;
  const salt = fromBase64(parts[3]);
  const candidate = await pbkdf2Hash(password, salt, iterations);
  return safeEqual(candidate, stored);
}

async function hmacKey(secret: string): Promise<CryptoKey> {
  return crypto.subtle.importKey(
    'raw',
    enc.encode(secret),
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign', 'verify'],
  );
}

export async function hmacHex(secret: string, data: string): Promise<string> {
  const key = await hmacKey(secret);
  const sig = await crypto.subtle.sign('HMAC', key, enc.encode(data));
  return Array.from(new Uint8Array(sig), (b) => b.toString(16).padStart(2, '0')).join('');
}

export async function hmacVerify(secret: string, data: string, mac: string): Promise<boolean> {
  const expected = await hmacHex(secret, data);
  return safeEqual(expected, mac);
}

/** Signed session cookie value: `<sid>.<hmac>` — tamper evident before any D1 hit. */
export async function signSessionId(secret: string, sid: string): Promise<string> {
  return `${sid}.${await hmacHex(secret, `session:${sid}`)}`;
}

export async function unsignSessionId(secret: string, cookie: string): Promise<string | null> {
  const idx = cookie.lastIndexOf('.');
  if (idx <= 0) return null;
  const sid = cookie.slice(0, idx);
  const mac = cookie.slice(idx + 1);
  if (!/^[0-9a-f]{32,128}$/.test(sid)) return null;
  return (await hmacVerify(secret, `session:${sid}`, mac)) ? sid : null;
}

/**
 * CSRF token: `<expiryMs>.<nonce>.<hmac>` — stateless, 2 hour lifetime,
 * optionally bound to a session id so a token cannot be replayed across users.
 */
export async function createCsrfToken(secret: string, sid = 'anon', ttlMs = 2 * 3600_000): Promise<string> {
  const exp = Date.now() + ttlMs;
  const nonce = randomHex(8);
  const body = `${exp}.${nonce}.${sid}`;
  return `${exp}.${nonce}.${await hmacHex(secret, `csrf:${body}`)}`;
}

export async function verifyCsrfToken(secret: string, token: string, sid = 'anon'): Promise<boolean> {
  if (!token) return false;
  const parts = token.split('.');
  if (parts.length !== 3) return false;
  const [expStr, nonce, mac] = parts;
  const exp = Number(expStr);
  if (!Number.isFinite(exp) || exp < Date.now()) return false;
  return hmacVerify(secret, `csrf:${expStr}.${nonce}.${sid}`, mac);
}

/** HTML entity escaping for anything interpolated into SSR markup. */
export function escapeHtml(input: unknown): string {
  if (input === null || input === undefined) return '';
  return String(input)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

/** Escape for inline <script type="application/json"> payloads. */
export function escapeJsonForScript(value: unknown): string {
  return JSON.stringify(value)
    .replace(/</g, '\\u003c')
    .replace(/>/g, '\\u003e')
    .replace(/&/g, '\\u0026')
    .replace(/\u2028/g, '\\u2028')
    .replace(/\u2029/g, '\\u2029');
}

/** Strip anything that could break out of a CSS/URL context (media, links). */
export function safeUrl(input: unknown, fallback = ''): string {
  const raw = String(input ?? '').trim();
  if (!raw) return fallback;
  if (/^(https?:|mailto:|tel:|\/(?!\/)|#)/i.test(raw)) return raw;
  return fallback;
}
