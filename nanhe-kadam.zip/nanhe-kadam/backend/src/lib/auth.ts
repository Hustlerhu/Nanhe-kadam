/**
 * Session, RBAC and request-authentication helpers.
 * The cookie is HttpOnly + Secure + SameSite=Strict and HMAC-SHA256 signed, so a
 * tampered cookie is rejected before any database lookup happens.
 */
import type { Env, Role, SessionUser } from '../env.js';
import { createCsrfToken, randomHex, signSessionId, unsignSessionId, verifyCsrfToken } from './crypto.js';
import { parseCookies, serializeCookie, clientIp } from './http.js';
import { createSession, destroySession, getSession, toSessionUser } from './db.js';
import type { UserRow } from './db.js';

export const SESSION_COOKIE = 'nk_sess';
export const SESSION_TTL_HOURS = 12;

export function sessionSecret(env: Env): string {
  return env.SESSION_SECRET && env.SESSION_SECRET.length >= 16
    ? env.SESSION_SECRET
    : 'nk_dev_session_secret_do_not_use_in_production_0001';
}

export function csrfSecret(env: Env): string {
  return env.CSRF_SECRET && env.CSRF_SECRET.length >= 16
    ? env.CSRF_SECRET
    : 'nk_dev_csrf_secret_do_not_use_in_production_0001';
}

export interface AuthContext {
  sid: string;
  user: SessionUser;
}

/** Resolve the signed-in user from the request cookie, or null. */
export async function loadSession(env: Env, request: Request): Promise<AuthContext | null> {
  const cookies = parseCookies(request);
  const raw = cookies[SESSION_COOKIE];
  if (!raw) return null;
  const sid = await unsignSessionId(sessionSecret(env), raw);
  if (!sid) return null;
  const row = await getSession(env, sid);
  if (!row) return null;
  const user = toSessionUser(row as unknown as UserRow, row.teacher_id ?? null);
  return { sid, user };
}

export async function startSession(env: Env, request: Request, user: UserRow): Promise<string> {
  const sid = randomHex(32);
  await createSession(env, sid, user.id, clientIp(request), request.headers.get('User-Agent') ?? '', SESSION_TTL_HOURS);
  const signed = await signSessionId(sessionSecret(env), sid);
  return serializeCookie(SESSION_COOKIE, signed, {
    maxAge: SESSION_TTL_HOURS * 3600,
    httpOnly: true,
    secure: true,
    sameSite: 'Strict',
    path: '/',
  });
}

export async function endSession(env: Env, sid: string | null): Promise<string> {
  if (sid) await destroySession(env, sid).catch(() => undefined);
  return serializeCookie(SESSION_COOKIE, '', { maxAge: 0, httpOnly: true, secure: true, sameSite: 'Strict', path: '/' });
}

export function canManageUsers(role: Role | undefined): boolean {
  return role === 'super_admin';
}

export function canManageContent(role: Role | undefined): boolean {
  return role === 'super_admin' || role === 'co_admin';
}

export function canUploadMedia(role: Role | undefined): boolean {
  return role === 'super_admin' || role === 'co_admin' || role === 'teacher';
}

export function canManageStaff(role: Role | undefined): boolean {
  return role === 'super_admin' || role === 'co_admin';
}

export async function issueCsrf(env: Env, sid = 'anon'): Promise<string> {
  return createCsrfToken(csrfSecret(env), sid);
}

export async function checkCsrf(env: Env, _request: Request, token: unknown, sid = 'anon'): Promise<boolean> {
  const value = typeof token === 'string' ? token : '';
  if (!value) return false;
  return verifyCsrfToken(csrfSecret(env), value, sid);
}

/** Constant-ish delay to blunt username-enumeration timing differences. */
export function timingNoise(): Promise<void> {
  const ms = 60 + Math.floor(Math.random() * 60);
  return new Promise((r) => setTimeout(r, ms));
}
