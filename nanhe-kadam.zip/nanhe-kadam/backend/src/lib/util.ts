/** Shared small utilities used by both the Worker and the test harness. */
export function nowIso(): string {
  return new Date().toISOString();
}

export function toInt(value: unknown, fallback = 0): number {
  const n = Number(value);
  return Number.isFinite(n) ? Math.trunc(n) : fallback;
}

export function clamp(n: number, lo: number, hi: number): number {
  return Math.min(hi, Math.max(lo, n));
}

export function slugId(prefix: string): string {
  const buf = new Uint8Array(9);
  crypto.getRandomValues(buf);
  const s = Array.from(buf, (b) => b.toString(36).padStart(2, '0')).join('');
  return `${prefix}_${s.slice(0, 16)}`;
}

/** "12 Nov 2026" style label used across the public site. */
export function formatDate(iso: string): string {
  if (!iso) return '';
  const d = new Date(iso.length <= 10 ? `${iso}T00:00:00Z` : iso);
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric', timeZone: 'UTC' });
}

export function monthAbbr(iso: string): { day: string; month: string } {
  if (!iso) return { day: '', month: '' };
  const d = new Date(iso.length <= 10 ? `${iso}T00:00:00Z` : iso);
  if (Number.isNaN(d.getTime())) return { day: '', month: '' };
  return {
    day: d.toLocaleDateString('en-GB', { day: '2-digit', timeZone: 'UTC' }),
    month: d.toLocaleDateString('en-GB', { month: 'short', timeZone: 'UTC' }),
  };
}

export function rupees(n: number): string {
  return `₹${Math.round(n).toLocaleString('en-IN')}`;
}

export function megabytes(bytes: number, digits = 1): string {
  return (bytes / (1024 * 1024)).toFixed(digits);
}
