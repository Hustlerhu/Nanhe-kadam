/**
 * HTTP helpers: JSON envelopes, cookies, security headers, rate limiting.
 */
import { escapeHtml } from './crypto.js';

export const SECURITY_HEADERS: Record<string, string> = {
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'no-referrer',
  'Permissions-Policy':
    'geolocation=(), microphone=(), camera=(), payment=(), usb=(), magnetometer=(), gyroscope=(), accelerometer=(), interest-cohort=()',
  'Cross-Origin-Opener-Policy': 'same-origin',
  'Cross-Origin-Resource-Policy': 'same-origin',
  'X-Permitted-Cross-Domain-Policies': 'none',
  'X-DNS-Prefetch-Control': 'off',
  'Strict-Transport-Security': 'max-age=31536000; includeSubDomains; preload',
  // Never advertise the runtime.
  'X-Powered-By': 'Nanhe Kadam',
  Server: 'NK',
};

export function cspHeader(nonce?: string): string {
  // Documents get a per-response nonce. Sub-resources (JS, CSS, images, JSON)
  // get the same policy with no nonce at all, so no inline script can ever run
  // in a response that was not rendered by us.
  // NOTE on 'strict-dynamic': it disables host-source allowlists entirely, so
  // `'self'` would stop working for our own <script src> tags (they are not
  // nonce-stamped). We keep the per-response nonce for inline safety and keep
  // `'self'` working for the external bundles; there is no 'unsafe-inline' and
  // no 'unsafe-eval' anywhere.
  const scriptSrc = nonce ? `script-src 'self' 'nonce-${nonce}'` : "script-src 'self'";
  return [
    "default-src 'self'",
    // Only our own minified bundles + the per-response nonce. No 'unsafe-inline',
    // no eval, no third-party script origins.
    scriptSrc,
    // Inline *style attributes* are used for dynamic values (meter widths, transforms);
    // no inline <style> element or @import is ever emitted.
    "style-src 'self' 'unsafe-inline'",
    "style-src-attr 'unsafe-inline'",
    "img-src 'self' data: blob: https:",
    "media-src 'self' data: blob:",
    "font-src 'self' data:",
    "connect-src 'self'",
    "form-action 'self'",
    "frame-src 'self' https://www.google.com https://maps.google.com",
    "frame-ancestors 'none'",
    "base-uri 'none'",
    "object-src 'none'",
    "manifest-src 'self'",
    "worker-src 'self'",
    "require-trusted-types-for 'script'",
    'upgrade-insecure-requests',
  ].join('; ');
}

export function withSecurity(headers: HeadersInit = {}, nonce?: string): Headers {
  const h = new Headers(headers);
  for (const [k, v] of Object.entries(SECURITY_HEADERS)) h.set(k, v);
  // Every single response carries a CSP — documents with a nonce, all other
  // sub-resources and error envelopes with the strict non-nonce variant.
  h.set('Content-Security-Policy', cspHeader(nonce));
  return h;
}

export function json(data: unknown, status = 200, extra: Record<string, string> = {}): Response {
  return new Response(JSON.stringify(data), {
    status,
    headers: withSecurity({
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-store',
      ...extra,
    }),
  });
}

export function ok<T>(data: T, status = 200): Response {
  return json({ ok: true, data }, status);
}

export function fail(message: string, status = 400, code?: string): Response {
  return json({ ok: false, error: scrubError(message, status), code: code ?? undefined }, status);
}

/** Removes any runtime/SQL detail before a message can reach a client. */
export function scrubError(message: string, status: number): string {
  if (status < 500) return message;
  // 5xx must never reveal the database, the runtime or our internals.
  if (/sqlite|d1_|sql|binding|stack|at\s+\w+\s*\(|workers|cloudflare/i.test(message)) {
    return 'Something went wrong on the server. Please try again.';
  }
  return message || 'Something went wrong on the server. Please try again.';
}

/** Uniform, non-revealing error page. */
export function errorPage(status: number): { title: string; detail: string } {
  if (status === 404) return { title: 'Page not found', detail: 'That page has moved or no longer exists.' };
  if (status === 403) return { title: 'Access denied', detail: 'You do not have permission to view this page.' };
  if (status === 401) return { title: 'Sign in required', detail: 'Please sign in to continue.' };
  if (status === 429) return { title: 'Too many requests', detail: 'Please wait a few minutes and try again.' };
  return { title: 'Temporary problem', detail: 'Please refresh in a moment.' };
}

export function html(body: string, status = 200, nonce = '', extra: Record<string, string> = {}): Response {
  return new Response(body, {
    status,
    headers: withSecurity(
      {
        'Content-Type': 'text/html; charset=utf-8',
        'Cache-Control': 'no-store',
        ...extra,
      },
      nonce,
    ),
  });
}

export function redirect(location: string, status = 302, extra: HeadersInit = {}): Response {
  const h = withSecurity(extra as Record<string, string>);
  h.set('Location', location);
  return new Response(null, { status, headers: h });
}

export function parseCookies(request: Request): Record<string, string> {
  const raw = request.headers.get('Cookie');
  const out: Record<string, string> = {};
  if (!raw) return out;
  for (const part of raw.split(';')) {
    const idx = part.indexOf('=');
    if (idx === -1) continue;
    const k = part.slice(0, idx).trim();
    const v = part.slice(idx + 1).trim();
    if (k) out[k] = decodeURIComponent(v);
  }
  return out;
}

export function serializeCookie(
  name: string,
  value: string,
  opts: { maxAge?: number; httpOnly?: boolean; secure?: boolean; sameSite?: string; path?: string } = {},
): string {
  const parts = [`${name}=${encodeURIComponent(value)}`];
  parts.push(`Path=${opts.path ?? '/'}`);
  if (opts.maxAge !== undefined) parts.push(`Max-Age=${opts.maxAge}`);
  if (opts.httpOnly !== false) parts.push('HttpOnly');
  if (opts.secure !== false) parts.push('Secure');
  parts.push(`SameSite=${opts.sameSite ?? 'Strict'}`);
  return parts.join('; ');
}

/** Same-origin guard for state-changing requests (defence in depth beside CSRF). */
export function isSameOrigin(request: Request, baseUrl: string): boolean {
  const source = request.headers.get('Origin') ?? request.headers.get('Referer');
  if (!source) return true; // non-browser clients (curl / tests) — CSRF token still required
  try {
    const a = new URL(source).host;
    const b = new URL(baseUrl || request.url).host;
    const self = new URL(request.url).host;
    return a === b || a === self;
  } catch {
    return false;
  }
}

export async function readJson<T = Record<string, unknown>>(request: Request): Promise<T | null> {
  const ct = request.headers.get('Content-Type') ?? '';
  if (!ct.includes('application/json')) return null;
  try {
    const body = await request.json();
    return body && typeof body === 'object' ? (body as T) : null;
  } catch {
    return null;
  }
}

export function clientIp(request: Request): string {
  return (
    request.headers.get('CF-Connecting-IP') ??
    request.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ??
    '0.0.0.0'
  );
}

/**
 * Fixed-window D1 rate limiter. Returns true when the caller is still allowed.
 * Cheap: single UPSERT, string keys, pruned opportunistically.
 */
export async function rateLimit(
  db: D1DatabaseLike,
  key: string,
  limit: number,
  windowSeconds: number,
): Promise<{ allowed: boolean; remaining: number }> {
  const now = Date.now();
  const windowMs = windowSeconds * 1000;
  const bucket = Math.floor(now / windowMs);
  const rowKey = `${key}:${bucket}`;
  try {
    await db
      .prepare(
        `INSERT INTO rate_limits (key, count, expires_at) VALUES (?, 1, ?)
         ON CONFLICT(key) DO UPDATE SET count = count + 1`,
      )
      .bind(rowKey, new Date((bucket + 1) * windowMs + 60_000).toISOString())
      .run();
    const row = await db
      .prepare('SELECT count FROM rate_limits WHERE key = ?')
      .bind(rowKey)
      .first<{ count: number }>();
    const count = Number(row?.count ?? 1);
    if (Math.random() < 0.05) {
      await db
        .prepare('DELETE FROM rate_limits WHERE expires_at < ?')
        .bind(new Date(now).toISOString())
        .run()
        .catch(() => undefined);
    }
    return { allowed: count <= limit, remaining: Math.max(0, limit - count) };
  } catch {
    return { allowed: true, remaining: limit }; // never lock users out on limiter failure
  }
}

export function errMessage(e: unknown): string {
  if (e instanceof Error) return e.message;
  return String(e);
}

export { escapeHtml };
