/**
 * Data access layer — 100% parameterised queries (db.prepare(...).bind(...)).
 * Every helper returns plain JSON-safe objects so the SSR payload and the
 * portal API can share one contract.
 */
import type { Env, Role, SessionUser } from '../env.js';
import { nowIso, toInt } from './util.js';

export const SETTING_DEFAULTS: Record<string, string> = {
  school_name: 'Nanhe Kadam Public School',
  short_name: 'Nanhe Kadam',
  tagline: 'Public School',
  hero_headline: 'A Great Start for a Bright Future',
  hero_sub:
    "A safe, caring and creative environment where every child's first steps into education feel joyful.",
  about_title: 'About Our School',
  about_text:
    'Nanhe Kadam Public School is a nurturing space where young minds begin their journey of learning with joy, confidence and care. Guided by experienced teachers and a disciplined, values-first culture, we help children from Play Class to Class 5 grow academically, socially and emotionally — right here in Chorawa Icha, beside the well-known schools of the area.',
  address: 'Near Sudha Factory, Chorawa Icha, Bihar',
  map_embed:
    'https://www.google.com/maps?q=Chorawa+Icha+Bihar&output=embed',
  map_directions: 'https://www.google.com/maps/search/?api=1&query=Chorawa+Icha+Bihar',
  phone: '+91 95591 04341',
  email: 'nanhekadam@gmail.com',
  opening_date: '2026-11-11',
  principal: 'Amita Kumari',
  director: 'R K',
  play_learn_grow: 'Play • Learn • Grow',
  logo_media_id: '',
  hero_media_id: '',
  about_media_id: '',
  admissions_open: '1',
  admissions_note: 'Admissions open for Play Class to Class 5. Limited seats per section.',
  whatsapp_number: '919559104341',
  whatsapp_message: 'Namaste! I would like to know more about admission at Nanhe Kadam Public School.',
  whatsapp_enabled: '1',
  instagram_url: 'https://instagram.com/',
  instagram_handle: '@nanhekadam',
  instagram_enabled: '1',
  facebook_url: 'https://facebook.com/',
  facebook_handle: '/nanhekadam',
  facebook_enabled: '1',
  youtube_url: 'https://youtube.com/',
  youtube_handle: '@nanhekadam',
  youtube_enabled: '1',
  footer_note: 'Dream Big… Learn Big…',
};

export const CLASS_SEED = [
  { slug: 'play-class', name: 'Play Class', age: '2.5 – 3.5 yrs', summary: 'First friends, first songs, first smiles.' },
  { slug: 'nursery', name: 'Nursery', age: '3 – 4 yrs', summary: 'Rhymes, colours and confident little steps.' },
  { slug: 'lkg', name: 'LKG', age: '4 – 5 yrs', summary: 'Letters, numbers and lots of hands-on play.' },
  { slug: 'ukg', name: 'UKG', age: '5 – 6 yrs', summary: 'Reading readiness and school discipline.' },
  { slug: 'class-1', name: 'Class 1', age: '6 – 7 yrs', summary: 'Strong foundations in English, Hindi and Maths.' },
  { slug: 'class-2', name: 'Class 2', age: '7 – 8 yrs', summary: 'Curiosity, comprehension and neat handwriting.' },
  { slug: 'class-3', name: 'Class 3', age: '8 – 9 yrs', summary: 'Project work, reading fluency and reasoning.' },
  { slug: 'class-4', name: 'Class 4', age: '9 – 10 yrs', summary: 'Independent study habits and confidence.' },
  { slug: 'class-5', name: 'Class 5', age: '10 – 11 yrs', summary: 'CBSE-ready learners, ready for the next big step.' },
];

export type Settings = Record<string, string>;

export async function getSettings(env: Env): Promise<Settings> {
  const rows = await env.DB.prepare('SELECT key, value FROM settings').all<{ key: string; value: string }>();
  const out: Settings = { ...SETTING_DEFAULTS };
  for (const r of rows.results ?? []) {
    if (r.key) out[r.key] = r.value ?? '';
  }
  return out;
}

export async function setSettings(env: Env, patch: Record<string, string>): Promise<void> {
  const entries = Object.entries(patch).filter(([k]) => /^[a-z0-9_]{2,40}$/.test(k));
  if (!entries.length) return;
  const stmts = entries.map(([k, v]) =>
    env.DB.prepare(
      'INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value',
    ).bind(k, String(v ?? '').slice(0, 4000)),
  );
  for (let i = 0; i < stmts.length; i += 25) await env.DB.batch(stmts.slice(i, i + 25));
}

/* ------------------------------- classes ------------------------------- */

export interface ClassRow {
  id: number;
  slug: string;
  name: string;
  age_group: string;
  summary: string;
  image_media_id: string;
  sort_order: number;
  active: number;
}

export async function listClasses(env: Env): Promise<ClassRow[]> {
  const r = await env.DB.prepare('SELECT * FROM classes ORDER BY sort_order ASC, id ASC').all<ClassRow>();
  return r.results ?? [];
}

/* ------------------------------- notices ------------------------------- */

export interface NoticeRow {
  id: number;
  title: string;
  body: string;
  date: string;
  is_new: number;
  pinned: number;
  audience: string;
  author_id: number | null;
  created_at: string;
}

export async function listNotices(env: Env, opts: { audience?: string[]; limit?: number } = {}): Promise<NoticeRow[]> {
  const audiences = opts.audience ?? ['all', 'public'];
  const placeholders = audiences.map(() => '?').join(',');
  const limit = Math.min(Math.max(opts.limit ?? 50, 1), 200);
  const r = await env.DB.prepare(
    `SELECT * FROM notices WHERE audience IN (${placeholders})
     ORDER BY pinned DESC, date DESC, id DESC LIMIT ${limit}`,
  )
    .bind(...audiences)
    .all<NoticeRow>();
  return r.results ?? [];
}

/* ------------------------------- galleries ------------------------------ */

export interface GalleryRow {
  id: number;
  slug: string;
  title: string;
  subtitle: string;
  sort_order: number;
}

export interface GalleryItemRow {
  id: number;
  gallery_id: number;
  media_id: string;
  caption: string;
  sort_order: number;
  created_at: string;
  mime: string | null;
  size_bytes: number | null;
  shard_id: number | null;
}

export async function listGalleries(env: Env): Promise<GalleryRow[]> {
  const r = await env.DB.prepare('SELECT * FROM galleries ORDER BY sort_order ASC, id ASC').all<GalleryRow>();
  return r.results ?? [];
}

export async function listGalleryItems(env: Env, galleryId?: number): Promise<GalleryItemRow[]> {
  const sql = galleryId
    ? `SELECT gi.*, mi.mime, mi.size_bytes, mi.shard_id
       FROM gallery_items gi LEFT JOIN media_index mi ON mi.id = gi.media_id
       WHERE gi.gallery_id = ? ORDER BY gi.sort_order ASC, gi.id ASC`
    : `SELECT gi.*, mi.mime, mi.size_bytes, mi.shard_id
       FROM gallery_items gi LEFT JOIN media_index mi ON mi.id = gi.media_id
       ORDER BY gi.gallery_id ASC, gi.sort_order ASC, gi.id ASC`;
  const stmt = env.DB.prepare(sql);
  const r = galleryId ? await stmt.bind(galleryId).all<GalleryItemRow>() : await stmt.all<GalleryItemRow>();
  return r.results ?? [];
}

/* -------------------------------- events ------------------------------- */

export interface EventRow {
  id: number;
  title: string;
  date: string;
  description: string;
  media_id: string;
  is_featured: number;
}

export async function listEvents(env: Env): Promise<EventRow[]> {
  const r = await env.DB.prepare('SELECT * FROM events ORDER BY date DESC, id DESC').all<EventRow>();
  return r.results ?? [];
}

/* -------------------------------- users -------------------------------- */

export interface UserRow {
  id: number;
  username: string;
  password_hash: string;
  role: Role;
  full_name: string;
  must_change_password: number;
  active: number;
  created_at: string;
}

export async function findUserByUsername(env: Env, username: string): Promise<UserRow | null> {
  return env.DB.prepare('SELECT * FROM users WHERE username = ? COLLATE NOCASE').bind(username).first<UserRow>();
}

export async function findUserById(env: Env, id: number): Promise<UserRow | null> {
  return env.DB.prepare('SELECT * FROM users WHERE id = ?').bind(id).first<UserRow>();
}

export async function listUsers(env: Env): Promise<Array<Omit<UserRow, 'password_hash'> & { teacher_id: number | null }>> {
  const r = await env.DB.prepare(
    `SELECT u.id, u.username, u.role, u.full_name, u.must_change_password, u.active, u.created_at,
            (SELECT t.id FROM teachers t WHERE t.user_id = u.id LIMIT 1) AS teacher_id
     FROM users u ORDER BY CASE u.role WHEN 'super_admin' THEN 0 WHEN 'co_admin' THEN 1 ELSE 2 END, u.id ASC`,
  ).all<Omit<UserRow, 'password_hash'> & { teacher_id: number | null }>();
  return r.results ?? [];
}

export function toSessionUser(u: UserRow, teacherId: number | null = null): SessionUser {
  return {
    id: toInt(u.id),
    username: u.username,
    full_name: u.full_name,
    role: u.role,
    must_change_password: toInt(u.must_change_password),
    teacher_id: teacherId,
  };
}

/* ------------------------------- sessions ------------------------------ */

export interface SessionRow {
  id: string;
  user_id: number;
  created_at: string;
  expires_at: string;
  ip: string;
  user_agent: string;
}

export async function createSession(
  env: Env,
  sid: string,
  userId: number,
  ip: string,
  userAgent: string,
  ttlHours = 12,
): Promise<void> {
  const expires = new Date(Date.now() + ttlHours * 3600_000).toISOString();
  await env.DB.prepare(
    'INSERT INTO sessions (id, user_id, created_at, expires_at, ip, user_agent) VALUES (?, ?, ?, ?, ?, ?)',
  )
    .bind(sid, userId, nowIso(), expires, ip.slice(0, 64), userAgent.slice(0, 200))
    .run();
  await env.DB.prepare('DELETE FROM sessions WHERE expires_at < ?').bind(nowIso()).run().catch(() => undefined);
}

export async function getSession(env: Env, sid: string): Promise<(SessionRow & UserRow & { teacher_id: number | null }) | null> {
  return env.DB.prepare(
    `SELECT s.id AS session_id, s.user_id, s.created_at AS session_created, s.expires_at, s.ip, s.user_agent,
            u.id, u.username, u.password_hash, u.role, u.full_name, u.must_change_password, u.active, u.created_at,
            (SELECT t.id FROM teachers t WHERE t.user_id = u.id LIMIT 1) AS teacher_id
     FROM sessions s JOIN users u ON u.id = s.user_id
     WHERE s.id = ? AND s.expires_at > ? AND u.active = 1`,
  )
    .bind(sid, nowIso())
    .first<SessionRow & UserRow & { teacher_id: number | null }>();
}

export async function destroySession(env: Env, sid: string): Promise<void> {
  await env.DB.prepare('DELETE FROM sessions WHERE id = ?').bind(sid).run();
}

/* ------------------------------- teachers ------------------------------ */

export interface TeacherRow {
  id: number;
  user_id: number | null;
  full_name: string;
  designation: string;
  phone: string;
  email: string;
  qualification: string;
  joined_on: string;
  monthly_salary: number;
  active: number;
  created_at: string;
  username?: string | null;
  class_count?: number;
  salary_total?: number;
}

export async function listTeachers(env: Env): Promise<TeacherRow[]> {
  const r = await env.DB.prepare(
    `SELECT t.*, u.username,
            (SELECT COUNT(*) FROM teacher_assignments a WHERE a.teacher_id = t.id) AS class_count,
            (SELECT COALESCE(SUM(s.amount), 0) FROM teacher_salaries s WHERE s.teacher_id = t.id) AS salary_total
     FROM teachers t LEFT JOIN users u ON u.id = t.user_id
     ORDER BY t.active DESC, t.full_name ASC`,
  ).all<TeacherRow>();
  return r.results ?? [];
}

export async function getTeacher(env: Env, id: number): Promise<TeacherRow | null> {
  return env.DB.prepare('SELECT * FROM teachers WHERE id = ?').bind(id).first<TeacherRow>();
}

export interface AssignmentRow {
  id: number;
  teacher_id: number;
  class_id: number;
  subject: string;
  class_name?: string;
  class_slug?: string;
}

export async function listAssignments(env: Env, teacherId?: number): Promise<AssignmentRow[]> {
  const sql = `SELECT a.*, c.name AS class_name, c.slug AS class_slug
               FROM teacher_assignments a JOIN classes c ON c.id = a.class_id
               ${teacherId ? 'WHERE a.teacher_id = ?' : ''}
               ORDER BY c.sort_order ASC`;
  const stmt = env.DB.prepare(sql);
  const r = teacherId ? await stmt.bind(teacherId).all<AssignmentRow>() : await stmt.all<AssignmentRow>();
  return r.results ?? [];
}

export interface SalaryRow {
  id: number;
  teacher_id: number;
  month: string;
  amount: number;
  paid_on: string;
  note: string;
}

export async function listSalaries(env: Env, teacherId?: number): Promise<SalaryRow[]> {
  const sql = teacherId
    ? 'SELECT * FROM teacher_salaries WHERE teacher_id = ? ORDER BY month DESC'
    : 'SELECT * FROM teacher_salaries ORDER BY month DESC, id DESC';
  const stmt = env.DB.prepare(sql);
  const r = teacherId ? await stmt.bind(teacherId).all<SalaryRow>() : await stmt.all<SalaryRow>();
  return r.results ?? [];
}

export interface AttendanceRow {
  id: number;
  teacher_id: number;
  day: string;
  status: string;
}

export async function listAttendance(env: Env, teacherId?: number, limit = 120): Promise<AttendanceRow[]> {
  const lim = Math.min(Math.max(limit, 1), 400);
  const sql = teacherId
    ? `SELECT * FROM teacher_attendance WHERE teacher_id = ? ORDER BY day DESC LIMIT ${lim}`
    : `SELECT * FROM teacher_attendance ORDER BY day DESC LIMIT ${lim}`;
  const stmt = env.DB.prepare(sql);
  const r = teacherId ? await stmt.bind(teacherId).all<AttendanceRow>() : await stmt.all<AttendanceRow>();
  return r.results ?? [];
}

/**
 * Atomic cascading delete: teacher + salaries + attendance + assignments +
 * their media (index rows and shard chunks) + their sessions.
 */
export async function deleteTeacherCascade(env: Env, teacherId: number): Promise<void> {
  const teacher = await getTeacher(env, teacherId);
  const mediaRows = await env.DB.prepare(
    `SELECT id FROM media_index WHERE teacher_id = ?
     UNION SELECT media_id AS id FROM gallery_items WHERE media_id IN
       (SELECT id FROM media_index WHERE teacher_id = ?)`,
  )
    .bind(teacherId, teacherId)
    .all<{ id: string }>();

  const { deleteMedia } = await import('./media.js');
  for (const row of mediaRows.results ?? []) {
    await deleteMedia(env, row.id).catch(() => undefined);
  }

  const stmts = [
    env.DB.prepare('DELETE FROM teacher_salaries WHERE teacher_id = ?').bind(teacherId),
    env.DB.prepare('DELETE FROM teacher_attendance WHERE teacher_id = ?').bind(teacherId),
    env.DB.prepare('DELETE FROM teacher_assignments WHERE teacher_id = ?').bind(teacherId),
    env.DB.prepare('DELETE FROM gallery_items WHERE media_id IN (SELECT id FROM media_index WHERE teacher_id = ?)').bind(teacherId),
    env.DB.prepare('DELETE FROM media_index WHERE teacher_id = ?').bind(teacherId),
    env.DB.prepare('DELETE FROM teachers WHERE id = ?').bind(teacherId),
  ];
  if (teacher?.user_id) {
    stmts.push(env.DB.prepare('DELETE FROM sessions WHERE user_id = ?').bind(teacher.user_id));
    stmts.push(env.DB.prepare('DELETE FROM users WHERE id = ? AND role = ?').bind(teacher.user_id, 'teacher'));
  }
  await env.DB.batch(stmts);
}

/* ------------------------------ enquiries ------------------------------ */

export interface EnquiryRow {
  id: number;
  parent_name: string;
  child_name: string;
  class_interested: string;
  phone: string;
  email: string;
  message: string;
  status: string;
  created_at: string;
  ip: string;
}

export async function listEnquiries(env: Env): Promise<EnquiryRow[]> {
  const r = await env.DB.prepare('SELECT * FROM enquiries ORDER BY id DESC LIMIT 300').all<EnquiryRow>();
  return r.results ?? [];
}

/* ------------------------------- dashboard ----------------------------- */

export interface DashboardStats {
  teachers: number;
  classes: number;
  notices: number;
  galleries: number;
  photos: number;
  enquiries: number;
  newEnquiries: number;
  salaryTotal: number;
  salaryThisMonth: number;
  attendanceRate: number;
}

export async function dashboardStats(env: Env): Promise<DashboardStats> {
  const month = new Date().toISOString().slice(0, 7);
  const row = await env.DB.prepare(
    `SELECT
       (SELECT COUNT(*) FROM teachers WHERE active = 1) AS teachers,
       (SELECT COUNT(*) FROM classes) AS classes,
       (SELECT COUNT(*) FROM notices) AS notices,
       (SELECT COUNT(*) FROM galleries) AS galleries,
       (SELECT COUNT(*) FROM media_index WHERE shard_id > 0) AS photos,
       (SELECT COUNT(*) FROM enquiries) AS enquiries,
       (SELECT COUNT(*) FROM enquiries WHERE status = 'new') AS new_enquiries,
       (SELECT COALESCE(SUM(amount), 0) FROM teacher_salaries) AS salary_total,
       (SELECT COALESCE(SUM(amount), 0) FROM teacher_salaries WHERE substr(month, 1, 7) = ?) AS salary_month,
       (SELECT COUNT(*) FROM teacher_attendance WHERE status = 'present') AS present_days,
       (SELECT COUNT(*) FROM teacher_attendance) AS all_days`,
  )
    .bind(month)
    .first<Record<string, number>>();
  const allDays = Number(row?.all_days ?? 0);
  return {
    teachers: Number(row?.teachers ?? 0),
    classes: Number(row?.classes ?? 0),
    notices: Number(row?.notices ?? 0),
    galleries: Number(row?.galleries ?? 0),
    photos: Number(row?.photos ?? 0),
    enquiries: Number(row?.enquiries ?? 0),
    newEnquiries: Number(row?.new_enquiries ?? 0),
    salaryTotal: Number(row?.salary_total ?? 0),
    salaryThisMonth: Number(row?.salary_month ?? 0),
    attendanceRate: allDays ? Math.round((Number(row?.present_days ?? 0) / allDays) * 100) : 0,
  };
}

/* -------------------------------- audit -------------------------------- */

export async function audit(
  env: Env,
  userId: number | null,
  action: string,
  target: string,
  ip: string,
): Promise<void> {
  await env.DB.prepare('INSERT INTO audit_log (user_id, action, target, ip, created_at) VALUES (?, ?, ?, ?, ?)')
    .bind(userId, action.slice(0, 80), target.slice(0, 160), ip.slice(0, 64), nowIso())
    .run()
    .catch(() => undefined);
}
