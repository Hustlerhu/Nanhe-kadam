/**
 * 4-Account Cloudflare D1 Distributed Media Pool
 * ==============================================
 * Account 1 (this Worker)  -> Shard 1 : local D1, 500 MB free tier
 * Accounts 2 / 3 / 4       -> Shard 2..4 : remote "Storage Vault" Workers,
 *                                          each with their own 500 MB free D1.
 * Total pool: 2,000 MB at ₹0.
 *
 * D1 limits honoured here
 * -----------------------
 *  • Hard cap: 1 MB per row  -> payloads are split into 512 KB raw chunks whose
 *    base64 encoding is 683 KB, i.e. safely *under* the 700 KB chunk budget and
 *    well under the row limit, so SQLITE_TOOBIG can never be hit.
 *  • Hard cap: 500 MB per DB -> writes go to the first shard below the 430 MB
 *    soft ceiling (leaves headroom for chunks in flight + index rows).
 */
import type { Env } from '../env.js';
import { fromBase64, toBase64 } from './crypto.js';

/** Raw bytes per chunk. base64(512 KB) = 683 KB < 700 KB budget < 1 MB row limit. */
export const CHUNK_SIZE = 512 * 1024;
/** Stop writing to a shard once it passes this (a 500 MB free D1 keeps 70 MB headroom). */
export const SHARD_SOFT_LIMIT_BYTES = 430 * 1024 * 1024;
/** Hard ceiling advertised in the UI for the whole pool. */
export const SHARD_CAPACITY_BYTES = 500 * 1024 * 1024;
export const MAX_UPLOAD_BYTES = 3 * 1024 * 1024; // 3 MB HD photo ceiling
export const STATIC_SHARD = 0; // bundled artwork shipped with the Worker

export interface ShardInfo {
  id: number;
  label: string;
  account: string;
  kind: 'local' | 'vault' | 'static';
  connected: boolean;
  usedBytes: number;
  capacityBytes: number;
  mediaCount: number;
  error?: string;
}

export interface StoredMedia {
  id: string;
  shardId: number;
  mime: string;
  bytes: number;
  chunks: number;
  storageKey: string;
  cacheControl: string;
}

const vaultCache = new Map<string, { at: number; stats: { usedBytes: number; mediaCount: number } | null }>();
const VAULT_STATS_TTL = 45_000;

function vaultConfig(env: Env): Array<{ id: number; url: string; secret: string; account: string }> {
  const rows = [
    { id: 2, url: env.VAULT_2_URL ?? '', secret: env.VAULT_2_SECRET ?? '', account: 'Account 2' },
    { id: 3, url: env.VAULT_3_URL ?? '', secret: env.VAULT_3_SECRET ?? '', account: 'Account 3' },
    { id: 4, url: env.VAULT_4_URL ?? '', secret: env.VAULT_4_SECRET ?? '', account: 'Account 4' },
  ];
  return rows
    .map((r) => ({ ...r, url: normaliseUrl(r.url), secret: r.secret.trim() }))
    .filter((r) => r.url && r.secret);
}

function normaliseUrl(url: string): string {
  const u = url.trim().replace(/\/+$/, '');
  if (!u) return '';
  if (!/^https?:\/\//i.test(u)) return `https://${u}`;
  return u;
}

/* ------------------------------------------------------------------ *
 * Local (Shard 1) read/write
 * ------------------------------------------------------------------ */

async function localStats(db: D1DatabaseLike): Promise<{ usedBytes: number; mediaCount: number }> {
  try {
    const row = await db
      .prepare(
        `SELECT COALESCE(SUM(LENGTH(data)), 0) AS used,
                (SELECT COUNT(*) FROM media) AS n
         FROM media_chunks`,
      )
      .first<{ used: number; n: number }>();
    return { usedBytes: Number(row?.used ?? 0), mediaCount: Number(row?.n ?? 0) };
  } catch {
    return { usedBytes: 0, mediaCount: 0 };
  }
}

async function vaultStats(
  cfg: { url: string; secret: string },
): Promise<{ usedBytes: number; mediaCount: number } | null> {
  const hit = vaultCache.get(cfg.url);
  if (hit && Date.now() - hit.at < VAULT_STATS_TTL) return hit.stats;
  try {
    const res = await fetch(`${cfg.url}/vault/stats`, {
      headers: { 'X-Vault-Secret': cfg.secret },
      signal: AbortSignal.timeout(6000),
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const body = (await res.json()) as { used_bytes?: number; media_count?: number; ok?: boolean };
    const stats = { usedBytes: Number(body.used_bytes ?? 0), mediaCount: Number(body.media_count ?? 0) };
    vaultCache.set(cfg.url, { at: Date.now(), stats });
    return stats;
  } catch {
    vaultCache.set(cfg.url, { at: Date.now(), stats: null });
    return null;
  }
}

/** Full pool snapshot for the Super Admin storage meter. */
export async function shardPool(env: Env, opts: { probe?: boolean } = {}): Promise<ShardInfo[]> {
  const local = await localStats(env.DB);
  const out: ShardInfo[] = [
    {
      id: 1,
      label: 'Vault 1 — Primary Worker',
      account: 'Account 1 (this account)',
      kind: 'local',
      connected: true,
      usedBytes: local.usedBytes,
      capacityBytes: SHARD_CAPACITY_BYTES,
      mediaCount: local.mediaCount,
    },
  ];
  const configs = vaultConfig(env);
  for (let id = 2; id <= 4; id++) {
    const cfg = configs.find((c) => c.id === id);
    if (!cfg) {
      out.push({
        id,
        label: `Vault ${id}`,
        account: `Account ${id}`,
        kind: 'vault',
        connected: false,
        usedBytes: 0,
        capacityBytes: SHARD_CAPACITY_BYTES,
        mediaCount: 0,
        error: 'Not configured',
      });
      continue;
    }
    let stats: { usedBytes: number; mediaCount: number } | null = null;
    if (opts.probe !== false) stats = await vaultStats(cfg);
    else stats = { usedBytes: 0, mediaCount: 0 };
    out.push({
      id,
      label: `Vault ${id} — ${cfg.account}`,
      account: cfg.account,
      kind: 'vault',
      connected: stats !== null,
      usedBytes: stats?.usedBytes ?? 0,
      capacityBytes: SHARD_CAPACITY_BYTES,
      mediaCount: stats?.mediaCount ?? 0,
      error: stats === null ? 'Unreachable' : undefined,
    });
  }
  return out;
}

export interface PoolSummary {
  shards: ShardInfo[];
  usedBytes: number;
  capacityBytes: number;
  percent: number;
  connectedShards: number;
}

export async function poolSummary(env: Env): Promise<PoolSummary> {
  const shards = await shardPool(env);
  const usedBytes = shards.reduce((a, s) => a + s.usedBytes, 0);
  const capacityBytes = shards.reduce((a, s) => a + s.capacityBytes, 0);
  return {
    shards,
    usedBytes,
    capacityBytes,
    percent: capacityBytes ? Math.min(100, (usedBytes / capacityBytes) * 100) : 0,
    connectedShards: shards.filter((s) => s.connected).length,
  };
}

/** First shard with room: local first, then vaults 2 -> 4. */
export async function pickShard(env: Env, neededBytes: number): Promise<number | null> {
  const local = await localStats(env.DB);
  if (local.usedBytes + neededBytes <= SHARD_SOFT_LIMIT_BYTES) return 1;

  for (const cfg of vaultConfig(env)) {
    const stats = await vaultStats(cfg);
    if (!stats) continue;
    if (stats.usedBytes + neededBytes <= SHARD_SOFT_LIMIT_BYTES) return cfg.id;
  }
  return null;
}

/* ------------------------------------------------------------------ *
 * Write / read / delete
 * ------------------------------------------------------------------ */

function splitChunks(bytes: Uint8Array): string[] {
  const chunks: string[] = [];
  for (let i = 0; i < bytes.length; i += CHUNK_SIZE) {
    chunks.push(toBase64(bytes.subarray(i, Math.min(i + CHUNK_SIZE, bytes.length))));
  }
  return chunks.length ? chunks : [''];
}

async function putLocal(
  db: D1DatabaseLike,
  id: string,
  mime: string,
  bytes: Uint8Array,
): Promise<{ chunks: number }> {
  const chunks = splitChunks(bytes);
  const now = new Date().toISOString();
  await db
    .prepare('INSERT OR REPLACE INTO media (id, mime, size_bytes, chunk_count, created_at) VALUES (?, ?, ?, ?, ?)')
    .bind(id, mime, bytes.length, chunks.length, now)
    .run();
  await db.prepare('DELETE FROM media_chunks WHERE media_id = ?').bind(id).run();

  // D1 batch keeps every chunk of one asset in a single atomic transaction.
  const stmts = chunks.map((data, index) =>
    db
      .prepare('INSERT INTO media_chunks (media_id, chunk_index, data) VALUES (?, ?, ?)')
      .bind(id, index, data),
  );
  for (let i = 0; i < stmts.length; i += 20) {
    await db.batch(stmts.slice(i, i + 20));
  }
  return { chunks: chunks.length };
}

async function getLocal(db: D1DatabaseLike, id: string): Promise<{ mime: string; bytes: Uint8Array } | null> {
  const meta = await db
    .prepare('SELECT mime, chunk_count FROM media WHERE id = ?')
    .bind(id)
    .first<{ mime: string; chunk_count: number }>();
  if (!meta) return null;
  const rows = await db
    .prepare('SELECT data FROM media_chunks WHERE media_id = ? ORDER BY chunk_index ASC')
    .bind(id)
    .all<{ data: string }>();
  const list = rows.results ?? [];
  if (!list.length) return null;
  const parts = list.map((r) => fromBase64(r.data));
  const total = parts.reduce((a, p) => a + p.length, 0);
  const out = new Uint8Array(total);
  let off = 0;
  for (const p of parts) {
    out.set(p, off);
    off += p.length;
  }
  return { mime: meta.mime, bytes: out };
}

async function deleteLocal(db: D1DatabaseLike, id: string): Promise<void> {
  await db.prepare('DELETE FROM media_chunks WHERE media_id = ?').bind(id).run();
  await db.prepare('DELETE FROM media WHERE id = ?').bind(id).run();
}

async function putVault(cfg: { url: string; secret: string }, id: string, mime: string, bytes: Uint8Array) {
  const res = await fetch(`${cfg.url}/vault/put`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-Vault-Secret': cfg.secret },
    body: JSON.stringify({ id, mime, data: toBase64(bytes) }),
    signal: AbortSignal.timeout(50_000),
  });
  if (!res.ok) throw new Error(`Vault put failed (${res.status})`);
  vaultCache.delete(cfg.url);
  return (await res.json()) as { chunk_count?: number };
}

async function getVault(cfg: { url: string; secret: string }, id: string) {
  const res = await fetch(`${cfg.url}/vault/get/${encodeURIComponent(id)}`, {
    headers: { 'X-Vault-Secret': cfg.secret },
    signal: AbortSignal.timeout(30_000),
  });
  if (!res.ok) return null;
  const buf = new Uint8Array(await res.arrayBuffer());
  return { mime: res.headers.get('Content-Type') ?? 'application/octet-stream', bytes: buf };
}

async function deleteVault(cfg: { url: string; secret: string }, id: string) {
  await fetch(`${cfg.url}/vault/${encodeURIComponent(id)}`, {
    method: 'DELETE',
    headers: { 'X-Vault-Secret': cfg.secret },
    signal: AbortSignal.timeout(15_000),
  }).catch(() => undefined);
  vaultCache.delete(cfg.url);
}

function vaultFor(env: Env, shardId: number) {
  return vaultConfig(env).find((c) => c.id === shardId) ?? null;
}

/**
 * Store an image in the pool, auto-routing to the first shard with room and
 * recording the location in media_index. Returns null when the pool is full.
 */
export async function storeMedia(
  env: Env,
  input: {
    id: string;
    mime: string;
    bytes: Uint8Array;
    ownerUserId?: number | null;
    teacherId?: number | null;
    galleryId?: number | null;
    label?: string;
  },
): Promise<StoredMedia | null> {
  const shardId = await pickShard(env, Math.ceil(input.bytes.length * 1.34));
  if (!shardId) return null;

  let chunks = 0;
  if (shardId === 1) {
    chunks = (await putLocal(env.DB, input.id, input.mime, input.bytes)).chunks;
  } else {
    const cfg = vaultFor(env, shardId);
    if (!cfg) return null;
    const res = await putVault(cfg, input.id, input.mime, input.bytes);
    chunks = Number(res.chunk_count ?? Math.ceil(input.bytes.length / CHUNK_SIZE));
  }

  const now = new Date().toISOString();
  await env.DB.prepare(
    `INSERT OR REPLACE INTO media_index
       (id, shard_id, storage_key, mime, size_bytes, chunk_count, label, gallery_id,
        teacher_id, uploaded_by, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  )
    .bind(
      input.id,
      shardId,
      input.id,
      input.mime,
      input.bytes.length,
      chunks,
      input.label ?? '',
      input.galleryId ?? null,
      input.teacherId ?? null,
      input.ownerUserId ?? null,
      now,
    )
    .run();

  return {
    id: input.id,
    shardId,
    mime: input.mime,
    bytes: input.bytes.length,
    chunks,
    storageKey: input.id,
    cacheControl: 'public, max-age=3600',
  };
}

export interface MediaRecord {
  id: string;
  shard_id: number;
  storage_key: string;
  mime: string;
  size_bytes: number;
  chunk_count: number;
  label: string;
  gallery_id: number | null;
  teacher_id: number | null;
  uploaded_by: number | null;
  created_at: string;
}

export async function findMedia(env: Env, id: string): Promise<MediaRecord | null> {
  return await env.DB.prepare('SELECT * FROM media_index WHERE id = ?').bind(id).first<MediaRecord>();
}

/** Fetch bytes from whichever shard holds them (Shard 0 = bundled static asset). */
export async function readMedia(
  env: Env,
  rec: MediaRecord,
): Promise<{ mime: string; bytes: Uint8Array } | null> {
  if (rec.shard_id === STATIC_SHARD) return null; // caller redirects to /img/:key
  if (rec.shard_id === 1) return getLocal(env.DB, rec.storage_key);
  const cfg = vaultFor(env, rec.shard_id);
  if (!cfg) return null;
  return getVault(cfg, rec.storage_key);
}

/** Delete chunks on the owning shard + the index row. Zero orphans left behind. */
export async function deleteMedia(env: Env, id: string): Promise<boolean> {
  const rec = await findMedia(env, id);
  if (!rec) return false;
  if (rec.shard_id === 1) await deleteLocal(env.DB, rec.storage_key);
  else if (rec.shard_id > 1) {
    const cfg = vaultFor(env, rec.shard_id);
    if (cfg) await deleteVault(cfg, rec.storage_key);
  }
  await env.DB.prepare('DELETE FROM media_index WHERE id = ?').bind(id).run();
  return true;
}

/** Replace bytes in place: new asset stored first, old chunks removed after. */
export async function replaceMedia(
  env: Env,
  oldId: string,
  input: { id: string; mime: string; bytes: Uint8Array; label?: string },
): Promise<StoredMedia | null> {
  const old = await findMedia(env, oldId);
  const stored = await storeMedia(env, {
    ...input,
    galleryId: old?.gallery_id ?? null,
    teacherId: old?.teacher_id ?? null,
    ownerUserId: old?.uploaded_by ?? null,
    label: input.label ?? old?.label ?? '',
  });
  if (!stored) return null;
  if (old && old.id !== stored.id) await deleteMedia(env, old.id);
  return stored;
}

/** Probe a single vault worker (used by the admin "Test connection" button). */
export async function testVault(
  url: string,
  secret: string,
): Promise<{ ok: boolean; usedBytes?: number; mediaCount?: number; message: string }> {
  const base = normaliseUrl(url);
  if (!base || !secret) return { ok: false, message: 'URL and secret are both required' };
  try {
    const res = await fetch(`${base}/vault/health`, {
      headers: { 'X-Vault-Secret': secret },
      signal: AbortSignal.timeout(8000),
    });
    if (res.status === 401) return { ok: false, message: 'Secret rejected by vault (401)' };
    if (!res.ok) return { ok: false, message: `Vault replied HTTP ${res.status}` };
    const body = (await res.json()) as { ok?: boolean; used_bytes?: number; media_count?: number; name?: string };
    return {
      ok: body.ok !== false,
      usedBytes: Number(body.used_bytes ?? 0),
      mediaCount: Number(body.media_count ?? 0),
      message: `Connected to ${body.name ?? 'vault'} ✓`,
    };
  } catch (e) {
    return { ok: false, message: `Could not reach vault: ${e instanceof Error ? e.message : String(e)}` };
  }
}

export { localStats };
