/** Environment + storage typings shared by the worker, tests and dev server. */

export interface Env {
  DB: D1DatabaseLike;
  BASE_URL?: string;
  SCHOOL_NAME?: string;
  SESSION_SECRET?: string;
  CSRF_SECRET?: string;
  VAULT_2_URL?: string;
  VAULT_2_SECRET?: string;
  VAULT_3_URL?: string;
  VAULT_3_SECRET?: string;
  VAULT_4_URL?: string;
  VAULT_4_SECRET?: string;
  ENVIRONMENT?: string;
}

export type Role = 'super_admin' | 'co_admin' | 'teacher';

export interface SessionUser {
  id: number;
  username: string;
  full_name: string;
  role: Role;
  must_change_password: number;
  teacher_id: number | null;
}

export interface Session {
  sid: string;
  user: SessionUser;
  expires_at: string;
}
