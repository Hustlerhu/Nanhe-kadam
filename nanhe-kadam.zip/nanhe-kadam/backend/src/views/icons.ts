/**
 * Glossy 3D icon set — hand-authored SVG with gradients, inner highlights and
 * soft shadows. No emoji anywhere in the UI; every icon is crisp at any DPI and
 * weighs a few hundred bytes because it is inlined once by the SSR renderer.
 */

type IconOpts = { size?: number; cls?: string };

function wrap(_id: string, body: string, vb: string, size: number, cls: string) {
  return `<svg class="nk-ico ${cls}" width="${size}" height="${size}" viewBox="${vb}" role="img" aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg">${body}</svg>`;
}

/** Star / teacher badge */
export function icoTeachers({ size = 44, cls = '' }: IconOpts = {}) {
  const id = 'it';
  return wrap(
    id,
    `<defs>
      <linearGradient id="${id}g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FFE07A"/><stop offset=".55" stop-color="#F5B72B"/><stop offset="1" stop-color="#D98A0B"/></linearGradient>
      <linearGradient id="${id}s" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FFF6D8"/><stop offset="1" stop-color="#F3C64F"/></linearGradient>
      <filter id="${id}f" x="-30%" y="-30%" width="160%" height="160%"><feDropShadow dx="0" dy="2.2" stdDeviation="1.6" flood-color="#8A5A00" flood-opacity=".35"/></filter>
    </defs>
    <g filter="url(#${id}f)">
      <path d="M22 6.5l4.7 9.6 10.6 1.5-7.7 7.4 1.9 10.5L22 30.6l-9.5 4.9 1.9-10.5-7.7-7.4 10.6-1.5z" fill="url(#${id}g)" stroke="#B9760A" stroke-width="1.1" stroke-linejoin="round"/>
      <path d="M22 9.4l3.5 7.2 7.9 1.1-5.7 5.5 1.4 7.8L22 27.2l-7.1 3.8 1.4-7.8-5.7-5.5 7.9-1.1z" fill="url(#${id}s)" opacity=".85"/>
      <ellipse cx="18.4" cy="15.4" rx="3.4" ry="1.9" fill="#FFFDF2" opacity=".85" transform="rotate(-24 18.4 15.4)"/>
    </g>`,
    '0 0 44 44',
    size,
    cls,
  );
}

/** Shield — safe environment */
export function icoSafe({ size = 44, cls = '' }: IconOpts = {}) {
  const id = 'is';
  return wrap(
    id,
    `<defs>
      <linearGradient id="${id}g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#8BEA9E"/><stop offset=".5" stop-color="#3FBF5E"/><stop offset="1" stop-color="#187A38"/></linearGradient>
      <linearGradient id="${id}h" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#fff" stop-opacity=".55"/><stop offset=".5" stop-color="#fff" stop-opacity=".05"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></linearGradient>
      <filter id="${id}f" x="-30%" y="-30%" width="160%" height="170%"><feDropShadow dx="0" dy="2.4" stdDeviation="1.8" flood-color="#0B4A22" flood-opacity=".38"/></filter>
    </defs>
    <g filter="url(#${id}f)">
      <path d="M22 4.5l13.5 5v10.2c0 8.4-5.5 15.2-13.5 19.3-8-4.1-13.5-10.9-13.5-19.3V9.5z" fill="url(#${id}g)" stroke="#12662F" stroke-width="1.2"/>
      <path d="M22 4.5l13.5 5v10.2c0 1.6-.2 3.2-.6 4.7H9.1a20 20 0 01-.6-4.7V9.5z" fill="url(#${id}h)"/>
      <path d="M15.4 22.3l4.6 4.6 9-9.4" fill="none" stroke="#FFFFFF" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round"/>
    </g>`,
    '0 0 44 44',
    size,
    cls,
  );
}

/** Open book — creative learning */
export function icoCreative({ size = 44, cls = '' }: IconOpts = {}) {
  const id = 'ic';
  return wrap(
    id,
    `<defs>
      <linearGradient id="${id}a" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#7FD3FF"/><stop offset="1" stop-color="#1E7FD6"/></linearGradient>
      <linearGradient id="${id}b" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FFE06A"/><stop offset="1" stop-color="#F0A213"/></linearGradient>
      <filter id="${id}f" x="-30%" y="-30%" width="160%" height="170%"><feDropShadow dx="0" dy="2.4" stdDeviation="1.7" flood-color="#123A5A" flood-opacity=".35"/></filter>
    </defs>
    <g filter="url(#${id}f)">
      <path d="M22 12.4C18.4 9.7 13 8.9 6.6 9.2v23.4c6.4-.3 11.8.5 15.4 3.2 3.6-2.7 9-3.5 15.4-3.2V9.2C31 8.9 25.6 9.7 22 12.4z" fill="url(#${id}a)" stroke="#15629F" stroke-width="1.2"/>
      <path d="M22 12.4C18.4 9.7 13 8.9 6.6 9.2v23.4c6.4-.3 11.8.5 15.4 3.2z" fill="#FFFFFF" opacity=".22"/>
      <path d="M22 12.4v23.2" stroke="#0E4C7D" stroke-width="1.4"/>
      <path d="M10 16.5c3-.2 5.6.2 7.4 1.4M10 21.4c3-.2 5.6.2 7.4 1.4M24.6 17.9c1.8-1.2 4.4-1.6 7.4-1.4M24.6 22.8c1.8-1.2 4.4-1.6 7.4-1.4" stroke="#EAF6FF" stroke-width="1.5" stroke-linecap="round" fill="none" opacity=".9"/>
      <path d="M34.5 4.2l1.7 3.4 3.6.9-2.4 2.7.4 3.7-3.3-1.8-3.4 1.8.5-3.7-2.5-2.7 3.7-.9z" fill="url(#${id}b)" stroke="#C58A08" stroke-width=".9" stroke-linejoin="round"/>
    </g>`,
    '0 0 44 44',
    size,
    cls,
  );
}

/** Trophy — overall development */
export function icoGrowth({ size = 44, cls = '' }: IconOpts = {}) {
  const id = 'ig';
  return wrap(
    id,
    `<defs>
      <linearGradient id="${id}g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FFDE7A"/><stop offset=".55" stop-color="#F3B22A"/><stop offset="1" stop-color="#C8820A"/></linearGradient>
      <filter id="${id}f" x="-30%" y="-30%" width="160%" height="170%"><feDropShadow dx="0" dy="2.4" stdDeviation="1.7" flood-color="#7A4E00" flood-opacity=".38"/></filter>
    </defs>
    <g filter="url(#${id}f)">
      <path d="M13 6.5h18v9.2a9 9 0 01-18 0z" fill="url(#${id}g)" stroke="#A96C05" stroke-width="1.1"/>
      <path d="M13 8.6H7.8v3.1c0 3.5 2.4 6 5.9 6.3M31 8.6h5.2v3.1c0 3.5-2.4 6-5.9 6.3" fill="none" stroke="#C8930F" stroke-width="1.7" stroke-linecap="round"/>
      <path d="M22 15.7V25" stroke="#A96C05" stroke-width="2.2"/>
      <path d="M14.6 36.8c0-4.2 3.3-6.6 7.4-6.6s7.4 2.4 7.4 6.6z" fill="url(#${id}g)" stroke="#A96C05" stroke-width="1.1"/>
      <rect x="12.4" y="36" width="19.2" height="3.6" rx="1.8" fill="#E9A81C" stroke="#A96C05" stroke-width="1"/>
      <ellipse cx="18" cy="11.4" rx="3.2" ry="1.7" fill="#FFF9E2" opacity=".8" transform="rotate(-18 18 11.4)"/>
    </g>`,
    '0 0 44 44',
    size,
    cls,
  );
}

/** Heart in hands — parent support */
export function icoParent({ size = 44, cls = '' }: IconOpts = {}) {
  const id = 'ip';
  return wrap(
    id,
    `<defs>
      <linearGradient id="${id}h" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FF9AA8"/><stop offset=".5" stop-color="#F04150"/><stop offset="1" stop-color="#B3121F"/></linearGradient>
      <linearGradient id="${id}p" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FFE6BE"/><stop offset="1" stop-color="#E0A96B"/></linearGradient>
      <filter id="${id}f" x="-30%" y="-30%" width="160%" height="170%"><feDropShadow dx="0" dy="2.4" stdDeviation="1.7" flood-color="#6B0B13" flood-opacity=".32"/></filter>
    </defs>
    <g filter="url(#${id}f)">
      <path d="M22 13.6c2.2-3.4 6-4.4 8.6-2.6 2.6 1.8 3.1 5.4 1 8.4-1.9 2.7-6.6 5.9-9.6 7.7-3-1.8-7.7-5-9.6-7.7-2.1-3-1.6-6.6 1-8.4 2.6-1.8 6.4-.8 8.6 2.6z" fill="url(#${id}h)" stroke="#8E0C17" stroke-width="1.1"/>
      <ellipse cx="18.6" cy="13.4" rx="2.6" ry="1.5" fill="#FFF3F4" opacity=".75" transform="rotate(-26 18.6 13.4)"/>
      <path d="M7.4 27.2c3.5 1.4 5.9 3.6 7.5 6.4M36.6 27.2c-3.5 1.4-5.9 3.6-7.5 6.4" fill="none" stroke="url(#${id}p)" stroke-width="4.2" stroke-linecap="round"/>
      <path d="M13.4 33.4c2.4 1.6 5.4 2.5 8.6 2.5s6.2-.9 8.6-2.5" fill="none" stroke="url(#${id}p)" stroke-width="4.6" stroke-linecap="round"/>
    </g>`,
    '0 0 44 44',
    size,
    cls,
  );
}

/** Crown — about our school */
export function icoCrown({ size = 26, cls = '' }: IconOpts = {}) {
  const id = 'iw';
  return wrap(
    id,
    `<defs><linearGradient id="${id}g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FFE37F"/><stop offset="1" stop-color="#D08A08"/></linearGradient>
    <filter id="${id}f" x="-30%" y="-40%" width="160%" height="180%"><feDropShadow dx="0" dy="1.6" stdDeviation="1.1" flood-color="#7A4E00" flood-opacity=".35"/></filter></defs>
    <g filter="url(#${id}f)">
      <path d="M4 9.5l4.6 4 4.3-7.2 4.2 7.2 4.9-4-1.6 11.4H5.6z" fill="url(#${id}g)" stroke="#A96C05" stroke-width="1.1" stroke-linejoin="round"/>
      <rect x="5.6" y="20.4" width="14.8" height="3.4" rx="1.7" fill="#EFAF1E" stroke="#A96C05" stroke-width="1"/>
      <circle cx="12.9" cy="4.6" r="1.7" fill="#FFF3C4" stroke="#A96C05" stroke-width=".8"/>
    </g>`,
    '0 0 26 26',
    size,
    cls,
  );
}

/** Graduation cap — classes (flat fills only: survives duplicate-id contexts) */
export function icoCap({ size = 26, cls = '' }: IconOpts = {}) {
  return wrap(
    '',
    `<g>
      <path d="M13 4.4l10.8 4.5L13 13.4 2.2 8.9z" fill="#3A5B84" stroke="#1D344F" stroke-width="1.1" stroke-linejoin="round"/>
      <path d="M13 5.9l7.2 3-7.2 3-7.2-3z" fill="#6E93BF"/>
      <path d="M6.6 11.2v5.1c0 2.5 2.9 4.2 6.4 4.2s6.4-1.7 6.4-4.2v-5.1" fill="#2B4768" stroke="#1D344F" stroke-width="1.2" stroke-linejoin="round"/>
      <path d="M6.6 11.2v5.1c0 2.5 2.9 4.2 6.4 4.2V11.2z" fill="#33536F" opacity=".55"/>
      <path d="M22.6 9.6v5.8" stroke="#C8860A" stroke-width="1.6" stroke-linecap="round"/>
      <circle cx="22.6" cy="17.2" r="2" fill="#F3B32B" stroke="#A86C05" stroke-width=".9"/>
      <circle cx="22.6" cy="17.2" r=".8" fill="#FFF3C4"/>
    </g>`,
    '0 0 26 26',
    size,
    cls,
  );
}

/** Megaphone — notices */
export function icoMegaphone({ size = 26, cls = '' }: IconOpts = {}) {
  const id = 'im';
  return wrap(
    id,
    `<defs><linearGradient id="${id}g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FFD877"/><stop offset=".55" stop-color="#F0A81B"/><stop offset="1" stop-color="#C07407"/></linearGradient>
    <filter id="${id}f" x="-30%" y="-40%" width="160%" height="190%"><feDropShadow dx="0" dy="1.6" stdDeviation="1.2" flood-color="#6E4700" flood-opacity=".38"/></filter></defs>
    <g filter="url(#${id}f)">
      <path d="M4.6 10.6h4.8l9.4-5.2v15.2l-9.4-5.2H4.6z" fill="url(#${id}g)" stroke="#A96C05" stroke-width="1.1" stroke-linejoin="round"/>
      <path d="M9.4 15.6l1.6 6.6 3.2-.8-1.4-5.8z" fill="#F0B32A" stroke="#A96C05" stroke-width="1"/>
      <path d="M21.6 8.2c1.9 1.6 1.9 7 0 8.6M24.6 5.6c3.2 2.6 3.2 10.6 0 13.2" fill="none" stroke="#E8A118" stroke-width="1.7" stroke-linecap="round"/>
    </g>`,
    '0 0 30 26',
    size,
    cls,
  );
}

/** Person — principal / director */
export function icoPerson({ size = 22, cls = '' }: IconOpts = {}) {
  const id = 'iu';
  return wrap(
    id,
    `<defs><linearGradient id="${id}g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#8FD2F5"/><stop offset="1" stop-color="#27618F"/></linearGradient></defs>
    <circle cx="11" cy="7.4" r="4.2" fill="url(#${id}g)" stroke="#1D4C72" stroke-width="1"/>
    <path d="M2.6 21.2c0-4.6 3.8-7.4 8.4-7.4s8.4 2.8 8.4 7.4z" fill="url(#${id}g)" stroke="#1D4C72" stroke-width="1"/>`,
    '0 0 22 22',
    size,
    cls,
  );
}

/* ------------------------------ UI glyphs ------------------------------ */

export function icoPin({ size = 16, cls = '' }: IconOpts = {}) {
  return wrap('', `<path d="M8 1.6c3 0 5.4 2.3 5.4 5.2S8 16 8 16 2.6 9.7 2.6 6.8 5 1.6 8 1.6z" fill="currentColor" opacity=".95"/><circle cx="8" cy="6.9" r="1.9" fill="#fff"/>`, '0 0 16 18', size, cls);
}
export function icoPhone({ size = 16, cls = '' }: IconOpts = {}) {
  return wrap('', `<path d="M3.1 2.2l2.5-.7 1.9 3.6-1.7 1.5a10 10 0 004.2 4.2l1.5-1.7 3.6 1.9-.7 2.5c-.2.8-1 1.3-1.8 1.2C7.4 14 2 8.6 1.9 4c-.1-.8.4-1.6 1.2-1.8z" fill="currentColor"/>`, '0 0 16 16', size, cls);
}
export function icoMail({ size = 16, cls = '' }: IconOpts = {}) {
  return wrap('', `<rect x="1.2" y="3" width="13.6" height="10" rx="1.8" fill="currentColor"/><path d="M2.2 4.2L8 8.4l5.8-4.2" stroke="#fff" stroke-width="1.3" fill="none" stroke-linecap="round"/>`, '0 0 16 16', size, cls);
}
export function icoArrow({ size = 14, cls = '' }: IconOpts = {}) {
  return wrap('', `<path d="M2 7h8.6M7.2 3.4L10.8 7l-3.6 3.6" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`, '0 0 14 14', size, cls);
}
export function icoSend({ size = 16, cls = '' }: IconOpts = {}) {
  return wrap('', `<path d="M1.4 7.4L14 1.6 9.4 14.4 7.2 8.9z" fill="currentColor"/><path d="M7.2 8.9L14 1.6" stroke="#fff" stroke-width="1.1" opacity=".7"/>`, '0 0 16 16', size, cls);
}
export function icoHome({ size = 16, cls = '' }: IconOpts = {}) {
  return wrap('', `<path d="M8 1.4l6.4 5.2v7a1 1 0 01-1 1H2.6a1 1 0 01-1-1v-7z" fill="currentColor"/><rect x="6.2" y="9.2" width="3.6" height="5.4" rx=".8" fill="#fff" opacity=".85"/>`, '0 0 16 16', size, cls);
}
export function icoUsers({ size = 16, cls = '' }: IconOpts = {}) {
  return wrap('', `<circle cx="5.6" cy="5" r="2.8" fill="currentColor"/><path d="M1 13.2c0-2.7 2-4.3 4.6-4.3s4.6 1.6 4.6 4.3z" fill="currentColor"/><circle cx="11.8" cy="5.6" r="2.2" fill="currentColor" opacity=".65"/><path d="M9.6 13.2c0-1.8.7-3 1.9-3.6 2 .2 3.5 1.6 3.5 3.6z" fill="currentColor" opacity=".65"/>`, '0 0 16 16', size, cls);
}
export function icoBook({ size = 16, cls = '' }: IconOpts = {}) {
  return wrap('', `<path d="M8 3.2C6.6 2 4.2 1.7 1.6 1.9v11.4C4.2 13.1 6.6 13.4 8 14.6c1.4-1.2 3.8-1.5 6.4-1.3V1.9C11.8 1.7 9.4 2 8 3.2z" fill="currentColor"/><path d="M8 3.2v11.4" stroke="#fff" stroke-width="1" opacity=".55"/>`, '0 0 16 16', size, cls);
}
export function icoImage({ size = 16, cls = '' }: IconOpts = {}) {
  return wrap('', `<rect x="1.4" y="2.4" width="13.2" height="11.2" rx="2" fill="currentColor"/><circle cx="5.4" cy="6" r="1.5" fill="#fff" opacity=".9"/><path d="M2.6 12.2l3.6-3.8 2.6 2.6 2.4-2.2 2.4 3.4z" fill="#fff" opacity=".9"/>`, '0 0 16 16', size, cls);
}
export function icoBell({ size = 16, cls = '' }: IconOpts = {}) {
  return wrap('', `<path d="M8 1.4a4.2 4.2 0 014.2 4.2v3l1.4 2.4H2.4L3.8 8.6v-3A4.2 4.2 0 018 1.4z" fill="currentColor"/><path d="M6.2 12.6a1.9 1.9 0 003.6 0z" fill="currentColor"/>`, '0 0 16 16', size, cls);
}
export function icoGrid({ size = 16, cls = '' }: IconOpts = {}) {
  return wrap('', `<rect x="1.6" y="1.6" width="5.4" height="5.4" rx="1.4" fill="currentColor"/><rect x="9" y="1.6" width="5.4" height="5.4" rx="1.4" fill="currentColor" opacity=".7"/><rect x="1.6" y="9" width="5.4" height="5.4" rx="1.4" fill="currentColor" opacity=".7"/><rect x="9" y="9" width="5.4" height="5.4" rx="1.4" fill="currentColor"/>`, '0 0 16 16', size, cls);
}
export function icoLock({ size = 16, cls = '' }: IconOpts = {}) {
  return wrap('', `<rect x="2.4" y="6.6" width="11.2" height="8" rx="2" fill="currentColor"/><path d="M5 6.6V4.8a3 3 0 016 0v1.8" stroke="currentColor" stroke-width="1.7" fill="none"/><circle cx="8" cy="10.6" r="1.4" fill="#fff"/>`, '0 0 16 16', size, cls);
}
export function icoCheck({ size = 16, cls = '' }: IconOpts = {}) {
  return wrap('', `<path d="M2.4 8.6l3.6 3.6L13.6 4" stroke="currentColor" stroke-width="2.2" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`, '0 0 16 16', size, cls);
}
export function icoTrash({ size = 16, cls = '' }: IconOpts = {}) {
  return wrap('', `<path d="M3 4.6h10M6.4 4.6V2.8h3.2v1.8M4.4 4.6l.7 9.2h5.8l.7-9.2" stroke="currentColor" stroke-width="1.5" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`, '0 0 16 16', size, cls);
}
export function icoEdit({ size = 16, cls = '' }: IconOpts) {
  return wrap('', `<path d="M10.6 2.2l3.2 3.2-8.4 8.4-3.6.4.4-3.6z" fill="currentColor"/><path d="M9.2 3.6l3.2 3.2" stroke="#fff" stroke-width="1.1"/>`, '0 0 16 16', size, cls);
}
export function icoPlus({ size = 16, cls = '' }: IconOpts) {
  return wrap('', `<path d="M8 2.6v10.8M2.6 8h10.8" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/>`, '0 0 16 16', size, cls);
}
export function icoClose({ size = 16, cls = '' }: IconOpts = {}) {
  return wrap('', `<path d="M3.2 3.2l9.6 9.6M12.8 3.2l-9.6 9.6" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>`, '0 0 16 16', size, cls);
}
export function icoMenu({ size = 20, cls = '' }: IconOpts = {}) {
  return wrap('', `<path d="M2.4 5.2h15.2M2.4 10h15.2M2.4 14.8h15.2" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/>`, '0 0 20 20', size, cls);
}
export function icoUpload({ size = 16, cls = '' }: IconOpts = {}) {
  return wrap('', `<path d="M8 11.4V2.6M4.4 6.2L8 2.6l3.6 3.6" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="M2.4 11.6v1.8h11.2v-1.8" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round"/>`, '0 0 16 16', size, cls);
}
export function icoEye({ size = 16, cls = '' }: IconOpts = {}) {
  return wrap('', `<path d="M8 3.4c3.6 0 6.4 2.6 7.2 4.6-.8 2-3.6 4.6-7.2 4.6S1.6 10 0.8 8C1.6 6 4.4 3.4 8 3.4z" fill="currentColor" opacity=".9"/><circle cx="8" cy="8" r="2.2" fill="#fff"/>`, '0 0 16 16', size, cls);
}
export function icoStar({ size = 14, cls = '' }: IconOpts = {}) {
  return wrap('', `<path d="M7 1.4l1.8 3.7 4 .6-2.9 2.8.7 4-3.6-2-3.6 2 .7-4L1.2 5.7l4-.6z" fill="currentColor"/>`, '0 0 14 14', size, cls);
}
export function icoSparkle({ size = 14, cls = '' }: IconOpts = {}) {
  return wrap('', `<path d="M7 0l1.5 5.5L14 7l-5.5 1.5L7 14 5.5 8.5 0 7l5.5-1.5z" fill="currentColor"/>`, '0 0 14 14', size, cls);
}

/* ------------------------------ social ------------------------------ */

export function icoYouTube({ size = 20, cls = '' }: IconOpts = {}) {
  return wrap('', `<rect x="0.8" y="3.4" width="18.4" height="13.2" rx="4" fill="#FF2D2D"/><path d="M8.2 7.2l5.6 2.8-5.6 2.8z" fill="#fff"/>`, '0 0 20 20', size, cls);
}
export function icoFacebook({ size = 20, cls = '' }: IconOpts = {}) {
  return wrap('', `<circle cx="10" cy="10" r="9.2" fill="#1877F2"/><path d="M12.6 10.6h-1.9V18H8.3v-7.4H7V8.4h1.3V7.1c0-1.9 1-3 3-3h1.9v2.3h-1.4c-.6 0-.8.3-.8.9v1.1h2.2z" fill="#fff"/>`, '0 0 20 20', size, cls);
}
export function icoInstagram({ size = 20, cls = '' }: IconOpts = {}) {
  return wrap(
    '',
    `<defs><linearGradient id="igr" x1="0" y1="1" x2="1" y2="0"><stop offset="0" stop-color="#FEDA75"/><stop offset=".3" stop-color="#FA7E1E"/><stop offset=".6" stop-color="#D62976"/><stop offset="1" stop-color="#962FBF"/></linearGradient></defs>
     <rect x="0.8" y="0.8" width="18.4" height="18.4" rx="5.2" fill="url(#igr)"/><rect x="4.2" y="4.2" width="11.6" height="11.6" rx="3.6" fill="none" stroke="#fff" stroke-width="1.6"/><circle cx="10" cy="10" r="3" fill="none" stroke="#fff" stroke-width="1.6"/><circle cx="14.3" cy="5.7" r="1.1" fill="#fff"/>`,
    '0 0 20 20',
    size,
    cls,
  );
}
export function icoWhatsApp({ size = 20, cls = '' }: IconOpts = {}) {
  return wrap(
    '',
    `<defs><linearGradient id="wag" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#5BF07C"/><stop offset="1" stop-color="#128C4A"/></linearGradient></defs>
     <circle cx="10" cy="10" r="9.2" fill="url(#wag)"/><path d="M10 4.6a5.3 5.3 0 00-4.5 8.1L4.6 15.9l3.3-.9A5.3 5.3 0 1010 4.6zm0 1.5a3.8 3.8 0 013 6.1c-1.3 1.7-3.4 2-5 1l-.4-.2-1.6.4.4-1.5-.2-.4a3.8 3.8 0 013.8-5.4zm-1.6 1.8c-.2 0-.4.1-.6.4-.2.3-.5.8-.5 1.3s.4 1 .4 1.1c.1.1.8 1.3 2 1.8 1 .4 1.2.4 1.4.3.3 0 .7-.3.8-.6.1-.3.1-.5 0-.6l-.9-.5c-.2-.1-.3 0-.4.1l-.4.5c-.1.1-.2.1-.3 0l-1-.6c-.3-.2-.5-.5-.6-.7 0-.1 0-.2.1-.3l.3-.4v-.3l-.4-1z" fill="#fff"/>`,
    '0 0 20 20',
    size,
    cls,
  );
}

export const PILLAR_ICONS = [icoTeachers, icoSafe, icoCreative, icoGrowth, icoParent];
