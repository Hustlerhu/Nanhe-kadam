/**
 * Portal dashboard renderer.
 * Every section is produced ONLY when the signed-in role is allowed to see it —
 * a Teacher's HTML stream physically never contains Co-Admin or Super Admin
 * markup, forms or endpoints.
 */
import { escapeHtml, escapeJsonForScript } from '../lib/crypto.js';
import { formatDate, megabytes, rupees } from '../lib/util.js';
import type { SessionUser } from '../env.js';
import type {
  AssignmentRow,
  AttendanceRow,
  ClassRow,
  EnquiryRow,
  EventRow,
  GalleryItemRow,
  GalleryRow,
  NoticeRow,
  SalaryRow,
  Settings,
  TeacherRow,
} from '../lib/db.js';
import type { PoolSummary } from '../lib/media.js';
import * as I from './icons.js';

export interface MediaItemView {
  id: string;
  caption: string;
  url: string;
  shard: number;
  bytes: number;
}

export interface UserView {
  id: number;
  username: string;
  full_name: string;
  role: string;
  active: number;
  must_change_password: number;
  teacher_id: number | null;
  created_at: string;
}

export interface DashboardProps {
  user: SessionUser;
  schoolName: string;
  shortName: string;
  tagline: string;
  logo: string;
  csrf: string;
  settings: Settings;
  classes: ClassRow[];
  notices: NoticeRow[];
  galleries: Array<GalleryRow & { items: GalleryItemRow[] }>;
  events: EventRow[];
  teachers: TeacherRow[];
  assignments: AssignmentRow[];
  salaries: SalaryRow[];
  attendance: AttendanceRow[];
  users: UserView[];
  enquiries: EnquiryRow[];
  stats: {
    teachers: number;
    classes: number;
    notices: number;
    galleries: number;
    photos: number;
    enquiries: number;
    newEnquiries: number;
    salaryTotal: number;
    salaryThisMonth: number;
    attendanceRate: number;
  };
  pool: PoolSummary | null;
  mediaUrl: (id: string) => string;
  schoolMedia: { logo: MediaItemView | null; hero: MediaItemView | null; about: MediaItemView | null };
}

const ICONS = {
  dashboard: I.icoGrid,
  school: I.icoHome,
  storage: I.icoUpload,
  users: I.icoUsers,
  teachers: I.icoTeachers,
  salary: I.icoStar,
  attendance: I.icoCheck,
  notices: I.icoMegaphone,
  classes: I.icoBook,
  gallery: I.icoImage,
  enquiries: I.icoSend,
  social: I.icoInstagram,
  profile: I.icoPerson,
  shield: I.icoSafe,
};

type View = {
  key: string;
  label: string;
  icon: (o?: { size?: number }) => string;
  roles: Array<'super_admin' | 'co_admin' | 'teacher'>;
};

const VIEWS: View[] = [
  { key: 'overview', label: 'Dashboard', icon: ICONS.dashboard, roles: ['super_admin', 'co_admin', 'teacher'] },
  { key: 'school', label: 'School Identity', icon: ICONS.school, roles: ['super_admin', 'co_admin'] },
  { key: 'storage', label: 'Storage Pool', icon: ICONS.storage, roles: ['super_admin'] },
  { key: 'accounts', label: 'Co-Admins & Logins', icon: ICONS.shield, roles: ['super_admin'] },
  { key: 'teachers', label: 'Teachers', icon: ICONS.teachers, roles: ['super_admin', 'co_admin'] },
  { key: 'salary', label: 'Salary', icon: ICONS.salary, roles: ['super_admin', 'co_admin'] },
  { key: 'attendance', label: 'Attendance', icon: ICONS.attendance, roles: ['super_admin', 'co_admin'] },
  { key: 'notices', label: 'Notice Board', icon: ICONS.notices, roles: ['super_admin', 'co_admin', 'teacher'] },
  { key: 'classes', label: 'Classes', icon: ICONS.classes, roles: ['super_admin', 'co_admin'] },
  { key: 'gallery', label: 'Gallery Sections', icon: ICONS.gallery, roles: ['super_admin', 'co_admin', 'teacher'] },
  { key: 'enquiries', label: 'Admission Enquiries', icon: ICONS.enquiries, roles: ['super_admin', 'co_admin'] },
  { key: 'social', label: 'Social & Contact', icon: ICONS.social, roles: ['super_admin', 'co_admin'] },
  { key: 'profile', label: 'My Profile', icon: ICONS.profile, roles: ['super_admin', 'co_admin', 'teacher'] },
  { key: 'account', label: 'Security', icon: ICONS.shield, roles: ['super_admin', 'co_admin', 'teacher'] },
];

const ROLE_LABEL: Record<string, string> = {
  super_admin: 'Super Admin',
  co_admin: 'Co-Admin',
  teacher: 'Teacher',
};

function field(
  label: string,
  name: string,
  value: string,
  opts: { type?: string; full?: boolean; hint?: string; placeholder?: string; required?: boolean } = {},
): string {
  return `<div class="field${opts.full ? ' full' : ''}">
    <label for="f-${name}">${escapeHtml(label)}${opts.required ? ' <span class="req">*</span>' : ''}</label>
    <input class="input" id="f-${name}" name="${name}" type="${opts.type ?? 'text'}" value="${escapeHtml(value)}" placeholder="${escapeHtml(opts.placeholder ?? '')}" ${opts.required ? 'required' : ''}>
    ${opts.hint ? `<span class="panel-note">${escapeHtml(opts.hint)}</span>` : ''}
  </div>`;
}

function area(label: string, name: string, value: string, rows = 4): string {
  return `<div class="field full">
    <label for="f-${name}">${escapeHtml(label)}</label>
    <textarea class="textarea" id="f-${name}" name="${name}" rows="${rows}">${escapeHtml(value)}</textarea>
  </div>`;
}

function selectField(
  label: string,
  name: string,
  value: string,
  options: Array<{ value: string; label: string }>,
  opts: { full?: boolean } = {},
): string {
  return `<div class="field${opts.full ? ' full' : ''}">
    <label for="f-${name}">${escapeHtml(label)}</label>
    <select class="select" id="f-${name}" name="${name}">
      ${options.map((o) => `<option value="${escapeHtml(o.value)}"${o.value === value ? ' selected' : ''}>${escapeHtml(o.label)}</option>`).join('')}
    </select>
  </div>`;
}

function toggleField(label: string, name: string, on: boolean): string {
  return `<div class="field">
    <label for="f-${name}">${escapeHtml(label)}</label>
    <select class="select" id="f-${name}" name="${name}">
      <option value="1"${on ? ' selected' : ''}>Enabled</option>
      <option value="0"${!on ? ' selected' : ''}>Disabled</option>
    </select>
  </div>`;
}

export function renderDashboard(p: DashboardProps): string {
  const role = p.user.role;
  const allowed = VIEWS.filter((v) => v.roles.includes(role));
  const first = allowed[0]?.key ?? 'overview';

  const navHtml = allowed
    .map(
      (v, i) =>
        `<button class="side-link${i === 0 ? ' is-active' : ''}" type="button" data-view-link="${v.key}">${v.icon({ size: 16 })}<span>${escapeHtml(v.label)}</span></button>`,
    )
    .join('');

  const sections: string[] = [];
  sections.push(viewOverview(p));
  if (role === 'super_admin' || role === 'co_admin') {
    sections.push(viewSchool(p));
    if (role === 'super_admin') {
      sections.push(viewStorage(p));
      sections.push(viewAccounts(p));
    }
    sections.push(viewTeachers(p));
    sections.push(viewSalary(p));
    sections.push(viewAttendance(p));
    sections.push(viewNotices(p));
    sections.push(viewClasses(p));
    sections.push(viewGallery(p));
    sections.push(viewEnquiries(p));
    sections.push(viewSocial(p));
  }
  if (role === 'teacher') {
    sections.push(viewNotices(p));
    sections.push(viewGallery(p));
  }
  sections.push(viewProfile(p));
  sections.push(viewAccount(p));

  const payload = {
    page: 'dashboard',
    csrf: p.csrf,
    user: p.user,
    role,
    firstView: first,
    views: allowed.map((v) => v.key),
    classes: p.classes.map((c) => ({ id: c.id, name: c.name, slug: c.slug })),
    shell: {
      schoolName: p.schoolName,
      logo: p.logo,
      maxUploadMb: 3,
    },
  };

  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>${escapeHtml(ROLE_LABEL[role] ?? 'Portal')} — ${escapeHtml(p.shortName)}</title>
<meta name="robots" content="noindex, nofollow">
<link rel="icon" href="${escapeHtml(p.logo)}">
<link rel="stylesheet" href="/style.css"><link rel="stylesheet" href="/portal.css"><link rel="stylesheet" href="/dashboard.css">
</head>
<body class="portal-body">
<div class="portal-app">
  <aside class="portal-side" id="portal-side">
    <div class="side-brand">
      <img src="${escapeHtml(p.logo)}" alt="logo" width="40" height="40">
      <span><span class="n">${escapeHtml(p.shortName)}</span><span class="s">${escapeHtml(p.tagline)}</span></span>
    </div>
    <div class="side-role">${escapeHtml(ROLE_LABEL[role] ?? role)} · ${escapeHtml(p.user.username)}</div>
    ${navHtml}
    <div class="side-sep"></div>
    <div class="side-foot">
      <a class="side-link" href="/" target="_blank" rel="noopener">${I.icoHome({ size: 16 })}<span>View Website</span></a>
      <button class="side-link" type="button" id="logout-btn">${I.icoLock({ size: 16 })}<span>Sign Out</span></button>
      <div class="side-user"><b>${escapeHtml(p.user.full_name || p.user.username)}</b>${escapeHtml(ROLE_LABEL[role] ?? role)}</div>
    </div>
  </aside>

  <div class="portal-main">
    <div class="portal-top">
      <button class="icon-btn" type="button" id="side-toggle" aria-label="Open menu" style="display:none">${I.icoMenu({ size: 18 })}</button>
      <div>
        <h1 id="view-title">Dashboard</h1>
        <div class="sub" id="view-sub">${escapeHtml(p.schoolName)}</div>
      </div>
      <span class="spacer"></span>
      <div class="portal-top-actions">
        <span class="tag ${role === 'super_admin' ? 'gold' : role === 'co_admin' ? 'blue' : 'green'}">${escapeHtml(ROLE_LABEL[role] ?? role)}</span>
      </div>
    </div>
    <div class="portal-content" id="portal-content">
      ${sections.join('\n')}
    </div>
  </div>
</div>

<div class="scrim" id="scrim"></div>
<div class="toast-wrap" id="toast-wrap" aria-live="polite"></div>
<div class="modal" id="confirm-modal" role="dialog" aria-modal="true" aria-labelledby="confirm-title">
  <div class="modal-head"><h3 id="confirm-title">Please confirm</h3>
    <button class="icon-btn drawer-close" type="button" data-close aria-label="Close">${I.icoClose({ size: 16 })}</button></div>
  <div class="modal-body"><p id="confirm-text" style="font-size:14px;color:#4a3820"></p></div>
  <div class="modal-foot">
    <button class="btn btn-secondary" type="button" data-close>Cancel</button>
    <button class="btn btn-danger" type="button" id="confirm-yes">${I.icoTrash({ size: 15 })}<span>Delete</span></button>
  </div>
</div>

<script type="application/json" id="__NK_PORTAL__">${escapeJsonForScript(payload)}</script>
<script src="/portal-app.js" defer></script>
</body>
</html>`;
}

/* ------------------------------------------------------------------ *
 * Overview
 * ------------------------------------------------------------------ */

function viewOverview(p: DashboardProps): string {
  const role = p.user.role;
  const teacherCard =
    role === 'teacher'
      ? `<div class="panel"><div class="panel-head"><h2>My Classes</h2></div><div class="panel-body">
          <div class="chip-grid">${
            p.assignments.length
              ? p.assignments.map((a) => `<span class="chip is-on">${escapeHtml(a.class_name ?? '')}${a.subject ? ` · ${escapeHtml(a.subject)}` : ''}</span>`).join('')
              : '<span class="panel-note">No classes assigned yet. Please contact the school office.</span>'
          }</div></div></div>`
      : '';

  return `<section class="portal-view" data-view="overview">
    <div class="stat-grid">
      ${statCard('Teachers', String(p.stats.teachers), 'active staff')}
      ${statCard('Classes', String(p.stats.classes), 'Play Class – Class 5')}
      ${statCard('Photos', String(p.stats.photos), 'across gallery sections')}
      ${statCard('Notices', String(p.stats.notices), 'published')}
      ${
        role === 'teacher'
          ? statCard('My Salary (total)', rupees(p.salaries.reduce((a, s) => a + Number(s.amount), 0)), `${p.salaries.length} records`)
          : statCard('Enquiries', String(p.stats.enquiries), `${p.stats.newEnquiries} new`)
      }
      ${
        role === 'teacher'
          ? statCard('Attendance', `${p.stats.attendanceRate}%`, 'present days')
          : statCard('Salary This Month', rupees(p.stats.salaryThisMonth), `total ${rupees(p.stats.salaryTotal)}`)
      }
    </div>
    ${teacherCard}
    <div class="panel">
      <div class="panel-head">
        <h2>Welcome, ${escapeHtml(p.user.full_name || p.user.username)}</h2>
        <span class="spacer"></span>
        <span class="panel-note">${escapeHtml(formatDate(new Date().toISOString()))}</span>
      </div>
      <div class="panel-body" style="display:flex;flex-direction:column;gap:11px">
        <div class="notice-strip">
          ${I.icoSafe({ size: 18 })}
          <span>You are signed in as <b>${escapeHtml(ROLE_LABEL[role] ?? role)}</b>. Every action is recorded in the audit log and all data is validated on the server.</span>
        </div>
        ${
          role === 'teacher'
            ? `<div class="notice-strip info">${I.icoImage({ size: 18 })}<span>You can post class notices and upload gallery photos (up to <b>3 MB HD</b> each).</span></div>`
            : `<div class="notice-strip info">${I.icoUpload({ size: 18 })}<span>Photos are resized to Full HD (1920px, WebP) in your browser and chunked automatically across the 4-account storage pool.</span></div>`
        }
        <div class="panel-grid">
          ${miniTile('Latest Notices', p.notices.slice(0, 3).map((n) => `${formatDate(n.date)} — ${n.title}`))}
          ${miniTile('Recent Enquiries', p.enquiries.slice(0, 3).map((e) => `${e.parent_name} · ${e.class_interested}`))}
        </div>
      </div>
    </div>
  </section>`;
}

function statCard(k: string, v: string, d: string): string {
  return `<div class="stat"><div class="k">${escapeHtml(k)}</div><div class="v">${escapeHtml(v)}</div><div class="d">${escapeHtml(d)}</div></div>`;
}

function miniTile(title: string, lines: string[]): string {
  return `<div class="panel" style="box-shadow:none">
    <div class="panel-head"><h2 style="font-size:13.6px">${escapeHtml(title)}</h2></div>
    <div class="panel-body" style="display:flex;flex-direction:column;gap:6px">
      ${lines.length ? lines.map((l) => `<div class="panel-note" style="font-size:12.4px;color:#4a3820">${escapeHtml(l)}</div>`).join('') : '<div class="panel-note">Nothing yet.</div>'}
    </div>
  </div>`;
}

/* ------------------------------------------------------------------ *
 * School identity
 * ------------------------------------------------------------------ */

function viewSchool(p: DashboardProps): string {
  const s = p.settings;
  const mediaSlot = (key: 'logo' | 'hero' | 'about', label: string, item: MediaItemView | null) => `
    <div class="panel" style="box-shadow:none">
      <div class="panel-head"><h2 style="font-size:13.6px">${escapeHtml(label)}</h2></div>
      <div class="panel-body" style="display:flex;flex-direction:column;gap:9px">
        <div class="media-tile" style="aspect-ratio:16/10">
          ${item ? `<img src="${escapeHtml(item.url)}" alt="${escapeHtml(label)}">` : `<img src="/img/${key}.jpg" alt="${escapeHtml(label)}">`}
          ${item ? `<span class="shard-tag">Shard ${item.shard}</span>` : '<span class="shard-tag">Bundled</span>'}
        </div>
        <label class="drop" data-drop="${key}">
          <span class="di">${I.icoUpload({ size: 20 })}</span>
          <span class="dt">Replace ${escapeHtml(label)}</span>
          <span class="ds">Up to 3 MB HD · auto-resized to 1920px WebP</span>
          <input type="file" accept="image/*" hidden data-file="${key}">
        </label>
        <div class="prog" hidden data-prog="${key}"><i></i></div>
        ${item ? `<button class="btn btn-ghost btn-sm" type="button" data-reset-media="${key}">${I.icoTrash({ size: 13 })}<span>Reset to bundled</span></button>` : ''}
      </div>
    </div>`;

  return `<section class="portal-view" data-view="school" hidden>
    <div class="panel">
      <div class="panel-head"><h2>School Identity &amp; Contact</h2><span class="spacer"></span><span class="panel-note">Shown across the public website</span></div>
      <div class="panel-body">
        <form data-form="settings" data-scope="identity">
          <div class="form-grid">
            ${field('School Name', 'school_name', s.school_name, { required: true })}
            ${field('Navbar Brand', 'short_name', s.short_name, { required: true })}
            ${field('Subtitle / Tagline', 'tagline', s.tagline)}
            ${field('Play · Learn · Grow Ribbon', 'play_learn_grow', s.play_learn_grow)}
            ${field('Hero Headline', 'hero_headline', s.hero_headline)}
            ${field('Opening Date', 'opening_date', s.opening_date, { type: 'date' })}
            ${field('Principal', 'principal', s.principal)}
            ${field('Director', 'director', s.director)}
            ${area('Hero Description', 'hero_sub', s.hero_sub, 3)}
            ${area('About Our School', 'about_text', s.about_text, 5)}
            ${field('Address', 'address', s.address, { full: true })}
            ${field('Google Maps Embed URL', 'map_embed', s.map_embed, { full: true, hint: 'Use the src value from Google Maps → Share → Embed a map.' })}
            ${field('Google Maps Directions Link', 'map_directions', s.map_directions, { full: true })}
            ${field('Phone', 'phone', s.phone)}
            ${field('Email', 'email', s.email, { type: 'email' })}
            ${field('Footer Note', 'footer_note', s.footer_note)}
            ${selectField('Admissions', 'admissions_open', s.admissions_open, [
              { value: '1', label: 'Open — show as open' },
              { value: '0', label: 'Closed — show as enquiry only' },
            ])}
            ${area('Admissions Note', 'admissions_note', s.admissions_note, 2)}
          </div>
          <div style="display:flex;gap:9px;margin-top:14px;flex-wrap:wrap">
            <button class="btn btn-primary" type="submit">${I.icoCheck({ size: 15 })}<span>Save Identity</span></button>
            <span class="panel-note" data-form-status></span>
          </div>
        </form>
      </div>
    </div>
    <div class="panel">
      <div class="panel-head"><h2>Brand Images</h2><span class="spacer"></span><span class="panel-note">3 MB HD uploads · auto-chunked to the storage pool</span></div>
      <div class="panel-body">
        <div class="panel-grid">
          ${mediaSlot('logo', 'Logo', p.schoolMedia.logo)}
          ${mediaSlot('hero', 'Hero Banner', p.schoolMedia.hero)}
          ${mediaSlot('about', 'About Illustration', p.schoolMedia.about)}
        </div>
      </div>
    </div>
  </section>`;
}

/* ------------------------------------------------------------------ *
 * Storage pool
 * ------------------------------------------------------------------ */

function viewStorage(p: DashboardProps): string {
  const pool = p.pool;
  const s = p.settings;
  const usedMb = pool ? Number(megabytes(pool.usedBytes)) : 0;
  const capacityMb = pool ? Number(megabytes(pool.capacityBytes)) : 2000;
  const segs = pool
    ? pool.shards
        .map((sh) => {
          const w = sh.capacityBytes ? (sh.usedBytes / sh.capacityBytes) * 100 : 0;
          return `<span class="meter-seg s${sh.id}" style="width:${Math.max(0.4, w).toFixed(2)}%"></span>`;
        })
        .join('')
    : '';
  const shardRows = pool
    ? pool.shards
        .map((sh) => {
          const w = sh.capacityBytes ? Math.min(100, (sh.usedBytes / sh.capacityBytes) * 100) : 0;
          const color = ['linear-gradient(180deg,#ffd977,#e8a011)', 'linear-gradient(180deg,#9fe0ff,#2b8fd4)', 'linear-gradient(180deg,#b8f0c8,#2fa85c)', 'linear-gradient(180deg,#ffc3cb,#d93b47)'][sh.id - 1] ?? '#f2b01e';
          return `<div class="shard-row">
            <div class="shard-name">${escapeHtml(sh.label)}<span class="s">${sh.connected ? `${sh.mediaCount} photo${sh.mediaCount === 1 ? '' : 's'}` : escapeHtml(sh.error ?? 'offline')}</span></div>
            <div class="shard-bar"><i style="width:${w.toFixed(2)}%;background:${color}"></i></div>
            <div class="shard-val">${megabytes(sh.usedBytes)} / ${megabytes(sh.capacityBytes, 0)} MB</div>
          </div>`;
        })
        .join('')
    : '';

  return `<section class="portal-view" data-view="storage" hidden>
    <div class="panel">
      <div class="panel-head"><h2>Combined Storage Meter</h2><span class="spacer"></span><span class="tag gold">${pool?.connectedShards ?? 1} / 4 accounts connected</span></div>
      <div class="panel-body">
        <div class="meter-total">
          <span class="big">${usedMb.toFixed(1)} MB</span>
          <span class="of">used of ${capacityMb.toFixed(0)} MB across 4 Cloudflare Accounts</span>
        </div>
        <div class="meter-bar">${segs}</div>
        <div class="panel-note" style="margin-top:8px">Each photo is split into 512 KB chunks (≈683 KB base64 — safely below the 1 MB D1 row limit) and routed to the first vault under its 430 MB soft ceiling. Total free capacity: 4 × 500 MB = 2,000 MB.</div>
        <div class="shard-list">${shardRows}</div>
        <div style="display:flex;gap:8px;margin-top:14px;flex-wrap:wrap">
          <button class="btn btn-secondary btn-sm" type="button" data-action="refresh-pool">${I.icoUpload({ size: 13 })}<span>Re-check all vaults</span></button>
        </div>
      </div>
    </div>

    <div class="panel">
      <div class="panel-head"><h2>Storage Vault Workers</h2><span class="spacer"></span><span class="panel-note">Deploy vault-worker/ to accounts 2–4, then paste the URLs here</span></div>
      <div class="panel-body">
        <form data-form="vaults">
          <div class="form-grid">
            ${field('Vault 2 Worker URL', 'vault_2_url', s.vault_2_url ?? '', { placeholder: 'https://nanhe-kadam-vault-2.<subdomain>.workers.dev' })}
            ${field('Vault 2 Secret', 'vault_2_secret', s.vault_2_secret ?? '', { type: 'password', placeholder: 'Paste VAULT_SECRET' })}
            ${field('Vault 3 Worker URL', 'vault_3_url', s.vault_3_url ?? '', { placeholder: 'https://nanhe-kadam-vault-3.<subdomain>.workers.dev' })}
            ${field('Vault 3 Secret', 'vault_3_secret', s.vault_3_secret ?? '', { type: 'password', placeholder: 'Paste VAULT_SECRET' })}
            ${field('Vault 4 Worker URL', 'vault_4_url', s.vault_4_url ?? '', { placeholder: 'https://nanhe-kadam-vault-4.<subdomain>.workers.dev' })}
            ${field('Vault 4 Secret', 'vault_4_secret', s.vault_4_secret ?? '', { type: 'password', placeholder: 'Paste VAULT_SECRET' })}
          </div>
          <div style="display:flex;gap:8px;margin-top:14px;flex-wrap:wrap">
            <button class="btn btn-primary" type="submit">${I.icoCheck({ size: 15 })}<span>Save Vault Configuration</span></button>
            <button class="btn btn-secondary" type="button" data-action="test-vaults">${I.icoSafe({ size: 15 })}<span>Test all connections</span></button>
            <span class="panel-note" data-form-status></span>
          </div>
        </form>
      </div>
    </div>

    <div class="panel">
      <div class="panel-head"><h2>How the 4-account pool works</h2></div>
      <div class="panel-body" style="display:grid;gap:10px">
        <div class="notice-strip">${I.icoSafe({ size: 18 })}<span><b>Shard 1</b> lives in this Worker's D1 database (account 1) and also hosts every school table.</span></div>
        <div class="notice-strip info">${I.icoUpload({ size: 18 })}<span><b>Shards 2–4</b> are lightweight Storage Vault Workers on your other three Gmail accounts — each with its own free 500 MB D1.</span></div>
        <div class="notice-strip warn">${I.icoStar({ size: 18 })}<span>Uploads are routed to the first shard below <b>430 MB</b>, keeping a 70 MB safety margin inside the free tier. Deleting or replacing a photo removes every chunk on its owning shard.</span></div>
      </div>
    </div>
  </section>`;
}

/* ------------------------------------------------------------------ *
 * Accounts (super admin only)
 * ------------------------------------------------------------------ */

function viewAccounts(p: DashboardProps): string {
  const rows = p.users
    .map(
      (u) => `<tr>
        <td class="strong">${escapeHtml(u.full_name || u.username)}</td>
        <td>${escapeHtml(u.username)}</td>
        <td><span class="tag ${u.role === 'super_admin' ? 'gold' : u.role === 'co_admin' ? 'blue' : 'green'}">${escapeHtml(ROLE_LABEL[u.role] ?? u.role)}</span></td>
        <td>${u.active ? '<span class="tag green">Active</span>' : '<span class="tag grey">Disabled</span>'}</td>
        <td>${u.must_change_password ? '<span class="tag red">Must reset</span>' : '<span class="tag grey">Set</span>'}</td>
        <td>${escapeHtml(formatDate(u.created_at))}</td>
        <td>
          <div class="row-actions">
            <button class="btn btn-ghost btn-sm" type="button" data-reset-user="${u.id}" data-name="${escapeHtml(u.username)}">${I.icoLock({ size: 12 })}<span>Reset</span></button>
            ${u.role === 'co_admin' ? `<button class="btn btn-danger btn-sm" type="button" data-delete-user="${u.id}" data-name="${escapeHtml(u.username)}">${I.icoTrash({ size: 12 })}<span>Delete</span></button>` : ''}
          </div>
        </td>
      </tr>`,
    )
    .join('');

  const suggestions = ['CoAdmin1', 'CoAdmin2', 'CoAdmin3'].concat(
    Array.from({ length: 6 }, (_, i) => `Teacher${i + 1}`),
  );

  return `<section class="portal-view" data-view="accounts" hidden>
    <div class="panel">
      <div class="panel-head"><h2>All Logins</h2><span class="spacer"></span><span class="panel-note">${p.users.length} accounts</span></div>
      <div class="table-wrap"><table class="nk">
        <thead><tr><th>Name</th><th>Username</th><th>Role</th><th>Status</th><th>Password</th><th>Created</th><th></th></tr></thead>
        <tbody>${rows}</tbody>
      </table></div>
    </div>

    <div class="panel">
      <div class="panel-head"><h2>Create Co-Admin or Teacher Login</h2></div>
      <div class="panel-body">
        <form data-form="create-user">
          <div class="form-grid">
            ${field('Full Name', 'full_name', '', { required: true, placeholder: 'e.g. Sunita Verma' })}
            ${field('Username', 'username', '', { required: true, placeholder: 'Teacher1', hint: 'Suggested: ' + suggestions.slice(0, 4).join(', ') })}
            ${selectField('Role', 'role', 'co_admin', [
              { value: 'co_admin', label: 'Co-Admin' },
              { value: 'teacher', label: 'Teacher' },
            ])}
            ${field('Temporary Password', 'password', '', { type: 'text', required: true, placeholder: 'At least 8 characters', hint: 'The user must change it at first sign-in.' })}
            ${field('Phone (optional)', 'phone', '', { placeholder: '10-digit mobile' })}
            ${field('Monthly Salary (₹, teachers only)', 'monthly_salary', '0', { type: 'number' })}
            <div class="field full">
              <label>Class Assignments (teachers only)</label>
              <div class="chip-grid" data-class-picker>
                ${p.classes.map((c) => `<button class="chip" type="button" data-pick-class="${c.id}">${escapeHtml(c.name)}</button>`).join('')}
              </div>
            </div>
          </div>
          <div style="display:flex;gap:9px;margin-top:14px;flex-wrap:wrap;align-items:center">
            <button class="btn btn-primary" type="submit">${I.icoPlus({ size: 15 })}<span>Create Login</span></button>
            <span class="panel-note" data-form-status></span>
          </div>
        </form>
      </div>
    </div>

    <div class="panel">
      <div class="panel-head"><h2>Role Permissions</h2></div>
      <div class="panel-body table-wrap">
        <table class="nk">
          <thead><tr><th>Capability</th><th>Super Admin</th><th>Co-Admin</th><th>Teacher</th></tr></thead>
          <tbody>
            ${[
              ['School identity & map', 1, 1, 0],
              ['Storage vault configuration', 1, 0, 0],
              ['Create / delete Co-Admins', 1, 0, 0],
              ['Manage teachers & salary', 1, 1, 0],
              ['Notices & gallery uploads', 1, 1, 1],
              ['View enquiries', 1, 1, 0],
              ['View own salary & classes', 0, 0, 1],
            ]
              .map(
                (r) =>
                  `<tr><td class="strong">${r[0]}</td>${[r[1], r[2], r[3]]
                    .map((v) => `<td>${v ? '<span class="tag green">Yes</span>' : '<span class="tag grey">No</span>'}</td>`)
                    .join('')}</tr>`,
              )
              .join('')}
          </tbody>
        </table>
      </div>
    </div>
  </section>`;
}

/* ------------------------------------------------------------------ *
 * Teachers
 * ------------------------------------------------------------------ */

function viewTeachers(p: DashboardProps): string {
  const teacherSelect = p.teachers.map((t) => ({ value: String(t.id), label: t.full_name }));
  const rows = p.teachers
    .map(
      (t) => `<tr>
        <td class="strong">${escapeHtml(t.full_name)}</td>
        <td>${escapeHtml(t.designation || '—')}</td>
        <td>${escapeHtml(t.phone || '—')}</td>
        <td>${t.username ? `<span class="tag green">${escapeHtml(t.username)}</span>` : '<span class="tag grey">no login</span>'}</td>
        <td>${t.class_count ?? 0}</td>
        <td class="num">${rupees(Number(t.monthly_salary ?? 0))}</td>
        <td>${t.active ? '<span class="tag green">Active</span>' : '<span class="tag grey">Left</span>'}</td>
        <td>
          <div class="row-actions">
            <button class="btn btn-ghost btn-sm" type="button" data-assign-teacher="${t.id}" data-name="${escapeHtml(t.full_name)}">${I.icoBook({ size: 12 })}<span>Classes</span></button>
            <button class="btn btn-danger btn-sm" type="button" data-delete-teacher="${t.id}" data-name="${escapeHtml(t.full_name)}">${I.icoTrash({ size: 12 })}<span>Delete</span></button>
          </div>
        </td>
      </tr>`,
    )
    .join('');

  const assignRows = p.assignments
    .map((a) => {
      const t = p.teachers.find((x) => x.id === a.teacher_id);
      return `<tr>
        <td class="strong">${escapeHtml(t?.full_name ?? '—')}</td>
        <td><span class="tag gold">${escapeHtml(a.class_name ?? '')}</span></td>
        <td>${escapeHtml(a.subject || 'All subjects')}</td>
        <td><div class="row-actions"><button class="btn btn-ghost btn-sm" type="button" data-delete-assignment="${a.id}">${I.icoTrash({ size: 12 })}<span>Remove</span></button></div></td>
      </tr>`;
    })
    .join('');

  return `<section class="portal-view" data-view="teachers" hidden>
    <div class="panel">
      <div class="panel-head"><h2>Teaching Staff</h2><span class="spacer"></span><span class="panel-note">Deleting a teacher removes their salary, attendance, classes, photos and sessions atomically</span></div>
      <div class="table-wrap"><table class="nk">
        <thead><tr><th>Name</th><th>Designation</th><th>Phone</th><th>Login</th><th>Classes</th><th class="num">Salary</th><th>Status</th><th></th></tr></thead>
        <tbody>${rows || '<tr><td colspan="8" class="panel-note">No teachers yet.</td></tr>'}</tbody>
      </table></div>
    </div>

    <div class="panel-grid">
      <div class="panel">
        <div class="panel-head"><h2>Add Teacher</h2></div>
        <div class="panel-body">
          <form data-form="create-teacher">
            <div class="form-grid">
              ${field('Full Name', 'full_name', '', { required: true, full: true })}
              ${field('Designation', 'designation', 'Primary Teacher')}
              ${field('Phone', 'phone', '')}
              ${field('Qualification', 'qualification', '')}
              ${field('Joining Date', 'joined_on', new Date().toISOString().slice(0, 10), { type: 'date' })}
              ${field('Monthly Salary (₹)', 'monthly_salary', '0', { type: 'number' })}
              ${field('Login Username (optional)', 'username', '', { placeholder: 'Teacher1', hint: 'Leave blank for no portal login.' })}
              ${field('Temporary Password', 'password', '', { type: 'text', placeholder: 'Only if username set' })}
              <div class="field full">
                <label>Assign Classes</label>
                <div class="chip-grid" data-class-picker>
                  ${p.classes.map((c) => `<button class="chip" type="button" data-pick-class="${c.id}">${escapeHtml(c.name)}</button>`).join('')}
                </div>
              </div>
            </div>
            <div style="margin-top:14px;display:flex;gap:9px;align-items:center;flex-wrap:wrap">
              <button class="btn btn-primary" type="submit">${I.icoPlus({ size: 15 })}<span>Save Teacher</span></button>
              <span class="panel-note" data-form-status></span>
            </div>
          </form>
        </div>
      </div>

      <div class="panel">
        <div class="panel-head"><h2>Add Class Assignment</h2></div>
        <div class="panel-body">
          <form data-form="assignment">
            <div class="form-grid">
              ${selectField('Teacher', 'teacher_id', teacherSelect[0]?.value ?? '', teacherSelect, { full: true })}
              ${selectField('Class', 'class_id', String(p.classes[0]?.id ?? ''), p.classes.map((c) => ({ value: String(c.id), label: c.name })))}
              ${field('Subject', 'subject', 'All subjects')}
            </div>
            <div style="margin-top:14px;display:flex;gap:9px;align-items:center;flex-wrap:wrap">
              <button class="btn btn-primary" type="submit">${I.icoPlus({ size: 15 })}<span>Assign</span></button>
              <span class="panel-note" data-form-status></span>
            </div>
          </form>
          <div class="table-wrap" style="margin-top:12px"><table class="nk">
            <thead><tr><th>Teacher</th><th>Class</th><th>Subject</th><th></th></tr></thead>
            <tbody>${assignRows || '<tr><td colspan="4" class="panel-note">No assignments yet.</td></tr>'}</tbody>
          </table></div>
        </div>
      </div>
    </div>
  </section>`;
}

/* ------------------------------------------------------------------ *
 * Salary
 * ------------------------------------------------------------------ */

function viewSalary(p: DashboardProps): string {
  const teacherSelect = p.teachers.map((t) => ({ value: String(t.id), label: t.full_name }));
  const rows = p.salaries
    .map((s) => {
      const t = p.teachers.find((x) => x.id === s.teacher_id);
      return `<tr>
        <td class="strong">${escapeHtml(t?.full_name ?? '—')}</td>
        <td>${escapeHtml(s.month)}</td>
        <td class="num">${rupees(Number(s.amount))}</td>
        <td>${escapeHtml(formatDate(s.paid_on))}</td>
        <td>${escapeHtml(s.note || '—')}</td>
        <td><div class="row-actions"><button class="btn btn-danger btn-sm" type="button" data-delete-salary="${s.id}">${I.icoTrash({ size: 12 })}<span>Delete</span></button></div></td>
      </tr>`;
    })
    .join('');
  const total = p.salaries.reduce((a, s) => a + Number(s.amount), 0);

  return `<section class="portal-view" data-view="salary" hidden>
    <div class="stat-grid">
      ${statCard('Total Paid (all time)', rupees(total), `${p.salaries.length} payments`)}
      ${statCard('This Month', rupees(p.stats.salaryThisMonth), 'recorded payouts')}
      ${statCard('Monthly Payroll', rupees(p.teachers.reduce((a, t) => a + Number(t.monthly_salary ?? 0), 0)), 'active staff')}
    </div>
    <div class="panel">
      <div class="panel-head"><h2>Salary Records</h2></div>
      <div class="table-wrap"><table class="nk">
        <thead><tr><th>Teacher</th><th>Month</th><th class="num">Amount</th><th>Paid On</th><th>Note</th><th></th></tr></thead>
        <tbody>${rows || '<tr><td colspan="6" class="panel-note">No salary records yet.</td></tr>'}</tbody>
      </table></div>
    </div>
    <div class="panel">
      <div class="panel-head"><h2>Record a Payment</h2></div>
      <div class="panel-body">
        <form data-form="salary">
          <div class="form-grid">
            ${selectField('Teacher', 'teacher_id', teacherSelect[0]?.value ?? '', teacherSelect)}
            ${field('Month', 'month', new Date().toISOString().slice(0, 7), { type: 'month' })}
            ${field('Amount (₹)', 'amount', '0', { type: 'number', required: true })}
            ${field('Paid On', 'paid_on', new Date().toISOString().slice(0, 10), { type: 'date' })}
            ${field('Note', 'note', '', { full: true, placeholder: 'e.g. November salary — bank transfer' })}
          </div>
          <div style="margin-top:14px;display:flex;gap:9px;align-items:center;flex-wrap:wrap">
            <button class="btn btn-primary" type="submit">${I.icoPlus({ size: 15 })}<span>Save Payment</span></button>
            <span class="panel-note" data-form-status></span>
          </div>
        </form>
      </div>
    </div>
  </section>`;
}

/* ------------------------------------------------------------------ *
 * Attendance
 * ------------------------------------------------------------------ */

function viewAttendance(p: DashboardProps): string {
  const teacherSelect = p.teachers.map((t) => ({ value: String(t.id), label: t.full_name }));
  const rows = p.attendance
    .slice(0, 80)
    .map((a) => {
      const t = p.teachers.find((x) => x.id === a.teacher_id);
      const cls = a.status === 'present' ? 'green' : a.status === 'leave' ? 'gold' : 'red';
      return `<tr>
        <td class="strong">${escapeHtml(t?.full_name ?? '—')}</td>
        <td>${escapeHtml(formatDate(a.day))}</td>
        <td><span class="tag ${cls}">${escapeHtml(a.status)}</span></td>
        <td><div class="row-actions"><button class="btn btn-ghost btn-sm" type="button" data-delete-attendance="${a.id}">${I.icoTrash({ size: 12 })}<span>Remove</span></button></div></td>
      </tr>`;
    })
    .join('');

  return `<section class="portal-view" data-view="attendance" hidden>
    <div class="stat-grid">
      ${statCard('Attendance Rate', `${p.stats.attendanceRate}%`, 'all recorded days')}
      ${statCard('Records', String(p.attendance.length), 'most recent first')}
    </div>
    <div class="panel">
      <div class="panel-head"><h2>Mark Attendance</h2></div>
      <div class="panel-body">
        <form data-form="attendance">
          <div class="form-grid">
            ${selectField('Teacher', 'teacher_id', teacherSelect[0]?.value ?? '', teacherSelect)}
            ${field('Date', 'day', new Date().toISOString().slice(0, 10), { type: 'date', required: true })}
            ${selectField('Status', 'status', 'present', [
              { value: 'present', label: 'Present' },
              { value: 'absent', label: 'Absent' },
              { value: 'leave', label: 'Leave' },
            ])}
            ${field('Note', 'note', '')}
          </div>
          <div style="margin-top:14px;display:flex;gap:9px;align-items:center;flex-wrap:wrap">
            <button class="btn btn-primary" type="submit">${I.icoCheck({ size: 15 })}<span>Save Attendance</span></button>
            <span class="panel-note" data-form-status></span>
          </div>
        </form>
      </div>
    </div>
    <div class="panel">
      <div class="panel-head"><h2>Recent Attendance</h2></div>
      <div class="table-wrap"><table class="nk">
        <thead><tr><th>Teacher</th><th>Date</th><th>Status</th><th></th></tr></thead>
        <tbody>${rows || '<tr><td colspan="4" class="panel-note">No attendance recorded yet.</td></tr>'}</tbody>
      </table></div>
    </div>
  </section>`;
}

/* ------------------------------------------------------------------ *
 * Notices
 * ------------------------------------------------------------------ */

function viewNotices(p: DashboardProps): string {
  const isTeacher = p.user.role === 'teacher';
  const rows = p.notices
    .map((n) => {
      const cls = n.audience === 'class' ? 'purple' : n.audience === 'staff' ? 'blue' : 'gold';
      return `<tr>
        <td class="strong">${escapeHtml(n.title)}</td>
        <td>${escapeHtml(formatDate(n.date))}</td>
        <td><span class="tag ${cls}">${escapeHtml(n.audience)}</span></td>
        <td>${n.is_new ? '<span class="tag red">New</span>' : '<span class="tag grey">—</span>'}</td>
        <td>${n.pinned ? '<span class="tag gold">Pinned</span>' : '—'}</td>
        <td><div class="row-actions">
          <button class="btn btn-ghost btn-sm" type="button" data-toggle-notice="${n.id}" data-field="is_new" data-value="${n.is_new ? 0 : 1}">${I.icoStar({ size: 12 })}<span>${n.is_new ? 'Clear New' : 'Mark New'}</span></button>
          <button class="btn btn-danger btn-sm" type="button" data-delete-notice="${n.id}" data-name="${escapeHtml(n.title)}">${I.icoTrash({ size: 12 })}<span>Delete</span></button>
        </div></td>
      </tr>`;
    })
    .join('');

  return `<section class="portal-view" data-view="notices" hidden>
    <div class="panel">
      <div class="panel-head"><h2>Notice Board</h2><span class="spacer"></span><span class="panel-note">Shown live on the public website</span></div>
      <div class="table-wrap"><table class="nk">
        <thead><tr><th>Title</th><th>Date</th><th>Audience</th><th>New</th><th>Pinned</th><th></th></tr></thead>
        <tbody>${rows || '<tr><td colspan="6" class="panel-note">No notices yet.</td></tr>'}</tbody>
      </table></div>
    </div>
    <div class="panel">
      <div class="panel-head"><h2>Publish a Notice</h2></div>
      <div class="panel-body">
        <form data-form="notice">
          <div class="form-grid">
            ${field('Title', 'title', '', { required: true, full: true, placeholder: 'e.g. Winter Dress is Compulsory from 1st December' })}
            ${area('Details', 'body', '', 4)}
            ${field('Date', 'date', new Date().toISOString().slice(0, 10), { type: 'date', required: true })}
            ${selectField('Audience', 'audience', isTeacher ? 'class' : 'all', [
              { value: 'all', label: 'Everyone (public)' },
              { value: 'public', label: 'Public visitors' },
              { value: 'staff', label: 'Staff only' },
              { value: 'class', label: 'Class notice' },
            ])}
            ${selectField('Show "New" badge', 'is_new', '1', [
              { value: '1', label: 'Yes' },
              { value: '0', label: 'No' },
            ])}
            ${selectField('Pin to top', 'pinned', '0', [
              { value: '0', label: 'No' },
              { value: '1', label: 'Yes' },
            ])}
          </div>
          <div style="margin-top:14px;display:flex;gap:9px;align-items:center;flex-wrap:wrap">
            <button class="btn btn-primary" type="submit">${I.icoPlus({ size: 15 })}<span>Publish Notice</span></button>
            <span class="panel-note" data-form-status></span>
          </div>
        </form>
      </div>
    </div>
  </section>`;
}

/* ------------------------------------------------------------------ *
 * Classes
 * ------------------------------------------------------------------ */

function viewClasses(p: DashboardProps): string {
  const rows = p.classes
    .map(
      (c) => `<tr>
        <td><img src="/img/${escapeHtml(c.slug)}.jpg" alt="" width="34" height="34" style="border-radius:9px;object-fit:contain;background:#fff8e8"></td>
        <td class="strong">${escapeHtml(c.name)}</td>
        <td>${escapeHtml(c.age_group)}</td>
        <td class="panel-note">${escapeHtml(c.summary)}</td>
        <td>${c.active ? '<span class="tag green">Visible</span>' : '<span class="tag grey">Hidden</span>'}</td>
        <td><div class="row-actions">
          <button class="btn btn-ghost btn-sm" type="button" data-edit-class="${c.id}" data-name="${escapeHtml(c.name)}" data-age="${escapeHtml(c.age_group)}" data-summary="${escapeHtml(c.summary)}" data-active="${c.active}">${I.icoEdit({ size: 12 })}<span>Edit</span></button>
        </div></td>
      </tr>`,
    )
    .join('');

  return `<section class="portal-view" data-view="classes" hidden>
    <div class="panel">
      <div class="panel-head"><h2>Classes — Play Class to Class 5</h2><span class="spacer"></span><span class="panel-note">9 classes seeded and editable</span></div>
      <div class="table-wrap"><table class="nk">
        <thead><tr><th></th><th>Class</th><th>Age Group</th><th>Summary</th><th>Status</th><th></th></tr></thead>
        <tbody>${rows}</tbody>
      </table></div>
    </div>
    <div class="panel">
      <div class="panel-head"><h2 id="class-form-title">Edit a Class</h2></div>
      <div class="panel-body">
        <form data-form="class-update">
          <div class="form-grid">
            ${selectField('Class', 'id', String(p.classes[0]?.id ?? ''), p.classes.map((c) => ({ value: String(c.id), label: c.name })), { full: true })}
            ${field('Display Name', 'name', p.classes[0]?.name ?? '')}
            ${field('Age Group', 'age_group', p.classes[0]?.age_group ?? '')}
            ${area('Summary', 'summary', p.classes[0]?.summary ?? '', 3)}
            ${selectField('Visibility', 'active', '1', [
              { value: '1', label: 'Visible on website' },
              { value: '0', label: 'Hidden' },
            ])}
          </div>
          <div style="margin-top:14px;display:flex;gap:9px;align-items:center;flex-wrap:wrap">
            <button class="btn btn-primary" type="submit">${I.icoCheck({ size: 15 })}<span>Save Class</span></button>
            <span class="panel-note" data-form-status></span>
          </div>
        </form>
      </div>
    </div>
  </section>`;
}

/* ------------------------------------------------------------------ *
 * Gallery
 * ------------------------------------------------------------------ */

function viewGallery(p: DashboardProps): string {
  const galleriesHtml = p.galleries
    .map((g) => {
      const tiles = g.items
        .map(
          (it) => `<div class="media-tile">
            <img src="${escapeHtml(p.mediaUrl(it.media_id))}" alt="${escapeHtml(it.caption)}" loading="lazy">
            <span class="shard-tag">Shard ${it.shard_id ?? 0}</span>
            <button class="del" type="button" data-delete-media="${it.media_id}" data-item="${it.id}" aria-label="Delete photo">${I.icoTrash({ size: 13 })}</button>
            <span class="cap">${escapeHtml(it.caption || 'Untitled')}</span>
          </div>`,
        )
        .join('');
      return `<div class="panel" style="box-shadow:none">
        <div class="panel-head">
          <h2>${escapeHtml(g.title)}</h2>
          <span class="spacer"></span>
          <span class="panel-note">${g.items.length} photos · ${escapeHtml(g.subtitle)}</span>
        </div>
        <div class="panel-body" style="display:flex;flex-direction:column;gap:11px">
          <div class="media-grid" data-media-grid="${g.id}">${tiles || '<div class="panel-note">No photos in this section yet.</div>'}</div>
          <label class="drop" data-drop="gallery" data-gallery="${g.id}">
            <span class="di">${I.icoUpload({ size: 22 })}</span>
            <span class="dt">Upload photos to “${escapeHtml(g.title)}”</span>
            <span class="ds">Tap to choose files · up to 3 MB each · Full HD WebP</span>
            <input type="file" accept="image/*" multiple hidden data-file="gallery" data-gallery="${g.id}">
          </label>
          <div class="prog" hidden data-prog="gallery-${g.id}"><i></i></div>
          <div class="notice-strip info" style="font-size:11.8px">${I.icoSafe({ size: 16 })}<span data-upload-status="${g.id}">Chunked upload · auto-routed to the first vault with room.</span></div>
        </div>
      </div>`;
    })
    .join('');

  const eventRows = p.events
    .map(
      (e) => `<tr>
        <td class="strong">${escapeHtml(e.title)}</td>
        <td>${escapeHtml(formatDate(e.date))}</td>
        <td class="panel-note">${escapeHtml(e.description)}</td>
        <td><div class="row-actions"><button class="btn btn-danger btn-sm" type="button" data-delete-event="${e.id}" data-name="${escapeHtml(e.title)}">${I.icoTrash({ size: 12 })}<span>Delete</span></button></div></td>
      </tr>`,
    )
    .join('');

  return `<section class="portal-view" data-view="gallery" hidden>
    <div class="panel">
      <div class="panel-head"><h2>Gallery Sections</h2><span class="spacer"></span><span class="panel-note">3 sections · opening ceremony pre-seeded</span></div>
      <div class="panel-body" style="display:flex;flex-direction:column;gap:14px">${galleriesHtml}</div>
    </div>
    <div class="panel">
      <div class="panel-head"><h2>Add a Gallery Section</h2></div>
      <div class="panel-body">
        <form data-form="gallery">
          <div class="form-grid">
            ${field('Title', 'title', '', { required: true, placeholder: 'e.g. Annual Function 2027' })}
            ${field('Subtitle', 'subtitle', '', { placeholder: 'Short description' })}
          </div>
          <div style="margin-top:14px;display:flex;gap:9px;align-items:center;flex-wrap:wrap">
            <button class="btn btn-primary" type="submit">${I.icoPlus({ size: 15 })}<span>Create Section</span></button>
            <span class="panel-note" data-form-status></span>
          </div>
        </form>
      </div>
    </div>
    <div class="panel">
      <div class="panel-head"><h2>Events</h2></div>
      <div class="table-wrap"><table class="nk">
        <thead><tr><th>Event</th><th>Date</th><th>Description</th><th></th></tr></thead>
        <tbody>${eventRows || '<tr><td colspan="4" class="panel-note">No events yet.</td></tr>'}</tbody>
      </table></div>
      <div class="panel-body">
        <form data-form="event">
          <div class="form-grid">
            ${field('Title', 'title', '', { required: true })}
            ${field('Date', 'date', new Date().toISOString().slice(0, 10), { type: 'date', required: true })}
            ${area('Description', 'description', '', 2)}
          </div>
          <div style="margin-top:14px;display:flex;gap:9px;align-items:center;flex-wrap:wrap">
            <button class="btn btn-primary" type="submit">${I.icoPlus({ size: 15 })}<span>Add Event</span></button>
            <span class="panel-note" data-form-status></span>
          </div>
        </form>
      </div>
    </div>
  </section>`;
}

/* ------------------------------------------------------------------ *
 * Enquiries
 * ------------------------------------------------------------------ */

function viewEnquiries(p: DashboardProps): string {
  const rows = p.enquiries
    .map(
      (e) => `<tr>
        <td class="strong">${escapeHtml(e.parent_name)}</td>
        <td>${escapeHtml(e.child_name)}</td>
        <td><span class="tag gold">${escapeHtml(e.class_interested)}</span></td>
        <td><a href="tel:${escapeHtml(e.phone)}">${escapeHtml(e.phone)}</a></td>
        <td class="panel-note" style="max-width:220px">${escapeHtml(e.message || '—')}</td>
        <td>${escapeHtml(formatDate(e.created_at))}</td>
        <td><span class="tag ${e.status === 'new' ? 'red' : 'gey'}">${escapeHtml(e.status)}</span></td>
        <td><div class="row-actions"><button class="btn btn-danger btn-sm" type="button" data-delete-enquiry="${e.id}" data-name="${escapeHtml(e.parent_name)}">${I.icoTrash({ size: 12 })}<span>Delete</span></button></div></td>
      </tr>`,
    )
    .join('');

  return `<section class="portal-view" data-view="enquiries" hidden>
    <div class="stat-grid">
      ${statCard('Total Enquiries', String(p.enquiries.length), 'all time')}
      ${statCard('New', String(p.stats.newEnquiries), 'awaiting reply')}
    </div>
    <div class="panel">
      <div class="panel-head"><h2>Admission Enquiries</h2><span class="spacer"></span><span class="panel-note">Submitted from the public website</span></div>
      <div class="table-wrap"><table class="nk">
        <thead><tr><th>Parent</th><th>Child</th><th>Class</th><th>Phone</th><th>Message</th><th>Received</th><th>Status</th><th></th></tr></thead>
        <tbody>${rows || '<tr><td colspan="8" class="panel-note">No enquiries yet.</td></tr>'}</tbody>
      </table></div>
    </div>
  </section>`;
}

/* ------------------------------------------------------------------ *
 * Social & contact
 * ------------------------------------------------------------------ */

function viewSocial(p: DashboardProps): string {
  const s = p.settings;
  return `<section class="portal-view" data-view="social" hidden>
    <div class="panel">
      <div class="panel-head"><h2>Social Channels</h2><span class="spacer"></span><span class="panel-note">Toggle to hide a channel everywhere</span></div>
      <div class="panel-body">
        <form data-form="settings" data-scope="social">
          <div class="form-grid">
            ${toggleField('WhatsApp', 'whatsapp_enabled', s.whatsapp_enabled === '1')}
            ${field('WhatsApp Number', 'whatsapp_number', s.whatsapp_number, { placeholder: '919559104341' })}
            ${area('WhatsApp Pre-filled Message', 'whatsapp_message', s.whatsapp_message, 2)}
            ${toggleField('Instagram', 'instagram_enabled', s.instagram_enabled === '1')}
            ${field('Instagram URL', 'instagram_url', s.instagram_url)}
            ${field('Instagram Handle', 'instagram_handle', s.instagram_handle)}
            ${toggleField('Facebook', 'facebook_enabled', s.facebook_enabled === '1')}
            ${field('Facebook URL', 'facebook_url', s.facebook_url)}
            ${field('Facebook Handle', 'facebook_handle', s.facebook_handle)}
            ${toggleField('YouTube', 'youtube_enabled', s.youtube_enabled === '1')}
            ${field('YouTube URL', 'youtube_url', s.youtube_url)}
            ${field('YouTube Handle', 'youtube_handle', s.youtube_handle)}
          </div>
          <div style="margin-top:14px;display:flex;gap:9px;align-items:center;flex-wrap:wrap">
            <button class="btn btn-primary" type="submit">${I.icoCheck({ size: 15 })}<span>Save Social Settings</span></button>
            <span class="panel-note" data-form-status></span>
          </div>
        </form>
      </div>
    </div>
  </section>`;
}

/* ------------------------------------------------------------------ *
 * Profile & security
 * ------------------------------------------------------------------ */

function viewProfile(p: DashboardProps): string {
  const teacher = p.teachers.find((t) => t.user_id === p.user.id || t.id === p.user.teacher_id);
  const myAssignments = teacher ? p.assignments.filter((a) => a.teacher_id === teacher.id) : [];
  const mySalaries = teacher ? p.salaries.filter((s) => s.teacher_id === teacher.id) : [];

  const salaryRows = mySalaries
    .map(
      (s) => `<tr><td class="strong">${escapeHtml(s.month)}</td><td class="num">${rupees(Number(s.amount))}</td><td>${escapeHtml(formatDate(s.paid_on))}</td><td class="panel-note">${escapeHtml(s.note || '—')}</td></tr>`,
    )
    .join('');

  return `<section class="portal-view" data-view="profile" hidden>
    <div class="panel">
      <div class="panel-head"><h2>My Profile</h2></div>
      <div class="panel-body">
        <div class="panel-grid">
          <div><div class="stat"><div class="k">Name</div><div class="v" style="font-size:17px">${escapeHtml(p.user.full_name || p.user.username)}</div><div class="d">${escapeHtml(ROLE_LABEL[p.user.role] ?? p.user.role)}</div></div></div>
          <div><div class="stat"><div class="k">Username</div><div class="v" style="font-size:17px">${escapeHtml(p.user.username)}</div><div class="d">issued by school office</div></div></div>
          ${teacher ? `<div><div class="stat"><div class="k">Designation</div><div class="v" style="font-size:17px">${escapeHtml(teacher.designation || 'Teacher')}</div><div class="d">joined ${escapeHtml(formatDate(teacher.joined_on))}</div></div></div>` : ''}
          ${teacher ? `<div><div class="stat"><div class="k">Monthly Salary</div><div class="v" style="font-size:17px">${rupees(Number(teacher.monthly_salary ?? 0))}</div><div class="d">${escapeHtml(teacher.qualification || '')}</div></div></div>` : ''}
        </div>
        ${
          myAssignments.length
            ? `<div style="margin-top:14px"><div class="panel-note" style="margin-bottom:7px;font-weight:800;color:#5d4519">Assigned Classes</div>
               <div class="chip-grid">${myAssignments.map((a) => `<span class="chip is-on">${escapeHtml(a.class_name ?? '')}${a.subject ? ` · ${escapeHtml(a.subject)}` : ''}</span>`).join('')}</div></div>`
            : ''
        }
      </div>
    </div>
    ${
      mySalaries.length
        ? `<div class="panel"><div class="panel-head"><h2>Salary History</h2></div>
           <div class="table-wrap"><table class="nk"><thead><tr><th>Month</th><th class="num">Amount</th><th>Paid On</th><th>Note</th></tr></thead><tbody>${salaryRows}</tbody></table></div></div>`
        : ''
    }
  </section>`;
}

function viewAccount(_p: DashboardProps): string {
  return `<section class="portal-view" data-view="account" hidden>
    <div class="panel">
      <div class="panel-head"><h2>Change Password</h2></div>
      <div class="panel-body">
        <form data-form="password">
          <div class="form-grid">
            ${field('Current Password', 'current_password', '', { type: 'password', required: true, full: true })}
            ${field('New Password', 'new_password', '', { type: 'password', required: true, hint: 'Minimum 8 characters.' })}
            ${field('Confirm New Password', 'confirm_password', '', { type: 'password', required: true })}
          </div>
          <div style="margin-top:14px;display:flex;gap:9px;align-items:center;flex-wrap:wrap">
            <button class="btn btn-primary" type="submit">${I.icoLock({ size: 15 })}<span>Update Password</span></button>
            <span class="panel-note" data-form-status></span>
          </div>
        </form>
      </div>
    </div>
    <div class="panel">
      <div class="panel-head"><h2>Session</h2></div>
      <div class="panel-body" style="display:flex;flex-direction:column;gap:11px">
        <div class="notice-strip">${I.icoSafe({ size: 18 })}<span>Your session cookie is <b>HttpOnly · Secure · SameSite=Strict</b>, HMAC-SHA256 signed and backed by D1. It expires automatically after 12 hours.</span></div>
        <button class="btn btn-danger btn-sm" type="button" id="logout-btn-2" style="align-self:flex-start">${I.icoLock({ size: 13 })}<span>Sign out of this device</span></button>
      </div>
    </div>
  </section>`;
}
