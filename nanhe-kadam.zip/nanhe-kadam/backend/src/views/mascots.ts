/**
 * Interactive SVG mascots.
 *  • Bunny — the portal login guardian: eyes follow the cursor, paws cover the
 *    eyes while the password is focused, happy bounce on success, head-shake on
 *    failure. Pure CSS transforms driven by portal.js.
 *  • Stickman — the admission helper: waves, points at the form, then does a
 *    victory jump while confetti bursts on a successful enquiry.
 */

export function bunnySvg(): string {
  return `<div class="bunny-stage">
  <svg class="bunny" id="nk-bunny" viewBox="0 0 200 178" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Friendly bunny mascot">
    <defs>
      <radialGradient id="bk-body" cx="42%" cy="30%" r="76%">
        <stop offset="0" stop-color="#FFFFFF"/><stop offset=".62" stop-color="#F7EFE2"/><stop offset="1" stop-color="#E4D5BF"/>
      </radialGradient>
      <radialGradient id="bk-inner" cx="50%" cy="40%" r="70%">
        <stop offset="0" stop-color="#FFD3DC"/><stop offset="1" stop-color="#F2A0B2"/>
      </radialGradient>
      <linearGradient id="bk-paw" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stop-color="#FFFFFF"/><stop offset="1" stop-color="#EBDDC6"/>
      </linearGradient>
      <linearGradient id="bk-scarf" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0" stop-color="#FFD977"/><stop offset="1" stop-color="#E39B12"/>
      </linearGradient>
      <radialGradient id="bk-cheek" cx="50%" cy="50%" r="50%">
        <stop offset="0" stop-color="#FFB6C4" stop-opacity=".85"/><stop offset="1" stop-color="#FFB6C4" stop-opacity="0"/>
      </radialGradient>
      <filter id="bk-shadow" x="-40%" y="-30%" width="180%" height="180%">
        <feDropShadow dx="0" dy="5" stdDeviation="5" flood-color="#8A6A2C" flood-opacity=".24"/>
      </filter>
    </defs>
    <ellipse cx="100" cy="166" rx="46" ry="8" fill="#E7D2AB" opacity=".5"/>
    <g filter="url(#bk-shadow)">
      <!-- ears -->
      <g class="ear-l">
        <ellipse cx="72" cy="44" rx="15" ry="40" fill="url(#bk-body)" stroke="#D9C5A6" stroke-width="1.6" transform="rotate(-11 72 44)"/>
        <ellipse cx="72" cy="46" rx="7.6" ry="29" fill="url(#bk-inner)" opacity=".9" transform="rotate(-11 72 46)"/>
      </g>
      <g class="ear-r">
        <ellipse cx="128" cy="44" rx="15" ry="40" fill="url(#bk-body)" stroke="#D9C5A6" stroke-width="1.6" transform="rotate(11 128 44)"/>
        <ellipse cx="128" cy="46" rx="7.6" ry="29" fill="url(#bk-inner)" opacity=".9" transform="rotate(11 128 46)"/>
      </g>
      <!-- head -->
      <ellipse cx="100" cy="104" rx="56" ry="52" fill="url(#bk-body)" stroke="#D9C5A6" stroke-width="1.8"/>
      <ellipse cx="100" cy="88" rx="44" ry="34" fill="#FFFFFF" opacity=".55"/>
      <!-- cheeks -->
      <ellipse cx="66" cy="118" rx="14" ry="8" fill="url(#bk-cheek)"/>
      <ellipse cx="134" cy="118" rx="14" ry="8" fill="url(#bk-cheek)"/>
      <!-- eyes (open) -->
      <g class="bunny-eyes-open">
        <ellipse cx="80" cy="98" rx="11.5" ry="13" fill="#2A2118"/>
        <ellipse cx="120" cy="98" rx="11.5" ry="13" fill="#2A2118"/>
        <circle class="pupil" data-eye="l" cx="80" cy="96" r="5.4" fill="#FFFFFF" opacity=".92"/>
        <circle class="pupil" data-eye="r" cx="120" cy="96" r="5.4" fill="#FFFFFF" opacity=".92"/>
        <circle cx="85" cy="92" r="2.1" fill="#FFFFFF" opacity=".7"/>
        <circle cx="125" cy="92" r="2.1" fill="#FFFFFF" opacity=".7"/>
      </g>
      <!-- eyes (closed / covered by happy arc) -->
      <g class="bunny-eyes-closed" fill="none" stroke="#2A2118" stroke-width="3.4" stroke-linecap="round">
        <path d="M70 99c3.6-6 13.4-6 17 0"/>
        <path d="M113 99c3.6-6 13.4-6 17 0"/>
      </g>
      <!-- nose + mouth -->
      <path d="M100 110l-6.4-4.4h12.8z" fill="#F08CA0"/>
      <path d="M100 110v4M100 114c-2.6 3-7 3.4-9.4.6M100 114c2.6 3 7 3.4 9.4.6" fill="none" stroke="#B08A6A" stroke-width="2" stroke-linecap="round"/>
      <!-- whiskers -->
      <path d="M62 108l-14 3M63 116l-14 8M138 108l14 3M137 116l14 8" stroke="#D9C5A6" stroke-width="1.8" stroke-linecap="round"/>
      <!-- scarf -->
      <path d="M62 140c12 9 64 9 76 0 4 5 4 12-1 16-14 8-60 8-74 0-5-4-5-11-1-16z" fill="url(#bk-scarf)" stroke="#C8860A" stroke-width="1.4"/>
      <path d="M132 152l10 18 8-5-9-16z" fill="url(#bk-scarf)" stroke="#C8860A" stroke-width="1.2"/>
      <!-- paws -->
      <g class="paw" data-paw="l">
        <ellipse cx="70" cy="150" rx="17" ry="14" fill="url(#bk-paw)" stroke="#D9C5A6" stroke-width="1.6"/>
        <path d="M63 146c1.6-2.4 4-3 5.6-1.6M70 144.4c1.6-2.4 4-3 5.6-1.6M77 146c1.6-2.4 4-3 5.6-1.6" stroke="#D9C5A6" stroke-width="1.4" fill="none" stroke-linecap="round"/>
      </g>
      <g class="paw" data-paw="r">
        <ellipse cx="130" cy="150" rx="17" ry="14" fill="url(#bk-paw)" stroke="#D9C5A6" stroke-width="1.6"/>
        <path d="M123 146c1.6-2.4 4-3 5.6-1.6M130 144.4c1.6-2.4 4-3 5.6-1.6M137 146c1.6-2.4 4-3 5.6-1.6" stroke="#D9C5A6" stroke-width="1.4" fill="none" stroke-linecap="round"/>
      </g>
    </g>
  </svg>
</div>`;
}

export function stickmanSvg(): string {
  return `<svg class="stickman" id="nk-stickman" viewBox="0 0 200 240" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Cheerful student mascot">
  <defs>
    <linearGradient id="sm-shirt" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#7FC4F5"/><stop offset="1" stop-color="#2B7FD4"/></linearGradient>
    <linearGradient id="sm-bag" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FFC85C"/><stop offset="1" stop-color="#E08D0B"/></linearGradient>
    <filter id="sm-sh" x="-30%" y="-20%" width="160%" height="160%"><feDropShadow dx="0" dy="4" stdDeviation="4" flood-color="#8A6A2C" flood-opacity=".22"/></filter>
  </defs>
  <ellipse cx="100" cy="228" rx="42" ry="7" fill="#E2CFA8" opacity=".55"/>
  <g filter="url(#sm-sh)">
    <!-- back arm (waives) -->
    <g class="sm-arm-wave" id="sm-wave">
      <path d="M72 118c-14 6-22 16-24 30" stroke="#2B7FD4" stroke-width="9" stroke-linecap="round" fill="none"/>
      <circle cx="47" cy="152" r="7.5" fill="#F5C69B" stroke="#D9A472" stroke-width="1.4"/>
    </g>
    <!-- legs -->
    <path d="M88 176l-6 44" stroke="#31435F" stroke-width="9" stroke-linecap="round" fill="none"/>
    <path d="M112 176l6 44" stroke="#31435F" stroke-width="9" stroke-linecap="round" fill="none"/>
    <path d="M74 220h16M110 220h16" stroke="#1E2C42" stroke-width="8" stroke-linecap="round"/>
    <!-- body -->
    <rect x="76" y="106" width="48" height="72" rx="16" fill="url(#sm-shirt)" stroke="#1F5F9E" stroke-width="1.6"/>
    <path d="M100 106l-7 14 7 7 7-7z" fill="#FFFFFF" opacity=".9"/>
    <rect x="86" y="150" width="28" height="7" rx="3.5" fill="#FFFFFF" opacity=".5"/>
    <!-- satchel -->
    <g class="sm-bag">
      <rect x="118" y="126" width="30" height="34" rx="8" fill="url(#sm-bag)" stroke="#B4700A" stroke-width="1.6"/>
      <path d="M118 136h30" stroke="#B4700A" stroke-width="1.4"/>
      <circle cx="133" cy="131" r="2.6" fill="#B4700A"/>
    </g>
    <!-- head -->
    <g class="sm-head" id="sm-head">
      <circle cx="100" cy="74" r="30" fill="#F7CDA4" stroke="#D9A472" stroke-width="1.6"/>
      <path d="M70 66c2-18 16-27 30-27s28 9 30 27c-9-7-19-10-30-10s-21 3-30 10z" fill="#2C2118"/>
      <circle cx="89" cy="76" r="4" fill="#2C2118"/>
      <circle cx="111" cy="76" r="4" fill="#2C2118"/>
      <circle cx="90.6" cy="74.4" r="1.4" fill="#fff"/>
      <circle cx="112.6" cy="74.4" r="1.4" fill="#fff"/>
      <path d="M92 88c2.6 3.6 13.4 3.6 16 0" stroke="#8A5A32" stroke-width="2.6" fill="none" stroke-linecap="round"/>
      <ellipse cx="80" cy="84" rx="6" ry="3.4" fill="#FFB6C4" opacity=".7"/>
      <ellipse cx="120" cy="84" rx="6" ry="3.4" fill="#FFB6C4" opacity=".7"/>
    </g>
    <!-- front arm (points at the form) -->
    <g class="sm-arm-point" id="sm-point">
      <path d="M126 120c16 2 26 10 32 24" stroke="#2B7FD4" stroke-width="9" stroke-linecap="round" fill="none"/>
      <circle cx="160" cy="146" r="7.5" fill="#F5C69B" stroke="#D9A472" stroke-width="1.4"/>
    </g>
  </g>
</svg>`;
}

/** Confetti is created by JS from this template host (kept out of the DOM until needed). */
export const CONFETTI_HOST = '<div class="confetti-host" id="nk-confetti" aria-hidden="true"></div>';
