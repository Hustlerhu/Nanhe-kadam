/** Server-rendered /portal login page with the animated bunny guardian. */
import { escapeHtml, escapeJsonForScript } from '../lib/crypto.js';
import * as I from './icons.js';
import { bunnySvg } from './mascots.js';

export function renderLogin(opts: { logo: string; schoolName: string; tagline: string; csrf: string }): string {
  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>School Portal — ${escapeHtml(opts.schoolName)}</title>
<meta name="robots" content="noindex, nofollow">
<link rel="icon" href="${escapeHtml(opts.logo)}">
<link rel="stylesheet" href="/style.css"><link rel="stylesheet" href="/portal.css">
</head>
<body class="portal-body">
<div class="login-shell">
  <div class="login-card">
    <div class="login-brand">
      <img src="${escapeHtml(opts.logo)}" alt="${escapeHtml(opts.schoolName)} logo" width="62" height="62">
      <span class="n">${escapeHtml(opts.schoolName)}</span>
      <span class="s">School Portal</span>
    </div>
    ${bunnySvg()}
    <div class="role-tabs" role="tablist" aria-label="Login role">
      <button class="role-tab is-active" type="button" role="tab" aria-selected="true" data-role="super_admin">Super Admin</button>
      <button class="role-tab" type="button" role="tab" aria-selected="false" data-role="co_admin">Co-Admin</button>
      <button class="role-tab" type="button" role="tab" aria-selected="false" data-role="teacher">Teacher Login</button>
    </div>
    <form class="login-form" id="login-form" novalidate>
      <div class="login-title" id="login-role-title">Super Admin sign in</div>
      <div class="field">
        <label for="username">Username</label>
        <input class="input" id="username" name="username" type="text" autocomplete="username" autocapitalize="none" spellcheck="false" required placeholder="Your username">
      </div>
      <div class="field">
        <label for="password">Password</label>
        <div class="pw-wrap">
          <input class="input" id="password" name="password" type="password" autocomplete="current-password" required placeholder="Your password">
          <button class="pw-toggle" type="button" id="pw-toggle" aria-label="Show password">${I.icoEye({ size: 16 })}</button>
        </div>
      </div>
      <button class="btn btn-primary btn-lg btn-block" type="submit" id="login-submit">${I.icoLock({ size: 16 })}<span>Sign In</span></button>
      <div class="login-err" id="login-err" role="alert" aria-live="polite"></div>
      <p class="login-hint">Roles are verified on the server. <b>Teachers</b> use the username issued by the school office.</p>
      <a class="login-hint" href="/" style="font-weight:700;color:#6b4c14">← Back to website</a>
    </form>
  </div>
</div>
<div class="toast-wrap" id="toast-wrap" aria-live="polite"></div>
<script type="application/json" id="__NK_PORTAL__">${escapeJsonForScript({ csrf: opts.csrf, page: 'login' })}</script>
<script src="/portal.js" defer></script>
</body>
</html>`;
}

export function renderPasswordGate(opts: { logo: string; schoolName: string; username: string; csrf: string }): string {
  return `<!doctype html>
<html lang="en">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Set a new password — ${escapeHtml(opts.schoolName)}</title>
<meta name="robots" content="noindex,nofollow">
<link rel="icon" href="${escapeHtml(opts.logo)}"><link rel="stylesheet" href="/style.css"><link rel="stylesheet" href="/portal.css"></head>
<body class="portal-body">
<div class="login-shell">
  <div class="login-card gate-card">
    <div class="login-brand">
      <img src="${escapeHtml(opts.logo)}" alt="logo" width="62" height="62">
      <span class="n">${escapeHtml(opts.schoolName)}</span>
      <span class="s">First-time security step</span>
    </div>
    <div class="login-title">Welcome, ${escapeHtml(opts.username)} — please set your own password</div>
    <form class="login-form" id="pw-form" novalidate>
      <div class="field"><label for="new_password">New password</label>
        <input class="input" id="new_password" name="new_password" type="password" autocomplete="new-password" required minlength="8" placeholder="At least 8 characters"></div>
      <div class="field"><label for="confirm_password">Confirm password</label>
        <input class="input" id="confirm_password" name="confirm_password" type="password" autocomplete="new-password" required minlength="8" placeholder="Repeat password"></div>
      <button class="btn btn-primary btn-lg btn-block" type="submit" id="pw-submit">${I.icoLock({ size: 16 })}<span>Save &amp; Continue</span></button>
      <div class="login-err" id="pw-err" role="alert" aria-live="polite"></div>
      <p class="login-hint">Passwords are hashed with PBKDF2-SHA256 (100,000 iterations). We never store plain text.</p>
    </form>
  </div>
</div>
<div class="toast-wrap" id="toast-wrap" aria-live="polite"></div>
<script type="application/json" id="__NK_PORTAL__">${escapeJsonForScript({ csrf: opts.csrf, page: 'password' })}</script>
<script src="/portal.js" defer></script>
</body></html>`;
}
