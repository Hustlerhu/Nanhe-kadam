/**
 * Public site renderer — server-side hydrated so the homepage paints instantly
 * with zero "Loading…" flash. Nothing from the portal (routes, roles, schema or
 * dashboard markup) is referenced anywhere in this file.
 */
import { escapeHtml, escapeJsonForScript, safeUrl } from '../lib/crypto.js';
import { formatDate, monthAbbr } from '../lib/util.js';
import type { ClassRow, EventRow, GalleryItemRow, GalleryRow, NoticeRow, Settings } from '../lib/db.js';
import * as I from './icons.js';
import { stickmanSvg } from './mascots.js';

export interface HomeData {
  settings: Settings;
  classes: ClassRow[];
  notices: NoticeRow[];
  galleries: Array<GalleryRow & { items: GalleryItemRow[] }>;
  events: EventRow[];
  mediaUrl: (mediaId: string) => string;
}

const PILLARS = [
  { ico: I.icoTeachers, title: 'Expert Teachers', sub: 'Caring & Qualified Staff' },
  { ico: I.icoSafe, title: 'Safe Environment', sub: "Your Child's Safety First" },
  { ico: I.icoCreative, title: 'Creative Learning', sub: 'Through Fun & Play' },
  { ico: I.icoGrowth, title: 'Overall Development', sub: 'Study, Play & Grow' },
  { ico: I.icoParent, title: 'Parent Support', sub: 'Always With You' },
];

const NAV = [
  { href: '#home', label: 'Home', ico: I.icoHome },
  { href: '#about', label: 'About Us', ico: I.icoUsers },
  { href: '#classes', label: 'Classes', ico: I.icoBook },
  { href: '#gallery', label: 'Gallery', ico: I.icoImage },
  { href: '#notices', label: 'Notices', ico: I.icoBell },
  { href: '#admissions', label: 'Admissions', ico: I.icoCap },
  { href: '#contact', label: 'Contact', ico: I.icoPin },
];

function socialLinks(s: Settings) {
  return [
    { on: s.youtube_enabled === '1', url: safeUrl(s.youtube_url, '#'), ico: I.icoYouTube, label: 'YouTube' },
    { on: s.facebook_enabled === '1', url: safeUrl(s.facebook_url, '#'), ico: I.icoFacebook, label: 'Facebook' },
    { on: s.instagram_enabled === '1', url: safeUrl(s.instagram_url, '#'), ico: I.icoInstagram, label: 'Instagram' },
    { on: s.whatsapp_enabled === '1', url: whatsappUrl(s), ico: I.icoWhatsApp, label: 'WhatsApp' },
  ].filter((x) => x.on);
}

export function whatsappUrl(s: Settings): string {
  const num = String(s.whatsapp_number ?? '').replace(/[^\d]/g, '');
  const msg = encodeURIComponent(s.whatsapp_message ?? '');
  return num ? `https://wa.me/${num}${msg ? `?text=${msg}` : ''}` : '#';
}

export function renderHome(d: HomeData): string {
  const s = d.settings;
  const logo = s.logo_media_id ? d.mediaUrl(s.logo_media_id) : '/img/logo.jpg';
  const hero = s.hero_media_id ? d.mediaUrl(s.hero_media_id) : '/img/hero.jpg';
  const aboutArt = s.about_media_id ? d.mediaUrl(s.about_media_id) : '/img/about.jpg';
  const socials = socialLinks(s);
  const year = new Date().getFullYear();

  const pillarsHtml = PILLARS.map(
    (p) => `<div class="pillar">
        <span class="pillar-ico">${p.ico({ size: 38 })}</span>
        <span><span class="pillar-title">${escapeHtml(p.title)}</span><span class="pillar-sub">${escapeHtml(p.sub)}</span></span>
      </div>`,
  ).join('');

  const classHtml = d.classes
    .filter((c) => c.active !== 0)
    .map(
      (c, i) => `<button class="class-card" type="button" data-class="${escapeHtml(c.name)}" data-reveal="zoom" data-reveal-delay="${(i % 3) + 1}">
        <img src="/img/${escapeHtml(c.slug)}.jpg" alt="${escapeHtml(c.name)}" loading="lazy" decoding="async" width="92" height="92">
        <span class="cname">${escapeHtml(c.name)}</span>
        <span class="cage">${escapeHtml(c.age_group)}</span>
      </button>`,
    )
    .join('');

  const noticeHtml = d.notices
    .slice(0, 4)
    .map((n, i) => {
      const dt = monthAbbr(n.date);
      return `<button class="notice-row" type="button" data-notice="${escapeHtml(String(n.id))}" data-reveal data-reveal-delay="${i + 1}">
        <span class="notice-date"><span class="d">${dt.day}</span><span class="m">${dt.month}</span></span>
        <span class="notice-body"><span class="notice-title">${escapeHtml(n.title)}${n.is_new ? '<span class="badge-new">New</span>' : ''}</span></span>
        <span class="notice-arrow">${I.icoArrow({ size: 13 })}</span>
      </button>`;
    })
    .join('');

  const filledGalleries = d.galleries.filter((g) => g.items.length > 0);
  const galleryHtml = filledGalleries.length
    ? filledGalleries
        .map(
          (g) => `<div class="gallery-section" data-reveal>
        <div class="gallery-title">
          <span>${I.icoImage({ size: 18, cls: 'gallery-ico' })}</span>
          <h3>${escapeHtml(g.title)}</h3>
          <span class="sub">${escapeHtml(g.subtitle)}</span>
        </div>
        ${
          g.items.length
            ? `<div class="gallery-grid">${g.items
                .map(
                  (it, idx) => `<figure class="gallery-tile" data-photo="${escapeHtml(d.mediaUrl(it.media_id))}" data-caption="${escapeHtml(it.caption)}" data-reveal="zoom" data-reveal-delay="${(idx % 4) + 1}">
                <img src="${escapeHtml(d.mediaUrl(it.media_id))}" alt="${escapeHtml(it.caption || g.title)}" loading="lazy" decoding="async">
                ${it.caption ? `<figcaption>${escapeHtml(it.caption)}</figcaption>` : ''}
              </figure>`,
                )
                .join('')}</div>`
            : `<div class="gallery-empty">Photos from this section will appear here soon.</div>`
        }
      </div>`,
        )
        .join('')
    : `<div class="gallery-empty">Gallery photos will appear here once added by the school.</div>`;

  const eventsHtml = d.events.length
    ? d.events
        .slice(0, 6)
        .map((e, i) => {
          const dt = monthAbbr(e.date);
          return `<article class="event-card" data-reveal data-reveal-delay="${(i % 3) + 1}">
            <div class="event-date"><div class="d">${dt.day}</div><div class="m">${dt.month}</div></div>
            <div>
              <div class="event-title">${escapeHtml(e.title)}</div>
              <div class="event-desc">${escapeHtml(e.description)}</div>
            </div>
          </article>`;
        })
        .join('')
    : `<div class="gallery-empty">School events will be listed here.</div>`;

  const classOptions = d.classes
    .filter((c) => c.active !== 0)
    .map((c) => `<option value="${escapeHtml(c.name)}">${escapeHtml(c.name)}</option>`)
    .join('');

  const mapSrc = safeUrl(s.map_embed, '');
  const mapHtml = mapSrc
    ? `<iframe src="${escapeHtml(mapSrc)}" loading="lazy" referrerpolicy="no-referrer-when-downgrade" title="School location map" allowfullscreen></iframe>`
    : `<div class="gallery-empty" style="height:100%;display:grid;place-items:center">Map link not configured yet.</div>`;

  const payload = {
    settings: {
      school_name: s.school_name,
      short_name: s.short_name,
      tagline: s.tagline,
      phone: s.phone,
      email: s.email,
      address: s.address,
      admissions_open: s.admissions_open,
      admissions_note: s.admissions_note,
      whatsapp_url: whatsappUrl(s),
    },
    classes: d.classes.map((c) => ({ id: c.id, name: c.name, slug: c.slug, age: c.age_group, summary: c.summary })),
    notices: d.notices.map((n) => ({ id: n.id, title: n.title, body: n.body, date: n.date, isNew: n.is_new, author: '' })),
    gallery: d.galleries.map((g) => ({
      id: g.id,
      title: g.title,
      items: g.items.map((it) => ({ url: d.mediaUrl(it.media_id), caption: it.caption })),
    })),
  };

  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>${escapeHtml(s.school_name)} — ${escapeHtml(s.tagline)}, Chorawa Icha, Bihar</title>
<meta name="description" content="${escapeHtml(`${s.school_name} — ${s.tagline} at ${s.address}. Admission open for Play Class to Class 5. Safe campus, qualified teachers, caring environment.`)}">
<meta name="theme-color" content="#f2b01e">
<meta property="og:title" content="${escapeHtml(s.school_name)}">
<meta property="og:description" content="${escapeHtml(s.hero_sub)}">
<meta property="og:image" content="${escapeHtml(hero)}">
<meta property="og:type" content="website">
<link rel="icon" href="${escapeHtml(logo)}">
<link rel="preload" as="image" href="${escapeHtml(hero)}" fetchpriority="high">
<link rel="stylesheet" href="/style.css">
</head>
<body class="public-body">
<div class="topbar">
  <div class="wrap">
    <div class="topbar-items">
      <span class="topbar-item">${I.icoPin({ size: 13 })}<span>${escapeHtml(s.address)}</span></span>
      <span class="topbar-sep"></span>
      <a class="topbar-item" href="tel:${escapeHtml(String(s.phone).replace(/\s/g, ''))}">${I.icoPhone({ size: 13 })}<span>${escapeHtml(s.phone)}</span></a>
    </div>
    <div class="topbar-items">
      <a class="topbar-item mail" href="mailto:${escapeHtml(s.email)}">${I.icoMail({ size: 13 })}<span>${escapeHtml(s.email)}</span></a>
      <span class="topbar-sep mail"></span>
      <span class="top-social">
        ${socials.map((x) => `<a class="social-btn" href="${escapeHtml(x.url)}" target="_blank" rel="noopener noreferrer" aria-label="${escapeHtml(x.label)}">${x.ico({ size: 17 })}</a>`).join('')}
      </span>
    </div>
  </div>
</div>

<header class="site-header">
  <div class="wrap nav-shell">
    <a class="brand" href="#home" aria-label="${escapeHtml(s.school_name)} home">
      <img class="brand-logo" src="${escapeHtml(logo)}" alt="${escapeHtml(s.short_name)} logo" width="50" height="50">
      <span class="brand-text">
        <span class="brand-name">${escapeHtml(s.short_name)}</span>
        <span class="brand-sub">${escapeHtml(s.tagline)}</span>
      </span>
    </a>
    <nav class="nav-links" aria-label="Primary">
      ${NAV.map(
        (n, i) =>
          `<a class="nav-pill${i === 0 ? ' is-active' : ''}" href="${n.href}">${n.ico({ size: 15 })}<span>${n.label}</span></a>`,
      ).join('')}
    </nav>
    <div class="nav-actions">
      <a class="btn btn-primary" href="#admissions">${I.icoSend({ size: 15 })}<span>Enquiry</span></a>
      <button class="icon-btn nav-toggle" type="button" id="nav-toggle" aria-label="Open menu" aria-expanded="false" aria-controls="nav-drawer">${I.icoMenu({ size: 20 })}</button>
    </div>
  </div>
</header>

<main id="home">
  <section class="hero">
    <div class="hero-media"><img src="${escapeHtml(hero)}" alt="${escapeHtml(s.school_name)} campus" width="1600" height="893" fetchpriority="high"></div>
    <div class="wrap hero-inner">
      <div class="hero-copy">
        <span class="hero-badge">${I.icoSparkle({ size: 14 })}<span>${escapeHtml(s.play_learn_grow)}</span></span>
        <h1 class="hero-title">${escapeHtml(s.short_name)}<span class="gold">${escapeHtml(s.tagline)}</span></h1>
        <p class="hero-sub">${escapeHtml(s.hero_headline)}</p>
        <p class="hero-body">${escapeHtml(s.hero_sub)}</p>
        <div class="hero-actions">
          <a class="btn btn-primary btn-lg" href="#about">${I.icoCap({ size: 18 })}<span>Explore More</span>${I.icoArrow({ size: 14 })}</a>
          <a class="btn btn-secondary btn-lg" href="#gallery">${I.icoImage({ size: 17 })}<span>Our Gallery</span></a>
        </div>
      </div>
    </div>
  </section>

  <div class="pillar-strip">
    <div class="wrap"><div class="pillar-shell">${pillarsHtml}</div></div>
  </div>

  <section class="section" id="about">
    <div class="wrap">
      <div class="three-col">
        <article class="card">
          <div class="card-head">
            <span class="card-head-icon">${I.icoCrown({ size: 24 })}</span>
            <h2>${escapeHtml(s.about_title)}</h2>
          </div>
          <div class="about-grid">
            <p class="about-text">${escapeHtml(s.about_text)}</p>
            <div class="about-art"><img src="${escapeHtml(aboutArt)}" alt="Books and graduation cap" loading="lazy" width="132" height="132"></div>
          </div>
          <div class="about-meta">
            <div class="about-person">${I.icoPerson({ size: 18 })}<span><span class="k">Principal</span><span class="v">${escapeHtml(s.principal)}</span></span></div>
            <div class="about-person">${I.icoPerson({ size: 18 })}<span><span class="k">Director</span><span class="v">${escapeHtml(s.director)}</span></span></div>
          </div>
          <div class="about-cta">
            <a class="btn btn-primary btn-sm" href="#contact">${I.icoArrow({ size: 13 })}<span>Know More</span></a>
          </div>
        </article>

        <article class="card" id="classes">
          <div class="card-head">
            <span class="card-head-icon">${I.icoCap({ size: 24 })}</span>
            <h2>Our Classes</h2>
            <span class="spacer"></span>
            <span class="tag gold">Play Class – Class 5</span>
          </div>
          <div class="class-grid">${classHtml}</div>
        </article>

        <article class="card" id="notices">
          <div class="card-head">
            <span class="card-head-icon">${I.icoMegaphone({ size: 24 })}</span>
            <h2>Latest Notices</h2>
            <span class="spacer"></span>
            <a class="card-head-link" href="#notices-all">View All ${I.icoArrow({ size: 12 })}</a>
          </div>
          <div class="notice-list">${noticeHtml || '<div class="gallery-empty">No notices yet.</div>'}</div>
        </article>
      </div>
    </div>
  </section>

  <section class="section" id="gallery">
    <div class="wrap">
      <div class="sec-head" data-reveal>
        <span class="sec-kicker">${I.icoSparkle({ size: 12 })}<span>Our Memories</span></span>
        <h2 class="sec-title">Life at <span class="gold">${escapeHtml(s.short_name)}</span></h2>
        <p class="sec-sub">Real moments from our campus — celebrations, learning and everyday joy.</p>
      </div>
      <div class="card">${galleryHtml}</div>
    </div>
  </section>

  <section class="section" id="events">
    <div class="wrap">
      <div class="sec-head" data-reveal>
        <span class="sec-kicker">${I.icoSparkle({ size: 12 })}<span>School Calendar</span></span>
        <h2 class="sec-title">Events &amp; <span class="gold">Celebrations</span></h2>
      </div>
      <div class="event-grid">${eventsHtml}</div>
    </div>
  </section>

  <section class="section" id="admissions">
    <div class="wrap">
      <div class="card">
        <div class="sec-head" style="margin-bottom:16px" data-reveal>
          <span class="sec-kicker">${I.icoSparkle({ size: 12 })}<span>Admissions ${s.admissions_open === '1' ? 'Open' : 'Enquiry'}</span></span>
          <h2 class="sec-title">Admission <span class="gold">Enquiry</span></h2>
          <p class="sec-sub">${escapeHtml(s.admissions_note)}</p>
        </div>
        <div class="enquiry-grid">
          <div class="stickman-stage" data-reveal="left">
            ${stickmanSvg()}
            <div class="stickman-caption" id="stickman-caption">Fill the form — I'll do a happy dance!</div>
          </div>
          <form class="enquiry-form" id="enquiry-form" data-reveal="right" novalidate>
            <div class="form-grid">
              <div class="field">
                <label for="parent_name">Parent's Name <span class="req">*</span></label>
                <input class="input" id="parent_name" name="parent_name" type="text" autocomplete="name" maxlength="80" required placeholder="Your full name">
              </div>
              <div class="field">
                <label for="child_name">Child's Name <span class="req">*</span></label>
                <input class="input" id="child_name" name="child_name" type="text" maxlength="80" required placeholder="Child's name">
              </div>
              <div class="field">
                <label for="phone">Mobile Number <span class="req">*</span></label>
                <input class="input" id="phone" name="phone" type="tel" inputmode="numeric" autocomplete="tel" maxlength="15" required placeholder="10-digit mobile">
              </div>
              <div class="field">
                <label for="class_interested">Class <span class="req">*</span></label>
                <select class="select" id="class_interested" name="class_interested" required>
                  <option value="">Select class</option>
                  ${classOptions}
                </select>
              </div>
              <div class="field full">
                <label for="message">Message <span style="font-weight:600;color:#8b7659">(optional)</span></label>
                <textarea class="textarea" id="message" name="message" maxlength="600" placeholder="Anything you'd like to ask us?"></textarea>
              </div>
              <div class="field full">
                <div class="form-status" id="enquiry-status" role="status" aria-live="polite"></div>
                <button class="btn btn-primary btn-lg btn-block" type="submit" id="enquiry-submit">${I.icoSend({ size: 16 })}<span>Submit Enquiry</span></button>
                <p class="form-note" style="margin-top:8px">We usually reply within one working day. Your number is never shared.</p>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </section>

  <section class="section" id="contact">
    <div class="wrap">
      <div class="contact-grid">
        <div class="map-card" data-reveal="left">${mapHtml}</div>
        <div class="card contact-card" data-reveal="right">
          <div class="card-head">
            <span class="card-head-icon">${I.icoPin({ size: 22 })}</span>
            <h2>Reach Us</h2>
          </div>
          <div class="contact-line"><span class="ico">${I.icoPin({ size: 16 })}</span><span><span class="k">Address</span><span class="v">${escapeHtml(s.address)}</span></span></div>
          <div class="contact-line"><span class="ico">${I.icoPhone({ size: 16 })}</span><span><span class="k">Phone</span><span class="v"><a href="tel:${escapeHtml(String(s.phone).replace(/\s/g, ''))}">${escapeHtml(s.phone)}</a></span></span></div>
          <div class="contact-line"><span class="ico">${I.icoMail({ size: 16 })}</span><span><span class="k">Email</span><span class="v"><a href="mailto:${escapeHtml(s.email)}">${escapeHtml(s.email)}</a></span></span></div>
          <div class="contact-line"><span class="ico">${I.icoStar({ size: 16 })}</span><span><span class="k">Opening Ceremony</span><span class="v">${escapeHtml(formatDate(s.opening_date))}</span></span></div>
          <div style="display:flex;gap:9px;flex-wrap:wrap;margin-top:6px">
            <a class="btn btn-primary" href="${escapeHtml(safeUrl(s.map_directions, '#'))}" target="_blank" rel="noopener noreferrer">${I.icoPin({ size: 15 })}<span>Get Directions</span></a>
            <a class="btn btn-secondary" href="${escapeHtml(whatsappUrl(s))}" target="_blank" rel="noopener noreferrer">${I.icoWhatsApp({ size: 16 })}<span>WhatsApp</span></a>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="section" id="notices-all">
    <div class="wrap">
      <div class="card">
        <div class="card-head">
          <span class="card-head-icon">${I.icoMegaphone({ size: 22 })}</span>
          <h2>All Notices</h2>
        </div>
        <div class="notice-list">
          ${
            d.notices
              .map((n) => {
                const dt = monthAbbr(n.date);
                return `<button class="notice-row" type="button" data-notice="${escapeHtml(String(n.id))}">
                  <span class="notice-date"><span class="d">${dt.day}</span><span class="m">${dt.month}</span></span>
                  <span class="notice-body"><span class="notice-title">${escapeHtml(n.title)}${n.is_new ? '<span class="badge-new">New</span>' : ''}</span></span>
                  <span class="notice-arrow">${I.icoArrow({ size: 13 })}</span>
                </button>`;
              })
              .join('') || '<div class="gallery-empty">No notices published yet.</div>'
          }
        </div>
      </div>
    </div>
  </section>
</main>

<footer class="site-footer">
  <div class="wrap">
    <div class="footer-grid">
      <div>
        <div class="footer-brand">
          <img src="${escapeHtml(logo)}" alt="${escapeHtml(s.short_name)} logo" width="52" height="52" loading="lazy">
          <span>
            <span class="bn">${escapeHtml(s.short_name)}</span>
            <span class="bs">${escapeHtml(s.tagline)}</span>
            <span class="bt">${escapeHtml(s.footer_note)}</span>
          </span>
        </div>
        <p style="font-size:12.6px;color:#bda98a;margin-top:11px;line-height:1.55;max-width:290px">${escapeHtml(s.address)}. Play Class to Class 5, guided by caring qualified teachers.</p>
      </div>
      <div>
        <div class="footer-h">Quick Links</div>
        <div class="footer-links">
          ${NAV.map((n) => `<a class="footer-link" href="${n.href}">${I.icoArrow({ size: 11 })}<span>${n.label}</span></a>`).join('')}
        </div>
      </div>
      <div>
        <div class="footer-h">Contact Us</div>
        <div class="footer-contact">
          <a class="row" href="tel:${escapeHtml(String(s.phone).replace(/\s/g, ''))}">${I.icoPhone({ size: 14 })}<span>${escapeHtml(s.phone)}</span></a>
          <a class="row" href="mailto:${escapeHtml(s.email)}">${I.icoMail({ size: 14 })}<span>${escapeHtml(s.email)}</span></a>
          <span class="row">${I.icoPin({ size: 14 })}<span>${escapeHtml(s.address)}</span></span>
        </div>
      </div>
      <div>
        <div class="footer-h">Follow Us</div>
        <div class="footer-social">
          ${socials.map((x) => `<a class="social-btn" href="${escapeHtml(x.url)}" target="_blank" rel="noopener noreferrer" aria-label="${escapeHtml(x.label)}">${x.ico({ size: 19 })}</a>`).join('')}
        </div>
        <div class="footer-tag">Little Steps…<br>Big Dreams… <span class="heart">♥</span></div>
      </div>
    </div>
    <div class="footer-bottom">
      <span>© ${year} ${escapeHtml(s.school_name)}. All Rights Reserved.</span>
      <span class="made">Designed with <span class="h">♥</span> for a Better Tomorrow</span>
    </div>
  </div>
</footer>

<div class="social-dock" id="social-dock">
  <div class="dock-items">
    ${socials
      .map(
        (x) =>
          `<a class="dock-item" href="${escapeHtml(x.url)}" target="_blank" rel="noopener noreferrer" aria-label="${escapeHtml(x.label)}">${x.ico({ size: 24 })}</a>`,
      )
      .join('')}
  </div>
  <button class="dock-toggle" type="button" id="dock-toggle" aria-label="Social links" aria-expanded="false">${I.icoSparkle({ size: 22 })}</button>
</div>

<div class="scrim" id="scrim"></div>

<aside class="drawer" id="nav-drawer" aria-hidden="true" aria-label="Mobile menu">
  <div class="drawer-head">
    <span class="brand-name" style="font-size:16px">${escapeHtml(s.short_name)}</span>
    <button class="icon-btn drawer-close" type="button" data-close aria-label="Close menu">${I.icoClose({ size: 16 })}</button>
  </div>
  ${NAV.map((n) => `<a class="drawer-link" href="${n.href}" data-drawer-link>${n.ico({ size: 16 })}<span>${n.label}</span></a>`).join('')}
  <div class="drawer-foot">
    <a class="btn btn-primary btn-block" href="#admissions" data-drawer-link>${I.icoSend({ size: 15 })}<span>Send Enquiry</span></a>
    <a class="btn btn-secondary btn-block" href="/portal">${I.icoLock({ size: 15 })}<span>School Portal</span></a>
  </div>
</aside>

<div class="modal" id="notice-modal" role="dialog" aria-modal="true" aria-labelledby="notice-modal-title">
  <div class="modal-head">
    <h3 id="notice-modal-title">Notice</h3>
    <button class="icon-btn drawer-close" type="button" data-close aria-label="Close notice">${I.icoClose({ size: 16 })}</button>
  </div>
  <div class="modal-body" id="notice-modal-body"></div>
</div>

<div class="modal" id="photo-modal" role="dialog" aria-modal="true" aria-labelledby="photo-modal-title">
  <div class="modal-head">
    <h3 id="photo-modal-title">Photo</h3>
    <button class="icon-btn drawer-close" type="button" data-close aria-label="Close photo">${I.icoClose({ size: 16 })}</button>
  </div>
  <div class="modal-body"><img id="photo-modal-img" src="" alt="" style="width:100%;border-radius:14px"></div>
</div>

<div class="toast-wrap" id="toast-wrap" aria-live="polite"></div>

<script type="application/json" id="__NK_DATA__">${escapeJsonForScript(payload)}</script>
<script src="/public.js" defer></script>
</body>
</html>`;
}

export function renderFallback(message: string, detail = ''): string {
  return `<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>Nanhe Kadam Public School</title>
<link rel="stylesheet" href="/style.css"></head>
<body><div class="wrap" style="padding:60px 16px;text-align:center">
<h1 style="font-size:24px;color:#3d2b0f">${escapeHtml(message)}</h1>
${detail ? `<p style="color:#8b7659;margin-top:10px">${escapeHtml(detail)}</p>` : ''}
<p style="margin-top:20px"><a class="btn btn-primary" href="/">Reload home page</a></p>
</div></body></html>`;
}
