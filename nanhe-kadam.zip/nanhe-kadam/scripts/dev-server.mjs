#!/usr/bin/env node
/**
 * Local preview server (no Cloudflare account needed).
 * Runs the REAL worker code against an in-memory SQLite database seeded from
 * migrations/0001_reset.sql, so what you see locally is what deploys.
 *
 *   npm run dev          →  http://localhost:8787
 */
import { createServer } from 'node:http';
import { existsSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const PORT = Number(process.env.PORT || 8787);

const { default: Database } = await import('better-sqlite3');
const { readFileSync } = await import('node:fs');

/* ---- translate the real Worker source to runnable JS with esbuild-free tsc ---- */
if (!existsSync(path.join(root, 'frontend', 'embedded.ts'))) {
  console.error('frontend/embedded.ts is missing — run `npm run embed` first.');
  process.exit(1);
}

const buildDir = path.join(root, '.devbuild');
const { execSync } = await import('node:child_process');
execSync('npx tsc -p tsconfig.dev.json', { cwd: root, stdio: 'inherit' });

const workerModule = await import(pathToFileURL(path.join(buildDir, 'backend', 'src', 'index.js')).href);
const worker = workerModule.default;

/* ------------------------------ D1 over sqlite ------------------------------ */
const db = new Database(':memory:');
db.pragma('foreign_keys = ON');
db.exec(readFileSync(path.join(root, 'migrations', '0001_reset.sql'), 'utf8'));

class Stmt {
  constructor(sql) {
    this.sql = sql;
    this.params = [];
  }
  bind(...values) {
    this.params = values.map((v) => (v === undefined ? null : v));
    return this;
  }
  async first(col) {
    const row = db.prepare(this.sql).get(...this.params);
    if (!row) return null;
    return col ? row[col] ?? null : row;
  }
  async all() {
    return { results: db.prepare(this.sql).all(...this.params), success: true };
  }
  async run() {
    const info = db.prepare(this.sql).run(...this.params);
    return { success: true, meta: { changes: info.changes, last_row_id: Number(info.lastInsertRowid) } };
  }
}

const DB = {
  prepare: (sql) => new Stmt(sql),
  batch: async (stmts) => Promise.all(stmts.map((s) => s.run())),
  exec: async (sql) => {
    db.exec(sql);
    return { count: 0, duration: 0 };
  },
};

const env = {
  DB,
  BASE_URL: `http://localhost:${PORT}`,
  SCHOOL_NAME: 'Nanhe Kadam Public School',
  SESSION_SECRET: 'dev_session_secret_0123456789abcdef0123456789abcdef',
  CSRF_SECRET: 'dev_csrf_secret_0123456789abcdef0123456789abcdef',
};

/* -------------------------------- http bridge ------------------------------- */
const server = createServer(async (req, res) => {
  const chunks = [];
  for await (const chunk of req) chunks.push(chunk);
  const body = chunks.length ? Buffer.concat(chunks) : null;

  const url = `http://localhost:${PORT}${req.url}`;
  const headers = new Headers();
  for (const [k, v] of Object.entries(req.headers)) {
    if (typeof v === 'string') headers.set(k, v);
    else if (Array.isArray(v)) headers.set(k, v.join(','));
  }

  const request = new Request(url, {
    method: req.method,
    headers,
    body: ['GET', 'HEAD'].includes(req.method) ? undefined : body,
  });

  try {
    const response = await worker.fetch(request, env, { waitUntil() {}, passThroughOnException() {} });
    res.statusCode = response.status;
    response.headers.forEach((value, key) => {
      if (key === 'content-encoding' || key === 'transfer-encoding') return;
      res.setHeader(key, value);
    });
    const buf = Buffer.from(await response.arrayBuffer());
    res.end(buf);
  } catch (error) {
    console.error(error);
    res.statusCode = 500;
    res.end(String(error && error.stack ? error.stack : error));
  }
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`\n  Nanhe Kadam dev server → http://localhost:${PORT}`);
  console.log(`  portal                  → http://localhost:${PORT}/portal`);
  console.log(`  super admin             → Rakesh@1 / rakesh@7632 (sets a new password on first login)\n`);
});
