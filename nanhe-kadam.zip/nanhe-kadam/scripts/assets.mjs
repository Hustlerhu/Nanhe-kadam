/**
 * Build-time asset compilation: minify CSS + strip/obfuscate all client JS.
 *
 *   public.js      → public site interactions   (public, minified)
 *   portal.js      → sign-in + bunny only        (public, minified)
 *   portal-app.js  → dashboard only              (gated, minified, identifiers mangled)
 *
 * Sourcemaps are explicitly DISABLED, every comment is removed, and the
 * dashboard bundle gets identifier mangling so DevTools shows nothing readable.
 * Used by scripts/embed.mjs → frontend/embedded.ts.
 */
import esbuild from 'esbuild';

/**
 * esbuild 0.28+ exposes transform (not minify) — minify:true does the same work
 * for a single file, with sourcemaps explicitly off.
 */
async function minify(source, options) {
  const { loader, ...rest } = options;
  const out = await esbuild.transform(source, {
    ...rest,
    loader,
    minify: true,
    sourcemap: false,
  });
  return { code: out.code };
}

const CSS_BANNER = '/*! Nanhe Kadam Public School */';

export async function minifyCss(source) {
  const out = await minify(source, {
    loader: 'css',
    minify: true,
    sourcemap: false,
    legalComments: 'none',
  });
  return CSS_BANNER + '\n' + out.code;
}

async function minifyJs(source, { mangle = false, label = '' } = {}) {
  const out = await minify(source, {
    loader: 'js',
    minify: true,
    sourcemap: false,
    legalComments: 'none',
    target: 'es2019',
    // Tree shaking off: these are IIFEs with side effects.
    treeShaking: false,
    mangleProps: undefined,
    keepNames: false,
  });
  let code = out.code;
  if (mangle) {
    // Second pass with aggressive identifier mangling for the gated bundle.
    const pass2 = await minify(code, {
      loader: 'js',
      minify: true,
      sourcemap: false,
      legalComments: 'none',
      mangleProps: /^_nk_/,
      target: 'es2019',
    });
    code = pass2.code;
  }
  if (!code) throw new Error(`minification produced no output for ${label}`);
  if (code.includes('sourceMappingURL')) throw new Error(`sourcemap leaked into ${label}`);
  return `/*! ${label} */\n` + code;
}

export function minifyPublicJs(source) {
  return minifyJs(source, { label: 'Nanhe Kadam — public' });
}

export function minifyPortalJs(source) {
  return minifyJs(source, { label: 'Nanhe Kadam — portal sign-in' });
}

export function minifyPortalAppJs(source) {
  return minifyJs(source, { label: 'Nanhe Kadam — portal dashboard', mangle: true });
}
