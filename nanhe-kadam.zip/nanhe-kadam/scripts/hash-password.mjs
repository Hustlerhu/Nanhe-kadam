#!/usr/bin/env node
/**
 * scripts/hash-password.mjs
 * Generates a PBKDF2-SHA256 hash compatible with the Worker runtime.
 * Cloudflare caps PBKDF2 at 100,000 iterations — this script hard-codes it.
 *
 *   node scripts/hash-password.mjs "MyNewPassword"
 */
import { pbkdf2Sync, randomBytes } from 'node:crypto';

const ITERATIONS = 100_000; // hard Cloudflare Workers limit — never raise
const password = process.argv[2];

if (!password) {
  console.error('usage: node scripts/hash-password.mjs "<password>"');
  process.exit(1);
}

const salt = randomBytes(16);
const bits = pbkdf2Sync(password, salt, ITERATIONS, 32, 'sha256');
console.log(`pbkdf2$sha256$${ITERATIONS}$${salt.toString('base64')}$${bits.toString('base64')}`);
