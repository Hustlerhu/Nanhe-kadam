-- Storage Vault schema (accounts 2, 3 and 4)
-- Apply with:  npx wrangler d1 execute nanhe-kadam-vault --remote --file=schema.sql

CREATE TABLE IF NOT EXISTS vault_media (
  id          TEXT PRIMARY KEY,
  mime        TEXT NOT NULL DEFAULT 'image/jpeg',
  size_bytes  INTEGER NOT NULL DEFAULT 0,
  chunk_count INTEGER NOT NULL DEFAULT 0,
  created_at  TEXT NOT NULL
);

-- 512 KB raw per chunk → 683 KB base64 per row (under D1's 1 MB row limit)
CREATE TABLE IF NOT EXISTS vault_chunks (
  media_id    TEXT NOT NULL,
  chunk_index INTEGER NOT NULL,
  data        TEXT NOT NULL,
  PRIMARY KEY (media_id, chunk_index)
);

CREATE INDEX IF NOT EXISTS idx_vault_chunks ON vault_chunks(media_id);
