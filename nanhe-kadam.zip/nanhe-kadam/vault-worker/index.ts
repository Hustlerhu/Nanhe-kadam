/**
 * Nanhe Kadam — Storage Vault Worker
 * ===========================================================================
 * Deploy this exact same file to your 2nd, 3rd and 4th Gmail Cloudflare
 * accounts. Each one gives the school an extra 500 MB of free D1 storage, so
 * together with the Primary Worker you get 4 × 500 MB = 2,000 MB.
 *
 *   POST   /vault/put            { id, mime, data }  (data = base64 of the file)
 *   GET    /vault/get/:id        returns raw bytes
 *   DELETE /vault/:id            removes every chunk + the row
 *   GET    /vault/stats          { used_bytes, media_count }
 *   GET    /vault/health         { ok, name, used_bytes, media_count }
 *
 * Security: every request must carry the shared secret in the X-Vault-Secret
 * header. The Primary Worker is the only caller.
 *
 * Chunking: 512 KB raw per row → 683 KB base64 → safely under D1's 1 MB
 * per-row limit, so a 3 MB HD photo never triggers SQLITE_TOOBIG.
 */
interface VaultEnv {
  VAULT_DB: D1DatabaseLike;
  VAULT_SECRET?: string;
  VAULT_NAME?: string;
}

const CHUNK_SIZE = 512 * 1024;
const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'content-type, x-vault-secret',
  'Access-Control-Allow-Methods': 'GET, POST, DELETE, OPTIONS',
};

function jsonResponse(data: unknown, status = 200): Response {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-store',
      ...CORS,
    },
  });
}

function toBase64(bytes: Uint8Array): string {
  let bin = '';
  for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
  return btoa(bin);
}

function fromBase64(b64: string): Uint8Array {
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

/** SHA-256 digest, used to compare secrets without leaking their length. */
async function sha256Hex(input: string): Promise<Uint8Array> {
  const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(input));
  return new Uint8Array(digest);
}

/**
 * Constant-time secret check.
 * Both sides are hashed to a fixed 32 bytes first, so neither the length nor an
 * early prefix mismatch is observable, then compared with timingSafeEqual.
 */
async function authorised(request: Request, env: VaultEnv): Promise<boolean> {
  const expected = (env.VAULT_SECRET ?? '').trim();
  if (expected.length < 16) return false; // refuse to run unconfigured / weak
  const given = (request.headers.get('X-Vault-Secret') ?? '').trim();
  if (!given) return false;

  const [a, b] = await Promise.all([sha256Hex(given), sha256Hex(expected)]);
  // crypto.subtle.timingSafeEqual is available on Workers; fall back to a
  // constant-time byte loop on runtimes that do not expose it.
  const subtle = crypto.subtle as unknown as {
    timingSafeEqual?: (x: ArrayBufferView, y: ArrayBufferView) => boolean;
  };
  if (typeof subtle.timingSafeEqual === 'function') {
    try {
      return subtle.timingSafeEqual(a, b);
    } catch {
      return false;
    }
  }
  let diff = a.length ^ b.length;
  for (let i = 0; i < a.length; i++) diff |= a[i] ^ b[i];
  return diff === 0;
}

async function stats(db: D1DatabaseLike): Promise<{ used_bytes: number; media_count: number }> {
  const row = await db
    .prepare(
      `SELECT COALESCE(SUM(LENGTH(data)), 0) AS used,
              (SELECT COUNT(*) FROM vault_media) AS n
       FROM vault_chunks`,
    )
    .first<{ used: number; n: number }>();
  return { used_bytes: Number(row?.used ?? 0), media_count: Number(row?.n ?? 0) };
}

export default {
  async fetch(request: Request, env: VaultEnv): Promise<Response> {
    const url = new URL(request.url);
    const path = url.pathname.replace(/\/+$/, '') || '/';
    const method = request.method.toUpperCase();

    if (method === 'OPTIONS') return new Response(null, { status: 204, headers: CORS });

    if (!(await authorised(request, env))) {
      // Uniform response: never hint whether the vault exists, is configured,
      // or which part of the secret was wrong.
      return jsonResponse({ ok: false, error: 'Not found' }, 404);
    }

    try {
      if (path === '/vault/health' && method === 'GET') {
        const s = await stats(env.VAULT_DB);
        return jsonResponse({ ok: true, name: env.VAULT_NAME ?? 'Nanhe Kadam Storage Vault', ...s });
      }

      if (path === '/vault/stats' && method === 'GET') {
        return jsonResponse(await stats(env.VAULT_DB));
      }

      if (path === '/vault/put' && method === 'POST') {
        const body = (await request.json()) as { id?: string; mime?: string; data?: string };
        const id = String(body.id ?? '');
        const mime = String(body.mime ?? 'image/jpeg');
        if (!/^[A-Za-z0-9_.:-]{3,80}$/.test(id)) return jsonResponse({ ok: false, error: 'Bad id' }, 400);
        if (typeof body.data !== 'string' || body.data.length < 8) {
          return jsonResponse({ ok: false, error: 'Missing data' }, 400);
        }

        const bytes = fromBase64(body.data);
        const chunks: string[] = [];
        for (let i = 0; i < bytes.length; i += CHUNK_SIZE) {
          chunks.push(toBase64(bytes.subarray(i, Math.min(i + CHUNK_SIZE, bytes.length))));
        }

        await env.VAULT_DB.prepare(
          `INSERT OR REPLACE INTO vault_media (id, mime, size_bytes, chunk_count, created_at)
           VALUES (?, ?, ?, ?, ?)`,
        )
          .bind(id, mime, bytes.length, chunks.length, new Date().toISOString())
          .run();
        await env.VAULT_DB.prepare('DELETE FROM vault_chunks WHERE media_id = ?').bind(id).run();

        const stmts = chunks.map((data, index) =>
          env.VAULT_DB.prepare('INSERT INTO vault_chunks (media_id, chunk_index, data) VALUES (?, ?, ?)').bind(
            id,
            index,
            data,
          ),
        );
        for (let i = 0; i < stmts.length; i += 20) {
          await env.VAULT_DB.batch(stmts.slice(i, i + 20));
        }

        return jsonResponse({ ok: true, id, bytes: bytes.length, chunk_count: chunks.length }, 201);
      }

      const getMatch = /^\/vault\/get\/([A-Za-z0-9_.:-]{3,80})$/.exec(path);
      if (getMatch && method === 'GET') {
        const id = getMatch[1];
        const meta = await env.VAULT_DB.prepare('SELECT mime FROM vault_media WHERE id = ?')
          .bind(id)
          .first<{ mime: string }>();
        if (!meta) return jsonResponse({ ok: false, error: 'Not found' }, 404);

        const rows = await env.VAULT_DB.prepare(
          'SELECT data FROM vault_chunks WHERE media_id = ? ORDER BY chunk_index ASC',
        )
          .bind(id)
          .all<{ data: string }>();

        const parts = (rows.results ?? []).map((r) => fromBase64(r.data));
        if (!parts.length) return jsonResponse({ ok: false, error: 'No chunks' }, 404);

        const total = parts.reduce((a, p) => a + p.length, 0);
        const out = new Uint8Array(total);
        let offset = 0;
        for (const part of parts) {
          out.set(part, offset);
          offset += part.length;
        }

        return new Response(out as unknown as BodyInit, {
          status: 200,
          headers: {
            'Content-Type': meta.mime,
            'Content-Length': String(out.length),
            'Cache-Control': 'public, max-age=3600',
            'X-Content-Type-Options': 'nosniff',
            ...CORS,
          },
        });
      }

      const delMatch = /^\/vault\/([A-Za-z0-9_.:-]{3,80})$/.exec(path);
      if (delMatch && method === 'DELETE') {
        const id = delMatch[1];
        await env.VAULT_DB.prepare('DELETE FROM vault_chunks WHERE media_id = ?').bind(id).run();
        await env.VAULT_DB.prepare('DELETE FROM vault_media WHERE id = ?').bind(id).run();
        return jsonResponse({ ok: true, deleted: id });
      }

      return jsonResponse({ ok: false, error: 'Not found' }, 404);
    } catch (error) {
      // Log locally, return nothing revealing (no SQL, no binding names).
      console.error('[vault] error:', error instanceof Error ? error.message : String(error));
      return jsonResponse({ ok: false, error: 'Internal error' }, 500);
    }
  },
};
