#!/usr/bin/env bash
# ===========================================================================
#  Nanhe Kadam — one-command Storage Vault deployment
#
#  Run this ONCE PER EXTRA CLOUDFLARE ACCOUNT (2nd, 3rd and 4th Gmail):
#
#      bash deploy-vault.sh 2
#      bash deploy-vault.sh 3        # after `npx wrangler login` with account 3
#      bash deploy-vault.sh 4        # after `npx wrangler login` with account 4
#
#  It will:
#    • create (or reuse) a free D1 database named nanhe-kadam-vault
#    • apply schema.sql
#    • generate a strong shared secret, store it as a Worker secret
#    • deploy the Worker and print the exact URL + secret to paste into
#      Portal → Storage Pool
# ===========================================================================
set -euo pipefail

VAULT_INDEX="${1:-2}"
case "$VAULT_INDEX" in
  2|3|4) ;;
  *) echo "usage: bash deploy-vault.sh <2|3|4>"; exit 1 ;;
esac

BLUE='\033[0;34m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
say()  { printf "${BLUE}▸${NC} %s\n" "$1"; }
ok()   { printf "${GREEN}✓${NC} %s\n" "$1"; }
warn() { printf "${YELLOW}!${NC} %s\n" "$1"; }
die()  { printf "${RED}✗${NC} %s\n" "$1"; exit 1; }

cd "$(dirname "$0")"

WITH_INDEX="${WORKER_WITH_INDEX:-1}"          # set to 0 to keep the plain name
if [ "$WITH_INDEX" = "1" ]; then
  WORKER_NAME="nanhe-kadam-vault-${VAULT_INDEX}"
else
  WORKER_NAME="nanhe-kadam-vault"
fi
DB_NAME="nanhe-kadam-vault"

printf "\n${GREEN}Nanhe Kadam — Storage Vault %s${NC}\n" "$VAULT_INDEX"
printf "worker : %s\nd1     : %s\n\n" "$WORKER_NAME" "$DB_NAME"

command -v npx >/dev/null 2>&1 || die "wrangler is required (npm i -g wrangler)"

warn "Make sure you are logged in to Cloudflare account #${VAULT_INDEX}:"
warn "   npx wrangler whoami      (shows the active account)"
printf "\n"

# ---- 1. D1 database -------------------------------------------------------
say "Creating D1 database (reusing it if it already exists)…"
CREATE_LOG="$(mktemp)"
if npx wrangler d1 create "$DB_NAME" 2>&1 | tee "$CREATE_LOG"; then
  ok "database created"
else
  warn "create failed — assuming it already exists, continuing"
fi

DB_ID="$(grep -Eo '[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}' "$CREATE_LOG" | head -n1 || true)"
rm -f "$CREATE_LOG"

if [ -z "${DB_ID:-}" ]; then
  say "Looking up the existing database id…"
  DB_ID="$(npx wrangler d1 list --json 2>/dev/null \
    | tr -d '\n ' \
    | grep -Eo "\"name\":\"${DB_NAME}\"[^}]*\"uuid\":\"[0-9a-f-]{36}\"" \
    | grep -Eo '[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}' \
    | head -n1 || true)"
fi

[ -n "${DB_ID:-}" ] || die "Could not determine the D1 database_id. Run 'npx wrangler d1 list' and paste it into wrangler.toml manually."
ok "database_id: $DB_ID"

# ---- 2. wrangler.toml for THIS vault --------------------------------------
say "Writing wrangler.toml for $WORKER_NAME…"
cat > wrangler.toml <<TOML
name = "${WORKER_NAME}"
main = "index.ts"
compatibility_date = "2024-11-01"
workers_dev = true

[[d1_databases]]
binding = "VAULT_DB"
database_name = "${DB_NAME}"
database_id = "${DB_ID}"

[vars]
VAULT_NAME = "Nanhe Kadam Storage Vault ${VAULT_INDEX}"

[observability]
enabled = true

[limits]
cpu_ms = 100
TOML
ok "wrangler.toml written"

# ---- 3. schema ------------------------------------------------------------
say "Applying vault schema…"
npx wrangler d1 execute "$DB_NAME" --remote --file=schema.sql -y
ok "schema applied"

# ---- 4. secret ------------------------------------------------------------
SECRET="${VAULT_SECRET:-}"
if [ -z "$SECRET" ]; then
  SECRET="vk_$(LC_ALL=C tr -dc 'a-f0-9' </dev/urandom | head -c 40)"
fi
say "Storing VAULT_SECRET as a Worker secret…"
printf '%s' "$SECRET" | npx wrangler secret put VAULT_SECRET
ok "secret stored"

# ---- 5. deploy ------------------------------------------------------------
say "Deploying $WORKER_NAME…"
DEPLOY_LOG="$(npx wrangler deploy 2>&1 | tee /dev/stderr)"
VAULT_URL="$(printf '%s' "$DEPLOY_LOG" | grep -Eo 'https://[a-z0-9.-]+\.workers\.dev' | head -n1 || true)"

if [ -z "${VAULT_URL:-}" ]; then
  VAULT_URL="https://${WORKER_NAME}.<your-subdomain>.workers.dev"
  warn "Could not read the deployed URL automatically — copy it from the output above."
fi

printf "\n${GREEN}Vault %s is live.${NC}\n\n" "$VAULT_INDEX"
printf "Paste these into Portal → Storage Pool → Vault %s:\n\n" "$VAULT_INDEX"
printf "  URL    : %s\n" "$VAULT_URL"
printf "  Secret : %s\n\n" "$SECRET"
printf "Then click “Test all connections” to confirm all four accounts are pooled.\n"
printf "Total free capacity once all three are connected: 2,000 MB.\n\n"
