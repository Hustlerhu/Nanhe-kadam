/** Builds a Worker-compatible Env around the SQLite D1 shim. */
import { D1Shim } from './d1-shim.js';
import type { Env } from '../backend/src/env.js';

export interface TestEnv extends Env {
  __shim: D1Shim;
}

export function makeEnv(overrides: Partial<Env> = {}): TestEnv {
  const shim = new D1Shim();
  const env = {
    DB: shim as unknown as D1DatabaseLike,
    BASE_URL: 'https://nanhe-kadam.empathy-life-jelly.workers.dev',
    SCHOOL_NAME: 'Nanhe Kadam Public School',
    SESSION_SECRET: 'test_session_secret_0123456789abcdef0123456789abcdef',
    CSRF_SECRET: 'test_csrf_secret_0123456789abcdef0123456789abcdef',
    VAULT_2_URL: '',
    VAULT_2_SECRET: '',
    VAULT_3_URL: '',
    VAULT_3_SECRET: '',
    VAULT_4_URL: '',
    VAULT_4_SECRET: '',
    __shim: shim,
    ...overrides,
  } as TestEnv;
  return env;
}

export function closeEnv(env: TestEnv): void {
  env.__shim.close();
}
