/** PBKDF2 contract, session signing, CSRF tokens and the seeded Super Admin. */
import { describe, it, expect } from 'vitest';
import {
  PBKDF2_ITERATIONS,
  createCsrfToken,
  pbkdf2Hash,
  pbkdf2Verify,
  signSessionId,
  unsignSessionId,
  safeEqual,
  escapeHtml,
  escapeJsonForScript,
  verifyCsrfToken,
} from '../backend/src/lib/crypto.js';
import { makeEnv, closeEnv } from './env.js';
import { findUserByUsername } from '../backend/src/lib/db.js';

const SECRET = 'unit_test_secret_0123456789abcdef';

describe('PBKDF2-SHA256', () => {
  it('uses exactly 100,000 iterations (Cloudflare hard limit)', () => {
    expect(PBKDF2_ITERATIONS).toBe(100_000);
  });

  it('hashes and verifies correctly', async () => {
    const hash = await pbkdf2Hash('rakesh@7632');
    expect(hash.startsWith('pbkdf2$sha256$100000$')).toBe(true);
    expect(await pbkdf2Verify('rakesh@7632', hash)).toBe(true);
    expect(await pbkdf2Verify('wrong-password', hash)).toBe(false);
  });

  it('refuses to verify a hash minted with more than 100,000 iterations', async () => {
    const bogus = 'pbkdf2$sha256$210000$AAAAAAAAAAAAAAAAAAAAAA==$AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=';
    expect(await pbkdf2Verify('anything', bogus)).toBe(false);
  });

  it('produces a different hash per salt', async () => {
    const a = await pbkdf2Hash('same-password');
    const b = await pbkdf2Hash('same-password');
    expect(a).not.toBe(b);
    expect(await pbkdf2Verify('same-password', a)).toBe(true);
    expect(await pbkdf2Verify('same-password', b)).toBe(true);
  });

  it('verifies the seeded Super Admin password from migrations/0001_reset.sql', async () => {
    const env = makeEnv();
    const user = await findUserByUsername(env, 'Rakesh@1');
    expect(user).not.toBeNull();
    expect(user!.role).toBe('super_admin');
    expect(user!.must_change_password).toBe(1);
    expect(await pbkdf2Verify('rakesh@7632', user!.password_hash)).toBe(true);
    expect(await pbkdf2Verify('nope', user!.password_hash)).toBe(false);
    closeEnv(env);
  });
});

describe('session cookies', () => {
  it('signs and unsigns a session id', async () => {
    const sid = 'a'.repeat(64);
    const signed = await signSessionId(SECRET, sid);
    expect(await unsignSessionId(SECRET, signed)).toBe(sid);
  });

  it('rejects a tampered cookie', async () => {
    const sid = 'b'.repeat(64);
    const signed = await signSessionId(SECRET, sid);
    const tampered = signed.replace(/.$/, 'f');
    expect(await unsignSessionId(SECRET, tampered)).toBeNull();
  });

  it('rejects a cookie signed with a different secret', async () => {
    const sid = 'c'.repeat(64);
    const signed = await signSessionId(SECRET, sid);
    expect(await unsignSessionId('another_secret_0123456789abcdef', signed)).toBeNull();
  });
});

describe('CSRF tokens', () => {
  it('round-trips for the bound session', async () => {
    const token = await createCsrfToken(SECRET, 'sess-1');
    expect(await verifyCsrfToken(SECRET, token, 'sess-1')).toBe(true);
  });

  it('rejects a token minted for another session', async () => {
    const token = await createCsrfToken(SECRET, 'sess-1');
    expect(await verifyCsrfToken(SECRET, token, 'sess-2')).toBe(false);
  });

  it('rejects an expired token', async () => {
    const token = await createCsrfToken(SECRET, 'sess-1', -1000);
    expect(await verifyCsrfToken(SECRET, token, 'sess-1')).toBe(false);
  });

  it('rejects garbage', async () => {
    expect(await verifyCsrfToken(SECRET, '', 'sess-1')).toBe(false);
    expect(await verifyCsrfToken(SECRET, 'not-a-token', 'sess-1')).toBe(false);
  });
});

describe('output escaping', () => {
  it('escapes HTML metacharacters', () => {
    expect(escapeHtml('<script>alert("x")</script>')).toBe(
      '&lt;script&gt;alert(&quot;x&quot;)&lt;/script&gt;',
    );
    expect(escapeHtml("O'Brien & sons")).toBe('O&#39;Brien &amp; sons');
  });

  it('makes JSON safe for inline <script> payloads', () => {
    const out = escapeJsonForScript({ name: '</script><img onerror=alert(1)>' });
    expect(out).not.toContain('</script>');
    expect(out).toContain('\\u003c');
  });

  it('compares strings in constant time safely', () => {
    expect(safeEqual('abc', 'abc')).toBe(true);
    expect(safeEqual('abc', 'abd')).toBe(false);
    expect(safeEqual('abc', 'abcd')).toBe(false);
  });
});
