/**
 * Verifies the D1 storage contract:
 *  • a 3 MB HD upload splits into rows that are all far below D1's 1 MB limit
 *  • reassembly is byte-perfect
 *  • the shard pool reports usage and deletes leave zero orphans
 */
import { describe, it, expect } from 'vitest';
import { makeEnv, closeEnv } from './env.js';
import {
  CHUNK_SIZE,
  MAX_UPLOAD_BYTES,
  SHARD_CAPACITY_BYTES,
  deleteMedia,
  findMedia,
  poolSummary,
  readMedia,
  storeMedia,
} from '../backend/src/lib/media.js';
import { assertRowSizes } from './d1-shim.js';

function syntheticPhoto(bytes: number): Uint8Array {
  // Deterministic pseudo-random bytes so the comparison is meaningful.
  const out = new Uint8Array(bytes);
  let seed = 123456789;
  for (let i = 0; i < bytes; i++) {
    seed = (seed * 1103515245 + 12345) & 0x7fffffff;
    out[i] = seed & 0xff;
  }
  return out;
}

describe('D1 media chunking (3 MB HD photos)', () => {
  it('keeps every chunk row well under the 1 MB D1 limit', async () => {
    const env = makeEnv();
    const photo = syntheticPhoto(MAX_UPLOAD_BYTES); // full 3 MB
    const stored = await storeMedia(env, { id: 'test_photo_1', mime: 'image/webp', bytes: photo });
    expect(stored).not.toBeNull();
    expect(stored!.shardId).toBe(1);
    expect(stored!.bytes).toBe(MAX_UPLOAD_BYTES);
    // 3 MB / 512 KB raw = 6 chunks; base64 of each ≈ 683 KB.
    expect(stored!.chunks).toBe(Math.ceil(MAX_UPLOAD_BYTES / CHUNK_SIZE));
    expect(() => assertRowSizes(env.__shim.db)).not.toThrow();
    closeEnv(env);
  });

  it('reassembles the exact original bytes', async () => {
    const env = makeEnv();
    const photo = syntheticPhoto(2_400_000);
    await storeMedia(env, { id: 'test_photo_2', mime: 'image/webp', bytes: photo });
    const rec = await findMedia(env, 'test_photo_2');
    expect(rec).not.toBeNull();
    const back = await readMedia(env, rec!);
    expect(back).not.toBeNull();
    expect(back!.bytes.length).toBe(photo.length);
    let identical = true;
    for (let i = 0; i < photo.length; i += 997) {
      if (back!.bytes[i] !== photo[i]) {
        identical = false;
        break;
      }
    }
    expect(identical).toBe(true);
    closeEnv(env);
  });

  it('reports pool usage against the 2,000 MB / 4-account capacity', async () => {
    const env = makeEnv();
    await storeMedia(env, { id: 'p_a', mime: 'image/webp', bytes: syntheticPhoto(600_000) });
    await storeMedia(env, { id: 'p_b', mime: 'image/webp', bytes: syntheticPhoto(400_000) });
    const pool = await poolSummary(env);
    expect(pool.capacityBytes).toBe(SHARD_CAPACITY_BYTES * 4);
    expect(pool.shards).toHaveLength(4);
    expect(pool.shards[0].usedBytes).toBeGreaterThan(0);
    expect(pool.usedBytes).toBeGreaterThan(0);
    expect(pool.connectedShards).toBe(1); // only vault 1 configured in tests
    closeEnv(env);
  });

  it('deletes every chunk of a media asset (no orphans)', async () => {
    const env = makeEnv();
    const photo = syntheticPhoto(900_000);
    await storeMedia(env, { id: 'p_del', mime: 'image/webp', bytes: photo });
    const before = env.__shim.db
      .prepare('SELECT COUNT(*) AS n FROM media_chunks WHERE media_id = ?')
      .get('p_del') as { n: number };
    expect(before.n).toBeGreaterThan(0);

    const done = await deleteMedia(env, 'p_del');
    expect(done).toBe(true);

    const chunks = env.__shim.db
      .prepare('SELECT COUNT(*) AS n FROM media_chunks WHERE media_id = ?')
      .get('p_del') as { n: number };
    const rows = env.__shim.db.prepare('SELECT COUNT(*) AS n FROM media WHERE id = ?').get('p_del') as { n: number };
    const index = env.__shim.db.prepare('SELECT COUNT(*) AS n FROM media_index WHERE id = ?').get('p_del') as { n: number };
    expect(chunks.n).toBe(0);
    expect(rows.n).toBe(0);
    expect(index.n).toBe(0);
    closeEnv(env);
  });

  it('rejects nothing at exactly 3 MB but the API layer enforces the cap', () => {
    expect(MAX_UPLOAD_BYTES).toBe(3 * 1024 * 1024);
    expect(CHUNK_SIZE).toBe(512 * 1024);
    // base64 expansion must stay under the 1 MB row limit
    expect(Math.ceil((CHUNK_SIZE * 4) / 3)).toBeLessThan(1_000_000);
  });
});
