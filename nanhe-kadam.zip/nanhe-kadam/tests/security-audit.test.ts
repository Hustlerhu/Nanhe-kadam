/**
 * Security & code-leak audit.
 * These tests read the ACTUAL bytes returned by the Worker for every public
 * route and assert that nothing internal can escape — dashboard code, admin
 * endpoint shapes, SQL, shard URLs, comments or sourcemap references.
 */
import { describe, it, expect } from 'vitest';
import worker from '../backend/src/index.js';
import { makeEnv, closeEnv, type TestEnv } from './env.js';
import { createCsrfToken, randomHex, signSessionId } from '../backend/src/lib/crypto.js';
import { pbkdf2Hash } from '../backend/src/lib/crypto.js';

const BASE = 'https://nanhe-kadam.empathy-life-jelly.workers.dev';
const SESSION_SECRET = 'test_session_secret_0123456789abcdef0123456789abcdef';
const CSRF_SECRET = 'test_csrf_secret_0123456789abcdef0123456789abcdef';

const req = (path: string, init: RequestInit = {}) => new Request(`${BASE}${path}`, init);
const call = (env: TestEnv, r: Request) => worker.fetch(r, env as never);

/** Everything that must never appear in a public response body. */
const FORBIDDEN = [
  '/api/admin',
  'data-view-link',
  'Combined Storage Meter',
  'vault_2_secret',
  'VAULT_SECRET',
  'media_chunks',
  'media_index',
  'teacher_salaries',
  'teacher_assignments',
  'rate_limits',
  'audit_log',
  'CREATE TABLE',
  'SELECT ',
  'INSERT INTO',
  'sqlite',
  'SQLITE_TOOBIG',
  'sourceMappingURL',
  '//# sourceURL',
  'password_hash',
  'pbkdf2$sha256',
  'SESSION_SECRET',
  'CSRF_SECRET',
  'account_id',
  'workers.dev/api',
];

async function signedIn(env: TestEnv, role: 'super_admin' | 'co_admin' | 'teacher' = 'super_admin', mustChange = 0) {
  const sid = randomHex(32);
  let userId = 1;
  if (role !== 'super_admin') {
    const hash = await pbkdf2Hash('role-pass-1234');
    env.__shim.db
      .prepare(
        "INSERT INTO users (username, password_hash, role, full_name, must_change_password, active, created_at) VALUES (?, ?, ?, 'Role User', 0, 1, ?)",
      )
      .run(`user_${role}`, hash, role, new Date().toISOString());
    userId = (env.__shim.db.prepare('SELECT id FROM users WHERE username = ?').get(`user_${role}`) as { id: number }).id;
  } else {
    env.__shim.db.prepare('UPDATE users SET must_change_password = ? WHERE id = 1').run(mustChange);
  }
  env.__shim.db
    .prepare('INSERT INTO sessions (id, user_id, created_at, expires_at, ip, user_agent) VALUES (?, ?, ?, ?, ?, ?)')
    .run(sid, userId, new Date().toISOString(), new Date(Date.now() + 3600_000).toISOString(), '127.0.0.1', 'vitest');
  return { sid, cookie: `nk_sess=${await signSessionId(SESSION_SECRET, sid)}`, userId };
}

describe('public responses leak nothing', () => {
  const routes: Array<[string, string]> = [
    ['/', 'homepage HTML'],
    ['/public.js', 'public bundle'],
    ['/style.css', 'stylesheet'],
    ['/portal', 'login page'],
    ['/robots.txt', 'robots'],
    ['/api/health', 'health JSON'],
    ['/api/notices', 'public notices JSON'],
    ['/this-page-does-not-exist', '404 page'],
  ];

  for (const [path, label] of routes) {
    it(`${label} (${path}) contains no internal references`, async () => {
      const env = makeEnv();
      const res = await call(env, req(path));
      const body = await res.text();
      for (const needle of FORBIDDEN) {
        expect(body.includes(needle), `leaked "${needle}" in ${path}`).toBe(false);
      }
      expect(res.headers.get('Content-Security-Policy')).toBeTruthy();
      closeEnv(env);
    });
  }

  it('the public stylesheet carries no app-shell or login selectors', async () => {
    const env = makeEnv();
    const css = await (await call(env, req('/style.css'))).text();
    for (const selector of ['.portal-side', '.portal-app', '.portal-view', '.stat-card', '.meter', '.portal-body', 'nk-bunny']) {
      expect(css.includes(selector), `public CSS leaked "${selector}"`).toBe(false);
    }
    closeEnv(env);
  });

  it('serves the login page without any dashboard JavaScript', async () => {
    const env = makeEnv();
    const body = await (await call(env, req('/portal'))).text();
    // login page must reference the sign-in bundle only
    expect(body).toContain('/portal.js');
    expect(body).not.toContain('/portal-app.js');
    closeEnv(env);
  });

  it('/portal.js is the sign-in bundle: no upload pipeline, no dashboard router', async () => {
    const env = makeEnv();
    const res = await call(env, req('/portal.js'));
    expect(res.status).toBe(200);
    const js = await res.text();
    // dashboard-only concepts must be absent
    for (const needle of ['initDashboard', 'api/admin', 'prepareImage', 'uploadPhoto', 'data-view-link', 'Storage Pool']) {
      expect(js.includes(needle), `sign-in bundle leaked "${needle}"`).toBe(false);
    }
    // but the bunny + login wiring must be there
    expect(js).toContain('nk-bunny');
    // minified: no comments, no sourcemaps
    expect(js).not.toContain('sourceMappingURL');
    expect(js.length).toBeLessThan(20_000);
    closeEnv(env);
  });

  it('minified bundles contain no developer comments', async () => {
    const env = makeEnv();
    for (const path of ['/public.js', '/portal.js', '/style.css']) {
      const text = await (await call(env, req(path))).text();
      expect(text.includes('/* ====='), `${path} kept a banner comment`).toBe(false);
      expect(text.includes('==================================='), `${path} kept a banner`).toBe(false);
      expect(text.includes('sourceMappingURL'), `${path} references a sourcemap`).toBe(false);
    }
    closeEnv(env);
  });

  it('minified public JS is meaningfully smaller than the source', async () => {
    const env = makeEnv();
    const js = await (await call(env, req('/public.js'))).text();
    expect(js.length).toBeLessThan(13_000); // source is ~15.6 KB
    const lines = js.split('\n').filter(Boolean).length;
    expect(lines).toBeLessThan(12); // minified to a handful of long lines
    closeEnv(env);
  });
});

describe('dashboard assets are gated at the edge', () => {
  it('/portal-app.js refuses an anonymous navigation with a redirect', async () => {
    const env = makeEnv();
    const res = await call(env, req('/portal-app.js'));
    expect(res.status).toBe(302);
    expect(res.headers.get('Location')).toBe('/portal');
    expect(await res.text()).toBe('');
    closeEnv(env);
  });

  it('/portal-app.js refuses a <script> fetch with 401 and no body', async () => {
    const env = makeEnv();
    const res = await call(env, req('/portal-app.js', { headers: { Accept: 'application/javascript' } }));
    expect(res.status).toBe(401);
    const body = await res.text();
    expect(body).not.toContain('initDashboard');
    closeEnv(env);
  });

  it('/portal-app.js refuses a forged cookie', async () => {
    const env = makeEnv();
    const res = await call(env, req('/portal-app.js', { headers: { Cookie: 'nk_sess=abc.def' } }));
    expect(res.status).toBe(302);
    closeEnv(env);
  });

  it('/portal-app.js is served to a valid session', async () => {
    const env = makeEnv();
    const { cookie } = await signedIn(env);
    const res = await call(env, req('/portal-app.js', { headers: { Cookie: cookie } }));
    expect(res.status).toBe(200);
    const js = await res.text();
    expect(js).toContain('/api/admin/');
    expect(js).not.toContain('sourceMappingURL');
    expect(res.headers.get('Cache-Control')).toContain('no-store');
    closeEnv(env);
  });

  it('/dashboard.css is gated exactly like the dashboard bundle', async () => {
    const env = makeEnv();
    const anon = await call(env, req('/dashboard.css'));
    expect(anon.status).toBe(302);
    expect(await anon.text()).toBe('');

    const { cookie } = await signedIn(env);
    const okRes = await call(env, req('/dashboard.css', { headers: { Cookie: cookie } }));
    expect(okRes.status).toBe(200);
    expect(await okRes.text()).toContain('.portal-app');
    closeEnv(env);
  });

  it('/portal/dashboard sends zero dashboard bytes without a session', async () => {
    const env = makeEnv();
    const res = await call(env, req('/portal/dashboard'));
    expect(res.status).toBe(302);
    expect(res.headers.get('Location')).toBe('/portal');
    expect((await res.text()).length).toBe(0);
    closeEnv(env);
  });

  it('/portal/dashboard sends zero dashboard bytes for an expired session', async () => {
    const env = makeEnv();
    const sid = randomHex(32);
    env.__shim.db
      .prepare('INSERT INTO sessions (id, user_id, created_at, expires_at, ip, user_agent) VALUES (?, 1, ?, ?, ?, ?)')
      .run(sid, new Date(Date.now() - 7200_000).toISOString(), new Date(Date.now() - 3600_000).toISOString(), '::1', 'vitest');
    const cookie = `nk_sess=${await signSessionId(SESSION_SECRET, sid)}`;
    const res = await call(env, req('/portal/dashboard', { headers: { Cookie: cookie } }));
    expect(res.status).toBe(302);
    expect((await res.text()).length).toBe(0);
    closeEnv(env);
  });

  it('/portal/dashboard sends zero bytes when must_change_password is set', async () => {
    const env = makeEnv();
    const { cookie } = await signedIn(env, 'super_admin', 1);
    const res = await call(env, req('/portal/dashboard', { headers: { Cookie: cookie } }));
    expect(res.status).toBe(302);
    expect(res.headers.get('Location')).toBe('/portal/password');
    closeEnv(env);
  });

  it('a teacher dashboard contains no staff, salary or account markup', async () => {
    const env = makeEnv();
    const { cookie } = await signedIn(env, 'teacher');
    const html = await (await call(env, req('/portal/dashboard', { headers: { Cookie: cookie } }))).text();
    expect(html).toContain('My Classes');
    for (const needle of [
      'Combined Storage Meter',
      'vault_2_secret',
      'Create Co-Admin or Teacher Login',
      'Salary Records',
      'Mark Attendance',
      'Admission Enquiries</h2>',
      'view-title">Storage Pool',
    ]) {
      expect(html.includes(needle), `teacher page leaked "${needle}"`).toBe(false);
    }
    closeEnv(env);
  });
});

describe('response headers and error hygiene', () => {
  it('every route carries the hardened header set', async () => {
    const env = makeEnv();
    for (const path of ['/', '/style.css', '/public.js', '/portal', '/api/health', '/nope']) {
      const res = await call(env, req(path));
      expect(res.headers.get('X-Frame-Options')).toBe('DENY');
      expect(res.headers.get('X-Content-Type-Options')).toBe('nosniff');
      expect(res.headers.get('Referrer-Policy')).toBe('no-referrer');
      expect(res.headers.get('Permissions-Policy')).toContain('camera=()');
      expect(res.headers.get('Cross-Origin-Opener-Policy')).toBe('same-origin');
      expect(res.headers.get('Strict-Transport-Security')).toContain('max-age=');
      expect(res.headers.get('X-Powered-By')).not.toMatch(/workerd|cloudflare|express/i);
    }
    closeEnv(env);
  });

  it('CSP forbids inline script, eval and third-party script origins', async () => {
    const env = makeEnv();
    const csp = (await call(env, req('/'))).headers.get('Content-Security-Policy') ?? '';
    expect(csp).toContain("default-src 'self'");
    expect(csp).toContain("object-src 'none'");
    expect(csp).toContain("base-uri 'none'");
    expect(csp).toContain("frame-ancestors 'none'");
    expect(csp).toContain("require-trusted-types-for 'script'");
    // script-src must be nonce-based and must not include unsafe-inline/unsafe-eval
    const scriptSrc = csp.split(';').find((p) => p.trim().startsWith('script-src')) ?? '';
    expect(scriptSrc).toContain("'nonce-");
    expect(scriptSrc).not.toContain('unsafe-inline');
    expect(scriptSrc).not.toContain('unsafe-eval');
    closeEnv(env);
  });

  it('404 page reveals nothing about the stack', async () => {
    const env = makeEnv();
    const res = await call(env, req('/definitely-not-here'));
    expect(res.status).toBe(404);
    const body = await res.text();
    expect(body).toContain('Page not found');
    for (const needle of ['    at ', 'stack', 'TypeError', 'sqlite', 'wrangler', 'SELECT', 'errno']) {
      expect(body.includes(needle), `404 leaked "${needle}"`).toBe(false);
    }
    closeEnv(env);
  });

  it('admin API errors are generic and never echo SQL', async () => {
    const env = makeEnv();
    const res = await call(env, req('/api/admin/stats', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' }));
    expect(res.status).toBe(401);
    const body = JSON.stringify(await res.json());
    expect(body).not.toContain('sqlite');
    expect(body).not.toContain('sessions');
    closeEnv(env);
  });

  it('a deliberately broken template returns a generic 500 payload', async () => {
    const env = makeEnv();
    // Drop a table the public renderer needs — the Worker must not leak the cause.
    env.__shim.db.exec('DROP TABLE gallery_items');
    const res = await call(env, req('/'));
    expect(res.status).toBe(503);
    const body = await res.text();
    expect(body.toLowerCase()).not.toContain('gallery_items');
    expect(body.toLowerCase()).not.toContain('sqlite');
    expect(body).toContain('Database is not ready yet');
    closeEnv(env);
  });
});

describe('secrets are never exposed to the browser', () => {
  it('dashboard payload carries a CSRF token but no server secrets', async () => {
    const env = makeEnv();
    const { cookie } = await signedIn(env);
    const html = await (await call(env, req('/portal/dashboard', { headers: { Cookie: cookie } }))).text();
    const match = /<script type="application\/json" id="__NK_PORTAL__">([\s\S]*?)<\/script>/.exec(html);
    expect(match).not.toBeNull();
    const payload = JSON.parse(match![1]);
    expect(typeof payload.csrf).toBe('string');
    const serialised = JSON.stringify(payload);
    for (const needle of ['SESSION_SECRET', 'CSRF_SECRET', 'password_hash', 'vault_', 'sqlite']) {
      expect(serialised.includes(needle)).toBe(false);
    }
    closeEnv(env);
  });

  it('public payload carries no tokens or role data', async () => {
    const env = makeEnv();
    const html = await (await call(env, req('/'))).text();
    const match = /<script type="application\/json" id="__NK_DATA__">([\s\S]*?)<\/script>/.exec(html);
    expect(match).not.toBeNull();
    const payload = JSON.parse(match![1]);
    const serialised = JSON.stringify(payload);
    for (const needle of ['csrf', 'role', 'super_admin', 'token', 'sid']) {
      expect(serialised.includes(needle)).toBe(false);
    }
    closeEnv(env);
  });

  it('inline JSON cannot break out of its <script> element', async () => {
    const env = makeEnv();
    env.__shim.db
      .prepare("UPDATE settings SET value = ? WHERE key = 'school_name'")
      .run('</script><img src=x onerror=alert(1)>');
    const html = await (await call(env, req('/'))).text();
    expect(html).not.toContain('</script><img');
    closeEnv(env);
  });
});

describe('rbac is enforced server-side, not just in the UI', () => {
  it('Co-Admin cannot create logins, reset passwords or touch vaults', async () => {
    const env = makeEnv();
    const { sid, cookie } = await signedIn(env, 'co_admin');
    const csrf = await createCsrfToken(CSRF_SECRET, sid);
    for (const action of ['user.create', 'user.delete', 'user.reset']) {
      const res = await call(
        env,
        req(`/api/admin/${action}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Cookie: cookie },
          body: JSON.stringify({ username: 'x', password: 'password123', role: 'co_admin', id: 1, csrf }),
        }),
      );
      expect(res.status, `${action} should be forbidden for co_admin`).toBe(403);
    }
    const vault = await call(
      env,
      req('/api/admin/vault.save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Cookie: cookie },
        body: JSON.stringify({ vaults: { vault_2_url: 'https://evil.example.com' }, csrf }),
      }),
    );
    expect(vault.status).toBe(403);
    closeEnv(env);
  });

  it('Teacher cannot create logins, teachers, salary or attendance', async () => {
    const env = makeEnv();
    const { sid, cookie } = await signedIn(env, 'teacher');
    const csrf = await createCsrfToken(CSRF_SECRET, sid);
    for (const action of ['user.create', 'teacher.create', 'salary.create', 'attendance.create', 'settings']) {
      const res = await call(
        env,
        req(`/api/admin/${action}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Cookie: cookie },
          body: JSON.stringify({ id: 1, amount: 1, csrf }),
        }),
      );
      expect(res.status, `${action} should be forbidden for teacher`).toBe(403);
    }
    closeEnv(env);
  });

  it('the Super Admin account cannot be deleted through the API', async () => {
    const env = makeEnv();
    const { sid, cookie } = await signedIn(env);
    const csrf = await createCsrfToken(CSRF_SECRET, sid);
    const res = await call(
      env,
      req('/api/admin/user.delete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Cookie: cookie },
        body: JSON.stringify({ id: 1, csrf }),
      }),
    );
    expect(res.status).toBe(403);
    const still = env.__shim.db.prepare('SELECT COUNT(*) AS n FROM users WHERE role = ?').get('super_admin') as { n: number };
    expect(still.n).toBe(1);
    closeEnv(env);
  });

  it('CSRF is required on every mutating admin call', async () => {
    const env = makeEnv();
    const { cookie } = await signedIn(env);
    const res = await call(
      env,
      req('/api/admin/notice.create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Cookie: cookie },
        body: JSON.stringify({ title: 'Sneaky notice' }),
      }),
    );
    expect(res.status).toBe(419);
    const notices = env.__shim.db.prepare('SELECT COUNT(*) AS n FROM notices').get() as { n: number };
    expect(notices.n).toBe(3);
    closeEnv(env);
  });

  it('a token minted for another session cannot be replayed', async () => {
    const env = makeEnv();
    const { sid, cookie } = await signedIn(env);
    const foreign = await createCsrfToken(CSRF_SECRET, 'someone-elses-session');
    void sid;
    const res = await call(
      env,
      req('/api/admin/notice.create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Cookie: cookie },
        body: JSON.stringify({ title: 'Replayed notice', csrf: foreign }),
      }),
    );
    expect(res.status).toBe(419);
    closeEnv(env);
  });
});

describe('cross-account shard isolation', () => {
  it('vault requests without a secret are rejected', async () => {
    const env = makeEnv();
    // The primary Worker must never call a vault it has no secret for.
    const { shardPool } = await import('../backend/src/lib/media.js');
    const pool = await shardPool(env);
    expect(pool[1].connected).toBe(false);
    expect(pool[1].error).toBe('Not configured');
    closeEnv(env);
  });

  it('a vault is only contacted when both URL and secret are configured', async () => {
    const env = makeEnv({ VAULT_2_URL: 'https://vault2.example.workers.dev', VAULT_2_SECRET: '' });
    const { shardPool } = await import('../backend/src/lib/media.js');
    const pool = await shardPool(env);
    expect(pool[1].connected).toBe(false); // URL alone is not enough
    closeEnv(env);
  });

  it('media for a shard with no configured vault returns 503, not an internal error', async () => {
    const env = makeEnv();
    env.__shim.db
      .prepare('INSERT INTO media_index (id, shard_id, storage_key, mime, size_bytes, chunk_count, label, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)')
      .run('orphan_1', 3, 'orphan_1', 'image/webp', 1024, 1, 'orphan', new Date().toISOString());
    const res = await call(env, req('/api/media/orphan_1'));
    expect(res.status).toBe(503);
    expect(await res.text()).toBe('Media unavailable');
    closeEnv(env);
  });
});

describe('PBKDF2 iteration contract', () => {
  it('backend, migration and every helper agree on 100,000', async () => {
    const { PBKDF2_ITERATIONS } = await import('../backend/src/lib/crypto.js');
    expect(PBKDF2_ITERATIONS).toBe(100_000);

    const fs = await import('node:fs/promises');
    const path = await import('node:path');
    const { fileURLToPath } = await import('node:url');
    const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

    const migration = await fs.readFile(path.join(root, 'migrations', '0001_reset.sql'), 'utf8');
    expect(migration).toContain('100000');
    expect(/210000|210,000/.test(migration)).toBe(false);
    // every seeded hash must declare exactly 100000 iterations
    const seeds = migration.match(/pbkdf2\$sha256\$(\d+)\$/g) ?? [];
    expect(seeds.length).toBeGreaterThan(0);
    for (const seed of seeds) expect(seed).toBe('pbkdf2$sha256$100000$');

    const helper = await fs.readFile(path.join(root, 'scripts', 'hash-password.mjs'), 'utf8');
    expect(helper).toContain('100_000');

    const deploy = await fs.readFile(path.join(root, 'deploy.sh'), 'utf8');
    expect(/210000|210,000/.test(deploy)).toBe(false);

    const crypto = await fs.readFile(path.join(root, 'backend', 'src', 'lib', 'crypto.ts'), 'utf8');
    expect(crypto).toContain('PBKDF2_ITERATIONS = 100_000');
    expect(/210000|210,000/.test(crypto)).toBe(false);
  });

  it('a 210,000-iteration hash is refused rather than attempted', async () => {
    const { pbkdf2Verify } = await import('../backend/src/lib/crypto.js');
    const bogus = 'pbkdf2$sha256$210000$AAAAAAAAAAAAAAAAAAAAAA==$AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=';
    expect(await pbkdf2Verify('x', bogus)).toBe(false);
  });
});

describe('nine distinct class avatars', () => {
  it('all nine bundled avatars are unique files', async () => {
    const fs = await import('node:fs/promises');
    const path = await import('node:path');
    const { fileURLToPath } = await import('node:url');
    const crypto = await import('node:crypto');
    const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
    const hashes = new Set<string>();
    for (let i = 1; i <= 9; i++) {
      const buf = await fs.readFile(path.join(root, 'public', `class${i}.jpg`));
      expect(buf.length).toBeGreaterThan(3000);
      hashes.add(crypto.createHash('sha256').update(buf).digest('hex'));
    }
    expect(hashes.size).toBe(9);
  });

  it('every class slug resolves to its own distinct avatar through /img', async () => {
    const env = makeEnv();
    const slugs = ['play-class', 'nursery', 'lkg', 'ukg', 'class-1', 'class-2', 'class-3', 'class-4', 'class-5'];
    const seen = new Set<string>();
    for (const slug of slugs) {
      const res = await call(env, req(`/img/${slug}.jpg`));
      expect(res.status).toBe(200);
      expect(res.headers.get('Content-Type')).toBe('image/jpeg');
      expect(res.headers.get('X-Content-Type-Options')).toBe('nosniff');
      const buf = Buffer.from(await res.arrayBuffer());
      expect(buf.length).toBeGreaterThan(3000);
      expect(buf.subarray(0, 2).toString('hex')).toBe('ffd8'); // real JPEG magic
      seen.add((await import('node:crypto')).createHash('sha256').update(buf).digest('hex'));
    }
    expect(seen.size).toBe(9);
    closeEnv(env);
  });

  it('a traversal attempt on /img is refused', async () => {
    const env = makeEnv();
    for (const bad of ['/img/../backend/src/index.ts', '/img/%2e%2e%2fpackage.json', '/img/nope.jpg']) {
      const res = await call(env, req(bad));
      expect([403, 404], `${bad} should not resolve`).toContain(res.status);
    }
    closeEnv(env);
  });
});
