/**
 * A faithful-enough D1 shim backed by better-sqlite3 so the test suite runs the
 * REAL schema and the REAL SQL statements — including the 1 MB row limit that
 * forces chunking. Runs entirely offline.
 */
import Database from 'better-sqlite3';
import { readFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));

interface RunResult {
  results?: unknown[];
  success: boolean;
  meta?: { changes?: number; last_row_id?: number; rows_read?: number; rows_written?: number };
}

class Statement {
  private db: Database.Database;
  private sql: string;
  private params: unknown[] = [];

  constructor(db: Database.Database, sql: string) {
    this.db = db;
    this.sql = sql;
  }

  bind(...values: unknown[]): Statement {
    this.params = values.map((v) => (v === undefined ? null : v));
    return this;
  }

  async first<T = unknown>(colName?: string): Promise<T | null> {
    const row = this.db.prepare(this.sql).get(...(this.params as never[])) as Record<string, unknown> | undefined;
    if (!row) return null;
    if (colName) return (row[colName] ?? null) as T | null;
    return row as T;
  }

  async all<T = unknown>(): Promise<RunResult & { results: T[] }> {
    const rows = this.db.prepare(this.sql).all(...(this.params as never[])) as T[];
    return { results: rows, success: true, meta: { rows_read: rows.length } };
  }

  async run<T = unknown>(): Promise<RunResult> {
    const stmt = this.db.prepare(this.sql);
    const info = stmt.run(...(this.params as never[]));
    void (0 as unknown as T);
    return {
      success: true,
      meta: { changes: info.changes, last_row_id: Number(info.lastInsertRowid), rows_written: info.changes },
    };
  }
}

export class D1Shim {
  db: Database.Database;

  constructor(schemaPath = join(here, '..', 'migrations', '0001_reset.sql')) {
    this.db = new Database(':memory:');
    this.db.pragma('foreign_keys = ON');
    const sql = readFileSync(schemaPath, 'utf8');
    this.db.exec(sql);
  }

  prepare(query: string): Statement {
    return new Statement(this.db, query);
  }

  async batch<T = unknown>(statements: Statement[]): Promise<RunResult[]> {
    const out: RunResult[] = [];
    for (const stmt of statements) out.push((await stmt.run()) as RunResult);
    void (0 as unknown as T);
    return out;
  }

  async exec(query: string): Promise<{ count: number; duration: number }> {
    const start = Date.now();
    this.db.exec(query);
    return { count: 0, duration: Date.now() - start };
  }

  close(): void {
    this.db.close();
  }
}

/**
 * Emulates Cloudflare's 1 MB per-row ceiling. Any text/blob value above the
 * limit throws SQLITE_TOOBIG, exactly like D1 does in production.
 */
export function assertRowSizes(db: Database.Database, limitBytes = 1_000_000): void {
  const rows = db.prepare('SELECT media_id, chunk_index, LENGTH(data) AS len FROM media_chunks').all() as Array<{
    media_id: string;
    chunk_index: number;
    len: number;
  }>;
  for (const row of rows) {
    if (row.len > limitBytes) {
      throw new Error(`SQLITE_TOOBIG: row ${row.media_id}#${row.chunk_index} is ${row.len} bytes`);
    }
  }
}
