/**
 * End-to-end route tests against the real Worker fetch handler:
 * public SSR, portal gating, RBAC, sign-in, enquiry validation, media streaming
 * and the strict public/portal isolation rule (no "Mera", no admin leakage).
 */
import { describe, it, expect, beforeAll } from 'vitest';
import worker from '../backend/src/index.js';
import { makeEnv, closeEnv, type TestEnv } from './env.js';
import { createCsrfToken } from '../backend/src/lib/crypto.js';
import { pbkdf2Hash } from '../backend/src/lib/crypto.js';

const BASE = 'https://nanhe-kadam.empathy-life-jelly.workers.dev';
const SESSION_SECRET = 'test_session_secret_0123456789abcdef0123456789abcdef';
const CSRF_SECRET = 'test_csrf_secret_0123456789abcdef0123456789abcdef';

function req(path: string, init: RequestInit = {}): Request {
  return new Request(`${BASE}${path}`, init);
}

async function call(env: TestEnv, request: Request): Promise<Response> {
  return await worker.fetch(request, env as never);
}

describe('public site (server-rendered)', () => {
  let env: TestEnv;
  beforeAll(() => {
    env = makeEnv();
  });

  it('renders the homepage instantly with real content (no Loading flash)', async () => {
    const res = await call(env, req('/'));
    expect(res.status).toBe(200);
    const html = await res.text();
    expect(html).toContain('Nanhe Kadam');
    expect(html).toContain('Public School');
    expect(html).toContain('Near Sudha Factory, Chorawa Icha, Bihar');
    expect(html).toContain('Amita Kumari');
    expect(html).toContain('Play Class');
    expect(html).toContain('Class 5');
    expect(html).toContain('Grand Opening – 11 Nov 2026');
    expect(html).toContain('__NK_DATA__');
    expect(html.toLowerCase()).not.toContain('loading...');
  });

  it('never says "Mera" anywhere in the public HTML', async () => {
    const html = await (await call(env, req('/'))).text();
    expect(/\bmera\b/i.test(html)).toBe(false);
  });

  it('leaks zero dashboard/portal markup on public routes', async () => {
    const html = await (await call(env, req('/'))).text();
    expect(html).not.toContain('portal-side');
    expect(html).not.toContain('data-view-link');
    expect(html).not.toContain('Super Admin sign in');
    expect(html).not.toContain('vault_2_secret');
    expect(html).not.toContain('CREATE TABLE');
    // the only portal reference is the discreet footer/menu link
    expect(html).toContain('/portal');
  });

  it('serves the nine seeded classes play-class → class-5', async () => {
    const html = await (await call(env, req('/'))).text();
    for (const name of ['Play Class', 'Nursery', 'LKG', 'UKG', 'Class 1', 'Class 2', 'Class 3', 'Class 4', 'Class 5']) {
      expect(html).toContain(name);
    }
  });

  it('renders the three opening-ceremony photos from the seeded gallery', async () => {
    const html = await (await call(env, req('/'))).text();
    expect(html).toContain('/img/opening1.jpg');
    expect(html).toContain('/img/opening2.jpg');
    expect(html).toContain('/img/opening3.jpg');
  });

  it('serves style.css, public.js and robots.txt', async () => {
    const css = await call(env, req('/style.css'));
    expect(css.status).toBe(200);
    expect(css.headers.get('Content-Type')).toContain('text/css');
    expect(await css.text()).toContain('.nk-bubble');

    const js = await call(env, req('/public.js'));
    expect(js.status).toBe(200);
    expect(await js.text()).toContain('pointerdown');

    const robots = await call(env, req('/robots.txt'));
    expect(await robots.text()).toContain('Disallow: /portal');
  });

  it('sends security headers on HTML responses', async () => {
    const res = await call(env, req('/'));
    expect(res.headers.get('X-Content-Type-Options')).toBe('nosniff');
    expect(res.headers.get('X-Frame-Options')).toBe('DENY');
    expect(res.headers.get('Referrer-Policy')).toBe('no-referrer');
    const csp = res.headers.get('Content-Security-Policy') ?? '';
    expect(csp).toContain("default-src 'self'");
    expect(csp).toContain('object-src');
  });

  it('serves the bundled images through /img', async () => {
    const res = await call(env, req('/img/opening1.jpg'));
    expect(res.status).toBe(200);
    expect(res.headers.get('Content-Type')).toBe('image/jpeg');
    expect(Number(res.headers.get('Content-Length'))).toBeGreaterThan(10_000);
  });

  it('health endpoint reports the database connection', async () => {
    const res = await call(env, req('/api/health'));
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body.ok).toBe(true);
    expect(body.data.db).toBe('connected');
  });
});

describe('portal gating', () => {
  let env: TestEnv;
  beforeAll(() => {
    env = makeEnv();
  });

  it('renders the bunny login page without any dashboard markup', async () => {
    const res = await call(env, req('/portal'));
    expect(res.status).toBe(200);
    const html = await res.text();
    expect(html).toContain('nk-bunny');
    expect(html).toContain('Super Admin');
    expect(html).toContain('Co-Admin');
    expect(html).toContain('Teacher Login');
    expect(html).not.toContain('portal-side');
    expect(html).not.toContain('Storage Pool');
  });

  it('redirects unauthenticated /portal/dashboard to the login page', async () => {
    const res = await call(env, req('/portal/dashboard'));
    expect(res.status).toBe(302);
    expect(res.headers.get('Location')).toBe('/portal');
    const body = await res.text();
    expect(body).toBe('');
  });

  it('rejects a forged session cookie with a redirect (no dashboard bytes)', async () => {
    const res = await call(
      env,
      req('/portal/dashboard', { headers: { Cookie: 'nk_sess=deadbeefdeadbeefdeadbeefdeadbeef.0000' } }),
    );
    expect(res.status).toBe(302);
  });

  it('returns 401 for admin API calls without a session', async () => {
    const res = await call(env, req('/api/admin/stats', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' }));
    expect(res.status).toBe(401);
  });

  it('blocks cross-origin admin POSTs', async () => {
    const res = await call(
      env,
      req('/api/admin/stats', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Origin: 'https://evil.example.com' },
        body: '{}',
      }),
    );
    expect(res.status).toBe(401); // no session → 401 before origin check
  });
});

describe('sign-in and roles', () => {
  it('rejects a wrong password with 401', async () => {
    const env = makeEnv();
    const csrf = await createCsrfToken(CSRF_SECRET, 'anon');
    const res = await call(
      env,
      req('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: 'Rakesh@1', password: 'wrong', csrf }),
      }),
    );
    expect(res.status).toBe(401);
    closeEnv(env);
  });

  it('rejects a request without a CSRF token', async () => {
    const env = makeEnv();
    const res = await call(
      env,
      req('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: 'Rakesh@1', password: 'rakesh@7632' }),
      }),
    );
    expect(res.status).toBe(419);
    closeEnv(env);
  });

  it('signs the Super Admin in and sets a hardened cookie', async () => {
    const env = makeEnv();
    const csrf = await createCsrfToken(CSRF_SECRET, 'anon');
    const res = await call(
      env,
      req('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: 'Rakesh@1', password: 'rakesh@7632', role: 'super_admin', csrf }),
      }),
    );
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body.ok).toBe(true);
    expect(body.data.must_change_password).toBe(true);
    expect(body.data.redirect).toBe('/portal/password');

    const cookie = res.headers.get('Set-Cookie') ?? '';
    expect(cookie).toContain('HttpOnly');
    expect(cookie).toContain('Secure');
    expect(cookie).toContain('SameSite=Strict');
    closeEnv(env);
  });

  it('refuses a role mismatch (Co-Admin tab with the Super Admin account)', async () => {
    const env = makeEnv();
    const csrf = await createCsrfToken(CSRF_SECRET, 'anon');
    const res = await call(
      env,
      req('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: 'Rakesh@1', password: 'rakesh@7632', role: 'teacher', csrf }),
      }),
    );
    expect(res.status).toBe(403);
    closeEnv(env);
  });

  it('loads a fully-populated dashboard for an authenticated session', async () => {
    const env = makeEnv();
    // Simulate a signed-in Super Admin with a raw session row + valid cookie.
    const { randomHex, signSessionId } = await import('../backend/src/lib/crypto.js');
    const sid = randomHex(32);
    env.__shim.db
      .prepare('INSERT INTO sessions (id, user_id, created_at, expires_at, ip, user_agent) VALUES (?, 1, ?, ?, ?, ?)')
      .run(sid, new Date().toISOString(), new Date(Date.now() + 3600_000).toISOString(), '127.0.0.1', 'vitest');
    // The seeded Super Admin starts with must_change_password = 1; the password
    // page is the correct landing spot for that state (covered separately).
    env.__shim.db.prepare('UPDATE users SET must_change_password = 0 WHERE id = 1').run();
    const cookie = await signSessionId(SESSION_SECRET, sid);

    const res = await call(env, req('/portal/dashboard', { headers: { Cookie: `nk_sess=${cookie}` } }));
    expect(res.status).toBe(200);
    const html = await res.text();
    expect(html).toContain('portal-side');
    expect(html).toContain('Combined Storage Meter');
    expect(html).toContain('2,000 MB');
    expect(html).toContain('Co-Admins &amp; Logins');
    expect(html).toContain('Storage Vault Workers');
    expect(html).toContain('Teacher');
    // admin surface must be noindex
    expect(res.headers.get('X-Robots-Tag')).toContain('noindex');
    closeEnv(env);
  });

  it('hides super-admin-only sections from a Co-Admin', async () => {
    const env = makeEnv();
    const { randomHex, signSessionId } = await import('../backend/src/lib/crypto.js');
    const hash = await pbkdf2Hash('coadmin-pass-123');
    env.__shim.db
      .prepare(
        "INSERT INTO users (username, password_hash, role, full_name, must_change_password, active, created_at) VALUES ('CoAdmin1', ?, 'co_admin', 'Co Admin', 0, 1, ?)",
      )
      .run(hash, new Date().toISOString());
    const userRow = env.__shim.db.prepare("SELECT id FROM users WHERE username = 'CoAdmin1'").get() as { id: number };
    const sid = randomHex(32);
    env.__shim.db
      .prepare('INSERT INTO sessions (id, user_id, created_at, expires_at, ip, user_agent) VALUES (?, ?, ?, ?, ?, ?)')
      .run(sid, userRow.id, new Date().toISOString(), new Date(Date.now() + 3600_000).toISOString(), '127.0.0.1', 'vitest');
    const cookie = await signSessionId(SESSION_SECRET, sid);

    const res = await call(env, req('/portal/dashboard', { headers: { Cookie: `nk_sess=${cookie}` } }));
    expect(res.status).toBe(200);
    const html = await res.text();
    expect(html).toContain('School Identity');
    expect(html).toContain('Teacher');
    // Co-Admins must not see storage-vault config or login management
    expect(html).not.toContain('Combined Storage Meter');
    expect(html).not.toContain('vault_2_secret');
    expect(html).not.toContain('Co-Admins &amp; Logins');

    // ... and the backend must refuse the API even if the UI is bypassed
    const csrf = await createCsrfToken(CSRF_SECRET, sid);
    const apiRes = await call(
      env,
      req('/api/admin/user.create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Cookie: `nk_sess=${cookie}` },
        body: JSON.stringify({ username: 'Sneaky', password: 'password123', role: 'co_admin', csrf }),
      }),
    );
    expect(apiRes.status).toBe(403);
    closeEnv(env);
  });
});

describe('admission enquiry', () => {
  it('validates and then stores a valid enquiry', async () => {
    const env = makeEnv();

    const bad = await call(
      env,
      req('/api/enquiries', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ parent_name: 'A', child_name: 'B', phone: '123', class_interested: 'Nursery' }),
      }),
    );
    expect(bad.status).toBe(422);

    const good = await call(
      env,
      req('/api/enquiries', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          parent_name: 'Sunita Devi',
          child_name: 'Aarav Kumar',
          phone: '9876543210',
          class_interested: 'Nursery',
          message: 'Please share the fee structure.',
        }),
      }),
    );
    expect(good.status).toBe(200);
    const body = await good.json();
    expect(body.ok).toBe(true);
    expect(body.data.received).toBe(true);

    const count = env.__shim.db.prepare('SELECT COUNT(*) AS n FROM enquiries').get() as { n: number };
    expect(count.n).toBe(1);
    closeEnv(env);
  });

  it('rejects a class that is not in the seeded list', async () => {
    const env = makeEnv();
    const res = await call(
      env,
      req('/api/enquiries', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          parent_name: 'Test Parent',
          child_name: 'Test Child',
          phone: '9876543210',
          class_interested: 'Class 12',
        }),
      }),
    );
    expect(res.status).toBe(422);
    closeEnv(env);
  });
});

describe('media API', () => {
  it('refuses uploads without a session', async () => {
    const env = makeEnv();
    const res = await call(
      env,
      req('/api/media', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{"data":"x"}' }),
    );
    expect(res.status).toBe(401);
    closeEnv(env);
  });

  it('streams a bundled static photo through the media route', async () => {
    const env = makeEnv();
    const res = await call(env, req('/api/media/static%3Aopening1.jpg'));
    // static shard assets redirect to the immutable /img route
    expect([302, 200]).toContain(res.status);
    if (res.status === 302) expect(res.headers.get('Location')).toBe('/img/opening1.jpg');
    const missing = await call(env, req('/api/media/does_not_exist'));
    expect(missing.status).toBe(404);
    closeEnv(env);
  });

  it('stores and serves a 3 MB photo through Shard 1', async () => {
    const env = makeEnv();
    const { randomHex, signSessionId, createCsrfToken: mint } = await import('../backend/src/lib/crypto.js');
    const sid = randomHex(32);
    env.__shim.db
      .prepare('INSERT INTO sessions (id, user_id, created_at, expires_at, ip, user_agent) VALUES (?, 1, ?, ?, ?, ?)')
      .run(sid, new Date().toISOString(), new Date(Date.now() + 3600_000).toISOString(), '127.0.0.1', 'vitest');
    const cookie = await signSessionId(SESSION_SECRET, sid);
    const csrf = await mint(CSRF_SECRET, sid);

    const payload = new Uint8Array(3 * 1024 * 1024);
    for (let i = 0; i < payload.length; i += 1024) payload[i] = i % 251;
    let binary = '';
    for (let i = 0; i < payload.length; i++) binary += String.fromCharCode(payload[i]);
    const dataUrl = `data:image/webp;base64,${Buffer.from(binary, 'binary').toString('base64')}`;

    const upload = await call(
      env,
      req('/api/media', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Cookie: `nk_sess=${cookie}` },
        body: JSON.stringify({ data: dataUrl, kind: 'gallery', gallery_id: 2, label: 'Test 3 MB photo', csrf }),
      }),
    );
    expect(upload.status).toBe(201);
    const upBody = await upload.json();
    expect(upBody.ok).toBe(true);
    expect(upBody.data.shard).toBe(1);
    expect(upBody.data.chunks).toBe(6);

    // every stored chunk row must be under 1 MB
    const sizes = env.__shim.db
      .prepare('SELECT MAX(LENGTH(data)) AS m FROM media_chunks WHERE media_id = ?')
      .get(upBody.data.id) as { m: number };
    expect(sizes.m).toBeLessThan(1_000_000);

    const streamed = await call(env, req(`/api/media/${upBody.data.id}`));
    expect(streamed.status).toBe(200);
    expect(streamed.headers.get('Cache-Control')).toContain('max-age=3600');
    expect(Number(streamed.headers.get('Content-Length'))).toBe(3 * 1024 * 1024);
    closeEnv(env);
  });

  it('rejects a file above 3 MB', async () => {
    const env = makeEnv();
    const { randomHex, signSessionId, createCsrfToken: mint } = await import('../backend/src/lib/crypto.js');
    const sid = randomHex(32);
    env.__shim.db
      .prepare('INSERT INTO sessions (id, user_id, created_at, expires_at, ip, user_agent) VALUES (?, 1, ?, ?, ?, ?)')
      .run(sid, new Date().toISOString(), new Date(Date.now() + 3600_000).toISOString(), '127.0.0.1', 'vitest');
    const cookie = await signSessionId(SESSION_SECRET, sid);
    const csrf = await mint(CSRF_SECRET, sid);

    const big = 'A'.repeat(Math.ceil(((3 * 1024 * 1024) + 1024) * 4 / 3) + 100);
    const res = await call(
      env,
      req('/api/media', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Cookie: `nk_sess=${cookie}` },
        body: JSON.stringify({ data: `data:image/webp;base64,${big}`, csrf }),
      }),
    );
    expect(res.status).toBe(413);
    closeEnv(env);
  });
});

describe('seeded content', () => {
  it('has the three opening-ceremony gallery items and the 11 Nov event', async () => {
    const env = makeEnv();
    const items = env.__shim.db.prepare('SELECT media_id FROM gallery_items ORDER BY sort_order').all() as Array<{ media_id: string }>;
    expect(items.map((i) => i.media_id)).toEqual([
      'static:opening1.jpg',
      'static:opening2.jpg',
      'static:opening3.jpg',
    ]);
    const event = env.__shim.db.prepare("SELECT title FROM events WHERE date = '2026-11-11'").get() as { title: string };
    expect(event.title).toContain('Grand Opening');
    closeEnv(env);
  });

  it('has exactly nine classes and three seeded notices', async () => {
    const env = makeEnv();
    const classes = env.__shim.db.prepare('SELECT COUNT(*) AS n FROM classes').get() as { n: number };
    expect(classes.n).toBe(9);
    const notices = env.__shim.db.prepare('SELECT COUNT(*) AS n FROM notices').get() as { n: number };
    expect(notices.n).toBe(3);
    closeEnv(env);
  });

  it('never stores the word "Mera" in any settings value', async () => {
    const env = makeEnv();
    const rows = env.__shim.db.prepare('SELECT key, value FROM settings').all() as Array<{ key: string; value: string }>;
    for (const row of rows) {
      expect(/\bmera\b/i.test(row.value)).toBe(false);
    }
    closeEnv(env);
  });
});
