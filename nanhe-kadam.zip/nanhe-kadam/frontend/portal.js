/* ==========================================================================
   Nanhe Kadam — portal sign-in client (PUBLIC bundle)
   Only the bubble-sweep engine, the bunny login guardian and the two
   authentication forms live here. No dashboard code, no admin endpoints,
   no capability hints — this file is safe to load before sign-in.
   ========================================================================== */
(function () {
  'use strict';

  var doc = document;
  var reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  var BOOT = (function () {
    try {
      var el = doc.getElementById('__NK_PORTAL__');
      return el ? JSON.parse(el.textContent || '{}') : {};
    } catch (e) {
      return {};
    }
  })();

  var CSRF = BOOT.csrf || '';
  var IS_DASHBOARD = BOOT.page === 'dashboard';
  var IS_PASSWORD_PAGE = BOOT.page === 'password';

  var MAX_UPLOAD = 3 * 1024 * 1024;      // 3 MB ceiling per file
  var TARGET_W = 1920;                    // Full HD long edge
  var WEBP_QUALITY = 0.9;

  /* ------------------------------- helpers ------------------------------ */
  function $(sel, root) { return (root || doc).querySelector(sel); }
  function $$(sel, root) { return Array.prototype.slice.call((root || doc).querySelectorAll(sel)); }

  function showToast(message, kind) {
    var wrap = $('#toast-wrap');
    if (!wrap) return;
    var el = doc.createElement('div');
    el.className = 'toast ' + (kind || '');
    el.textContent = message;
    wrap.appendChild(el);
    requestAnimationFrame(function () { el.classList.add('show'); });
    window.setTimeout(function () {
      el.classList.remove('show');
      window.setTimeout(function () { if (el.parentNode) el.parentNode.removeChild(el); }, 400);
    }, 3800);
  }

  function api(path, payload) {
    return fetch(path, {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(Object.assign({}, payload || {}, { csrf: CSRF })),
    }).then(function (res) {
      return res.json().then(function (body) { return { status: res.status, body: body }; });
    });
  }

  /* --------------------------- bubble sweep ----------------------------- */
  var SWEEP =
    '.btn, .icon-btn, .side-link, .role-tab, .chip, .social-btn, .drawer-link, .pw-toggle,' +
    '.media-tile .del, .dock-toggle, .nav-pill, .btn-mini';

  doc.addEventListener(
    'pointerdown',
    function (event) {
      var target = event.target;
      if (!target || !target.closest) return;
      var host = target.closest(SWEEP);
      if (!host || host.disabled) return;
      if (!reduceMotion) {
        var rect = host.getBoundingClientRect();
        var size = Math.max(rect.width, rect.height) * 1.15;
        var bubble = doc.createElement('span');
        bubble.className = 'nk-bubble';
        bubble.style.width = size + 'px';
        bubble.style.height = size + 'px';
        bubble.style.left = (event.clientX || rect.left + rect.width / 2) - rect.left + 'px';
        bubble.style.top = (event.clientY || rect.top + rect.height / 2) - rect.top + 'px';
        host.appendChild(bubble);
        bubble.addEventListener('animationend', function () {
          if (bubble.parentNode) bubble.parentNode.removeChild(bubble);
        });
        window.setTimeout(function () { if (bubble.parentNode) bubble.parentNode.removeChild(bubble); }, 800);
      }
      host.classList.add('is-press');
      window.setTimeout(function () { host.classList.remove('is-press'); }, 220);
    },
    { passive: true },
  );

  /* ==================================================================== *
   * 1. BUNNY LOGIN GUARDIAN
   * ==================================================================== */
  function initBunny() {
    var bunny = $('#nk-bunny');
    if (!bunny) return null;

    var username = $('#username');
    var password = $('#password');
    var pwToggle = $('#pw-toggle');
    var pupils = $$('.pupil', bunny);
    var paws = $$('.paw', bunny);
    var eyesOpen = $('.bunny-eyes-open', bunny);
    var eyesShut = $('.bunny-eyes-closed', bunny);

    var state = { covering: false, peeking: false, eyeX: 0, eyeY: 0 };

    function setEyes(dx, dy) {
      state.eyeX = dx;
      state.eyeY = dy;
      pupils.forEach(function (p) {
        p.style.transform = 'translate3d(' + (dx * 3.4).toFixed(2) + 'px,' + (dy * 2.6).toFixed(2) + 'px,0)';
      });
    }

    function coverEyes(cover) {
      state.covering = cover;
      bunny.classList.toggle('eyes-shut', cover && !state.peeking);
      paws.forEach(function (paw) {
        var side = paw.getAttribute('data-paw');
        var tx = cover ? (side === 'l' ? 30 : -30) : 0;
        var ty = cover ? -34 : 0;
        var rot = cover ? (side === 'l' ? 12 : -12) : 0;
        paw.style.transform = 'translate3d(' + tx + 'px,' + ty + 'px,0) rotate(' + rot + 'deg)';
      });
    }

    function peek() {
      // Playful: one paw drops for a moment on "show password".
      if (!state.covering) return;
      state.peeking = true;
      bunny.classList.remove('eyes-shut');
      var right = paws.filter(function (p) { return p.getAttribute('data-paw') === 'r'; })[0];
      if (right) right.style.transform = 'translate3d(-6px,-14px,0) rotate(-20deg)';
      window.setTimeout(function () {
        state.peeking = false;
        bunny.classList.add('eyes-shut');
        if (right) right.style.transform = 'translate3d(-30px,-34px,0) rotate(-12deg)';
      }, 1400);
    }

    doc.addEventListener(
      'pointermove',
      function (event) {
        if (state.covering) return;
        var rect = bunny.getBoundingClientRect();
        var cx = rect.left + rect.width / 2;
        var cy = rect.top + rect.height / 2;
        var dx = (event.clientX - cx) / (rect.width * 0.9);
        var dy = (event.clientY - cy) / (rect.height * 0.9);
        setEyes(Math.max(-1, Math.min(1, dx)), Math.max(-1, Math.min(1, dy)));
      },
      { passive: true },
    );

    if (username) {
      username.addEventListener('focus', function () { coverEyes(false); });
      username.addEventListener('input', function () {
        if (reduceMotion) return;
        // tiny nod of attention while typing a username
        setEyes(Math.sin(username.value.length) * 0.6, 0.2);
      });
    }

    if (password) {
      password.addEventListener('focus', function () { coverEyes(true); });
      password.addEventListener('blur', function () {
        if (!password.value) coverEyes(false);
      });
    }

    if (pwToggle) {
      pwToggle.addEventListener('click', function () {
        var showing = password.type === 'text';
        password.type = showing ? 'password' : 'text';
        pwToggle.setAttribute('aria-label', showing ? 'Show password' : 'Hide password');
        if (!showing) peek();
      });
    }

    return {
      happy: function () {
        coverEyes(false);
        bunny.classList.add('happy');
        window.setTimeout(function () { bunny.classList.remove('happy'); }, 900);
      },
      sad: function () {
        bunny.classList.add('sad');
        window.setTimeout(function () { bunny.classList.remove('sad'); }, 700);
      },
      reset: function () { coverEyes(false); setEyes(0, 0); },
    };
  }

  var bunny = initBunny();

  /* ==================================================================== *
   * 2. LOGIN FORM
   * ==================================================================== */
  var roleTitles = {
    super_admin: 'Super Admin sign in',
    co_admin: 'Co-Admin sign in',
    teacher: 'Teacher sign in',
  };
  var selectedRole = 'super_admin';

  /**
   * Swaps the button caption while keeping its inline SVG icon.
   * Uses DOM nodes only — never innerHTML — so the page passes
   * `require-trusted-types-for 'script'` without a Trusted Types policy.
   */
  function setSubmitLabel(button, label) {
    if (!button) return;
    var span = button.querySelector('span');
    if (span) {
      span.textContent = label;
      return;
    }
    button.textContent = label;
  }

  function initLogin() {
    var form = $('#login-form');
    if (!form) return;

    $$('.role-tab').forEach(function (tab) {
      tab.addEventListener('click', function () {
        $$('.role-tab').forEach(function (t) {
          t.classList.remove('is-active');
          t.setAttribute('aria-selected', 'false');
        });
        tab.classList.add('is-active');
        tab.setAttribute('aria-selected', 'true');
        selectedRole = tab.getAttribute('data-role');
        var title = $('#login-role-title');
        if (title) title.textContent = roleTitles[selectedRole] || 'Sign in';
      });
    });

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var errEl = $('#login-err');
      var submit = $('#login-submit');
      var username = ($('#username').value || '').trim();
      var password = $('#password').value || '';
      if (errEl) errEl.textContent = '';
      if (!username || !password) {
        if (errEl) errEl.textContent = 'Enter your username and password.';
        if (bunny) bunny.sad();
        return;
      }
      submit.disabled = true;
      setSubmitLabel(submit, 'Signing in…');

      api('/api/login', { username: username, password: password, role: selectedRole })
        .then(function (out) {
          if (out.body && out.body.ok) {
            if (bunny) bunny.happy();
            var dest = (out.body.data && out.body.data.redirect) || '/portal/dashboard';
            window.setTimeout(function () { window.location.href = dest; }, 620);
          } else {
            if (bunny) bunny.sad();
            if (errEl) errEl.textContent = (out.body && out.body.error) || 'Sign in failed.';
            submit.disabled = false;
            setSubmitLabel(submit, 'Sign In');
          }
        })
        .catch(function () {
          if (bunny) bunny.sad();
          if (errEl) errEl.textContent = 'Network problem — please try again.';
          submit.disabled = false;
          setSubmitLabel(submit, 'Sign In');
        });
    });
  }

  function initPasswordGate() {
    var form = $('#pw-form');
    if (!form) return;
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var errEl = $('#pw-err');
      var submit = $('#pw-submit');
      var p1 = $('#new_password').value || '';
      var p2 = $('#confirm_password').value || '';
      if (errEl) errEl.textContent = '';
      if (p1.length < 8) { if (errEl) errEl.textContent = 'Use at least 8 characters.'; return; }
      if (p1 !== p2) { if (errEl) errEl.textContent = 'Passwords do not match.'; return; }
      submit.disabled = true;
      submit.textContent = 'Saving…';
      api('/api/password', { new_password: p1 })
        .then(function (out) {
          if (out.body && out.body.ok) {
            window.location.href = '/portal/dashboard';
          } else {
            if (errEl) errEl.textContent = (out.body && out.body.error) || 'Could not update password.';
            submit.disabled = false;
            submit.textContent = 'Save & Continue';
          }
        })
        .catch(function () {
          if (errEl) errEl.textContent = 'Network problem — please try again.';
          submit.disabled = false;
          submit.textContent = 'Save & Continue';
        });
    });
  }

  /* ==================================================================== *
   * 3. IMAGE PIPELINE (3 MB HD → canvas → 1920px WebP q0.90)
   * ==================================================================== */
  function loadImage(file) {
    return new Promise(function (resolve, reject) {
      var url = URL.createObjectURL(file);
      var img = new Image();
      img.onload = function () {
        URL.revokeObjectURL(url);
        resolve(img);
      };
      img.onerror = function () {
        URL.revokeObjectURL(url);
        reject(new Error('Could not read that image file.'));
      };
      img.src = url;
    });
  }

  function renderToCanvas(img, maxEdge) {
    var w = img.naturalWidth || img.width;
    var h = img.naturalHeight || img.height;
    var scale = Math.min(1, maxEdge / Math.max(w, h));
    var tw = Math.max(1, Math.round(w * scale));
    var th = Math.max(1, Math.round(h * scale));
    var canvas = doc.createElement('canvas');
    canvas.width = tw;
    canvas.height = th;
    var ctx = canvas.getContext('2d');
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(img, 0, 0, tw, th);
    return canvas;
  }

  /**
   * Convert an uploaded File into a compact Full-HD WebP data URL.
   * Falls back to JPEG when the browser cannot encode WebP.
   */
  function prepareImage(file) {
    if (!/^image\//.test(file.type)) {
      return Promise.reject(new Error('Only image files are supported (JPG, PNG, WebP).'));
    }
    if (file.size > MAX_UPLOAD) {
      return Promise.reject(
        new Error('“' + file.name + '” is ' + (file.size / 1048576).toFixed(2) + ' MB — the maximum is 3 MB.'),
      );
    }
    return loadImage(file).then(function (img) {
      var canvas = renderToCanvas(img, TARGET_W);
      var webp = canvas.toDataURL('image/webp', WEBP_QUALITY);
      var isWebp = webp.indexOf('data:image/webp') === 0;
      if (!isWebp) return { data: canvas.toDataURL('image/jpeg', 0.9), width: canvas.width, height: canvas.height };

      // If a very detailed photo still exceeds 3 MB, step quality down until it fits.
      var quality = WEBP_QUALITY;
      var data = webp;
      while (approxBytes(data) > MAX_UPLOAD && quality > 0.62) {
        quality -= 0.06;
        data = canvas.toDataURL('image/webp', quality);
      }
      return { data: data, width: canvas.width, height: canvas.height };
    });
  }

  function approxBytes(dataUrl) {
    var idx = dataUrl.indexOf(',');
    return Math.floor(((dataUrl.length - idx - 1) * 3) / 4);
  }

  function setProgress(key, percent) {
    var bar = $('[data-prog="' + key + '"]');
    if (!bar) return;
    bar.hidden = percent <= 0 || percent >= 100;
    var inner = bar.querySelector('i');
    if (inner) inner.style.width = Math.max(0, Math.min(100, percent)) + '%';
  }

  function uploadPhoto(file, options) {
    var opts = options || {};
    return prepareImage(file).then(function (prepared) {
      return api('/api/media', {
        data: prepared.data,
        label: opts.label || file.name.replace(/\.[^.]+$/, '').slice(0, 120),
        gallery_id: opts.galleryId || null,
        kind: opts.kind || 'gallery',
      }).then(function (out) {
        if (!out.body || !out.body.ok) {
          throw new Error((out.body && out.body.error) || 'Upload failed');
        }
        return out.body.data;
      });
    });
  }

  /* ------------------------------- boot -------------------------------- */
  initLogin();
  initPasswordGate();
})();
