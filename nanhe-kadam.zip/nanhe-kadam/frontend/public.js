/* ==========================================================================
   Nanhe Kadam — public interaction layer
   • 120 FPS bubble-sweep on every control (transform + opacity only)
   • GPU scroll reveal via IntersectionObserver
   • Drawers (nav, social dock), notice + photo modals
   • Admission enquiry with the celebrating stickman
   No dependencies. ~7 KB minified.
   ========================================================================== */
(function () {
  'use strict';

  var doc = document;
  var reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------------------------- data payload ---------------------------- */
  var DATA = (function () {
    try {
      var el = doc.getElementById('__NK_DATA__');
      return el ? JSON.parse(el.textContent || '{}') : {};
    } catch (e) {
      return {};
    }
  })();

  /* ------------------------- bubble sweep engine ------------------------ */
  var SWEEP_SELECTOR =
    '.btn, .nav-pill, .social-btn, .class-card, .role-tab, .chip, .icon-btn, .dock-item,' +
    '.dock-toggle, .gallery-tile, .notice-row, .card-head-link, .drawer-link, .btn-mini,' +
    '.pw-toggle, .event-card, .media-tile .del, .footer-link';

  function spawnBubble(host, x, y) {
    var bubble = doc.createElement('span');
    bubble.className = 'nk-bubble';
    var rect = host.getBoundingClientRect();
    var size = Math.max(rect.width, rect.height) * 1.15;
    bubble.style.width = size + 'px';
    bubble.style.height = size + 'px';
    bubble.style.left = x - rect.left + 'px';
    bubble.style.top = y - rect.top + 'px';
    host.appendChild(bubble);
    // Cleanup on animation end — never on a timer that could drift.
    bubble.addEventListener('animationend', function () {
      if (bubble.parentNode) bubble.parentNode.removeChild(bubble);
    });
    window.setTimeout(function () {
      if (bubble.parentNode) bubble.parentNode.removeChild(bubble);
    }, 800);
  }

  function onPointerDown(event) {
    var target = event.target;
    if (!target || !target.closest) return;
    var host = target.closest(SWEEP_SELECTOR);
    if (!host || host.disabled) return;

    var x = typeof event.clientX === 'number' && event.clientX ? event.clientX : 0;
    var y = typeof event.clientY === 'number' && event.clientY ? event.clientY : 0;
    if (!x && !y) {
      var r = host.getBoundingClientRect();
      x = r.left + r.width / 2;
      y = r.top + r.height / 2;
    }

    if (!reduceMotion) spawnBubble(host, x, y);

    host.classList.add('is-press');
    window.setTimeout(function () {
      host.classList.remove('is-press');
    }, 220);
  }

  doc.addEventListener('pointerdown', onPointerDown, { passive: true });

  /* ------------------------------ helpers ------------------------------- */
  function $(sel, root) { return (root || doc).querySelector(sel); }
  function $$(sel, root) { return Array.prototype.slice.call((root || doc).querySelectorAll(sel)); }

  function showToast(message, kind) {
    var wrap = $('#toast-wrap');
    if (!wrap) return;
    var el = doc.createElement('div');
    el.className = 'toast ' + (kind || '');
    el.textContent = message;
    wrap.appendChild(el);
    requestAnimationFrame(function () {
      el.classList.add('show');
    });
    window.setTimeout(function () {
      el.classList.remove('show');
      window.setTimeout(function () { if (el.parentNode) el.parentNode.removeChild(el); }, 400);
    }, 3400);
  }

  var scrim = $('#scrim');
  var openLayers = [];

  function openLayer(el) {
    if (!el) return;
    el.classList.add('is-open');
    el.setAttribute('aria-hidden', 'false');
    if (scrim) scrim.classList.add('is-open');
    openLayers.push(el);
    doc.body.style.overflow = 'hidden';
  }

  function closeLayers() {
    openLayers.forEach(function (el) {
      el.classList.remove('is-open');
      el.setAttribute('aria-hidden', 'true');
    });
    openLayers = [];
    if (scrim) scrim.classList.remove('is-open');
    doc.body.style.overflow = '';
  }

  if (scrim) scrim.addEventListener('click', closeLayers);
  doc.addEventListener('click', function (e) {
    if (e.target.closest && e.target.closest('[data-close]')) closeLayers();
  });
  doc.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') closeLayers();
  });

  /* --------------------------- mobile drawer ---------------------------- */
  var navToggle = $('#nav-toggle');
  var navDrawer = $('#nav-drawer');
  if (navToggle && navDrawer) {
    navToggle.addEventListener('click', function () {
      if (navDrawer.classList.contains('is-open')) {
        closeLayers();
      } else {
        openLayer(navDrawer);
        navToggle.setAttribute('aria-expanded', 'true');
      }
    });
    $$('[data-drawer-link]', navDrawer).forEach(function (link) {
      link.addEventListener('click', function () { closeLayers(); });
    });
  }

  /* ---------------------------- social dock ----------------------------- */
  var dock = $('#social-dock');
  var dockToggle = $('#dock-toggle');
  if (dock && dockToggle) {
    dockToggle.addEventListener('click', function () {
      var open = dock.classList.toggle('is-open');
      dockToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  }

  /* --------------------------- scroll reveal ---------------------------- */
  var revealEls = $$('[data-reveal]');
  if ('IntersectionObserver' in window && !reduceMotion) {
    // Opt-in to the hidden-then-reveal state only once we know we can reveal it.
    doc.documentElement.classList.add('reveal-ready');
    var io = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-in');
            io.unobserve(entry.target);
          }
        });
      },
      { rootMargin: '0px 0px -8% 0px', threshold: 0.06 },
    );
    revealEls.forEach(function (el) { io.observe(el); });
  } else {
    revealEls.forEach(function (el) { el.classList.add('is-in'); });
  }
  // Safety net: anything still hidden after 2.5 s is forced visible.
  window.setTimeout(function () {
    $$('[data-reveal]:not(.is-in)').forEach(function (el) {
      var rect = el.getBoundingClientRect();
      if (rect.top < window.innerHeight * 1.6) el.classList.add('is-in');
    });
  }, 2500);

  /* --------------------------- active nav link -------------------------- */
  var sections = $$('main section[id]');
  var navPills = $$('.nav-pill');
  if ('IntersectionObserver' in window && sections.length && navPills.length) {
    var spy = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (!entry.isIntersecting) return;
          var id = entry.target.id;
          navPills.forEach(function (pill) {
            var match = pill.getAttribute('href') === '#' + id;
            pill.classList.toggle('is-active', match);
          });
        });
      },
      { rootMargin: '-45% 0px -50% 0px' },
    );
    sections.forEach(function (s) { spy.observe(s); });
  }

  /* ------------------------------ notices ------------------------------- */
  var noticeModal = $('#notice-modal');
  var noticeTitle = $('#notice-modal-title');
  var noticeBody = $('#notice-modal-body');
  var notices = (DATA.notices || []).slice();

  function findNotice(id) {
    for (var i = 0; i < notices.length; i++) if (String(notices[i].id) === String(id)) return notices[i];
    return null;
  }

  function niceDate(iso) {
    if (!iso) return '';
    var d = new Date(iso.length <= 10 ? iso + 'T00:00:00Z' : iso);
    if (isNaN(d.getTime())) return iso;
    return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric', timeZone: 'UTC' });
  }

  doc.addEventListener('click', function (e) {
    var trigger = e.target.closest && e.target.closest('[data-notice]');
    if (!trigger) return;
    var n = findNotice(trigger.getAttribute('data-notice'));
    if (!n) return;
    if (noticeTitle) noticeTitle.textContent = n.title;
    if (noticeBody) {
      noticeBody.replaceChildren();
      var dateEl = doc.createElement('div');
      dateEl.className = 'panel-note';
      dateEl.style.marginBottom = '9px';
      dateEl.textContent = niceDate(n.date);
      var text = doc.createElement('p');
      text.style.fontSize = '14px';
      text.style.color = '#4a3820';
      text.style.whiteSpace = 'pre-wrap';
      text.textContent = n.body || 'No further details were added to this notice.';
      noticeBody.appendChild(dateEl);
      noticeBody.appendChild(text);
    }
    openLayer(noticeModal);
  });

  /* ------------------------------- photos ------------------------------- */
  var photoModal = $('#photo-modal');
  var photoImg = $('#photo-modal-img');
  var photoTitle = $('#photo-modal-title');

  doc.addEventListener('click', function (e) {
    var tile = e.target.closest && e.target.closest('[data-photo]');
    if (!tile) return;
    var src = tile.getAttribute('data-photo');
    var caption = tile.getAttribute('data-caption') || 'Photo';
    if (photoImg) { photoImg.src = src; photoImg.alt = caption; }
    if (photoTitle) photoTitle.textContent = caption;
    openLayer(photoModal);
  });

  /* ------------------------------ classes ------------------------------- */
  doc.addEventListener('click', function (e) {
    var card = e.target.closest && e.target.closest('[data-class]');
    if (!card) return;
    var className = card.getAttribute('data-class');
    var select = $('#class_interested');
    if (select) {
      for (var i = 0; i < select.options.length; i++) {
        if (select.options[i].value === className) { select.selectedIndex = i; break; }
      }
    }
    var target = $('#admissions');
    if (target) target.scrollIntoView({ behavior: reduceMotion ? 'auto' : 'smooth', block: 'start' });
    var parentField = $('#parent_name');
    if (parentField) window.setTimeout(function () { parentField.focus({ preventScroll: true }); }, 520);
    showToast(className + ' selected — please fill the enquiry form', 'ok');
  });

  /* ----------------------------- stickman ------------------------------- */
  var stickman = $('#nk-stickman');
  var stickmanCaption = $('#stickman-caption');
  var stickmanWave = $('#sm-wave');
  var stickmanPoint = $('#sm-point');

  function stickmanMood(mood) {
    if (!stickman) return;
    stickman.classList.remove('is-happy', 'is-pointing', 'is-waving');
    if (mood === 'happy') stickman.classList.add('is-happy');
    else if (mood === 'point') stickman.classList.add('is-pointing');
    else stickman.classList.add('is-waving');
  }

  if (stickman) {
    stickmanMood('waving');
    var stage = stickman.closest('.stickman-stage');
    if (stage) {
      stage.addEventListener('pointerenter', function () { stickmanMood('point'); });
      stage.addEventListener('pointerdown', function () { stickmanMood('point'); });
    }
  }

  function confettiBurst() {
    if (reduceMotion) return;
    var host = stickman && stickman.closest('.stickman-stage');
    if (!host) return;
    var colors = ['#f2b01e', '#e04753', '#2b7fd4', '#2f9e57', '#ff8bb0', '#7b5cd6'];
    for (var i = 0; i < 26; i++) {
      var bit = doc.createElement('i');
      bit.className = 'nk-confetti';
      bit.style.left = 50 + (Math.random() * 40 - 20) + '%';
      bit.style.top = '52%';
      bit.style.background = colors[i % colors.length];
      bit.style.setProperty('--dx', (Math.random() * 180 - 90).toFixed(1) + 'px');
      bit.style.setProperty('--dy', (-90 - Math.random() * 110).toFixed(1) + 'px');
      bit.style.setProperty('--rot', (Math.random() * 720 - 360).toFixed(0) + 'deg');
      bit.style.animationDelay = (Math.random() * 0.16).toFixed(2) + 's';
      host.appendChild(bit);
      (function (node) {
        window.setTimeout(function () { if (node.parentNode) node.parentNode.removeChild(node); }, 1500);
      })(bit);
    }
  }

  /* -------------------------- enquiry form ------------------------------ */
  var form = $('#enquiry-form');
  var statusEl = $('#enquiry-status');
  var submitBtn = $('#enquiry-submit');

  function setStatus(message, kind) {
    if (!statusEl) return;
    statusEl.textContent = message || '';
    statusEl.className = 'form-status ' + (kind || '');
  }

  if (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!submitBtn) return;

      var payload = {
        parent_name: (form.parent_name.value || '').trim(),
        child_name: (form.child_name.value || '').trim(),
        phone: (form.phone.value || '').replace(/[^\d+]/g, ''),
        class_interested: form.class_interested.value || '',
        message: (form.message.value || '').trim(),
      };

      if (payload.parent_name.length < 2) return setStatus("Please enter the parent's name.", 'err');
      if (payload.child_name.length < 2) return setStatus("Please enter the child's name.", 'err');
      if (!/^[6-9]\d{9}$/.test(payload.phone)) return setStatus('Please enter a valid 10-digit mobile number.', 'err');
      if (!payload.class_interested) return setStatus('Please choose a class.', 'err');

      submitBtn.disabled = true;
      // Snapshot the original children (icon + caption) as clones so the button
      // can be restored with DOM nodes only — no innerHTML, Trusted Types safe.
      var originalNodes = Array.prototype.map.call(submitBtn.childNodes, function (node) {
        return node.cloneNode(true);
      });
      submitBtn.textContent = 'Sending…';
      setStatus('Sending your enquiry…');

      fetch('/api/enquiries', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })
        .then(function (res) { return res.json().then(function (body) { return { status: res.status, body: body }; }); })
        .then(function (out) {
          if (out.body && out.body.ok) {
            setStatus((out.body.data && out.body.data.message) || 'Thank you! We will contact you soon.', 'ok');
            stickmanMood('happy');
            confettiBurst();
            if (stickmanCaption) stickmanCaption.textContent = 'Yay! Enquiry received — happy dance!';
            form.reset();
            window.setTimeout(function () {
              stickmanMood('waving');
              if (stickmanCaption) stickmanCaption.textContent = 'Fill the form — I\'ll do a happy dance!';
            }, 5200);
          } else {
            setStatus((out.body && out.body.error) || 'Could not send right now. Please call us.', 'err');
            stickmanMood('point');
          }
        })
        .catch(function () {
          setStatus('Network problem — please check your connection or call us.', 'err');
        })
        .then(function () {
          submitBtn.disabled = false;
          submitBtn.replaceChildren.apply(
            submitBtn,
            originalNodes.map(function (node) { return node.cloneNode(true); }),
          );
        });
    });
  }

  /* ------------------------ marquee-free polish ------------------------- */
  // Keep the sticky header from shifting layout when it sticks.
  var header = $('.site-header');
  if (header && 'ResizeObserver' in window) {
    var ro = new ResizeObserver(function () {
      doc.documentElement.style.setProperty('--header-h', header.offsetHeight + 'px');
    });
    ro.observe(header);
  }

  doc.documentElement.classList.remove('no-js');

  // Last-resort guard against horizontal scroll on narrow screens.
  (function lockWidth() {
    function check() {
      var overflow = doc.documentElement.scrollWidth - doc.documentElement.clientWidth;
      if (overflow > 1) {
        var culprits = [];
        $$('body *').forEach(function (el) {
          var r = el.getBoundingClientRect();
          if (r.right > window.innerWidth + 1.5 || r.left < -1.5) {
            if (r.width > 0 && r.height > 0) culprits.push(el);
          }
        });
        if (culprits.length && window.console) {
          console.debug('[nk] elements wider than the viewport:', culprits.slice(0, 8));
        }
      }
    }
    if (doc.readyState === 'complete') check();
    else window.addEventListener('load', check, { once: true });
  })();

  window.NK = {
    toast: showToast,
    data: DATA,
    confetti: confettiBurst,
  };
})();
