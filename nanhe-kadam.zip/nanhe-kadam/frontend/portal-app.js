/* ==========================================================================
   Nanhe Kadam — portal dashboard client (GATED bundle)
   Served only to requests that present a valid HMAC-signed session cookie
   that resolves in D1 `sessions`. Unauthenticated requests are refused at the
   Worker edge (401 JSON for fetch, 302 to /portal for navigation) and never
   receive a single byte of this file.
   ========================================================================== */
(function () {
  'use strict';

  var doc = document;
  var reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  var BOOT = (function () {
    try {
      var el = doc.getElementById('__NK_PORTAL__');
      return el ? JSON.parse(el.textContent || '{}') : {};
    } catch (e) {
      return {};
    }
  })();

  var CSRF = BOOT.csrf || '';
  var IS_DASHBOARD = BOOT.page === 'dashboard';

  var MAX_UPLOAD = 3 * 1024 * 1024;
  var TARGET_W = 1920;
  var WEBP_QUALITY = 0.9;

  /* ------------------------------- helpers ------------------------------ */
  function $(sel, root) { return (root || doc).querySelector(sel); }
  function $$(sel, root) { return Array.prototype.slice.call((root || doc).querySelectorAll(sel)); }

  function showToast(message, kind) {
    var wrap = $('#toast-wrap');
    if (!wrap) return;
    var el = doc.createElement('div');
    el.className = 'toast ' + (kind || '');
    el.textContent = message;
    wrap.appendChild(el);
    requestAnimationFrame(function () { el.classList.add('show'); });
    window.setTimeout(function () {
      el.classList.remove('show');
      window.setTimeout(function () { if (el.parentNode) el.parentNode.removeChild(el); }, 400);
    }, 3800);
  }

  function api(path, payload) {
    return fetch(path, {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(Object.assign({}, payload || {}, { csrf: CSRF })),
    }).then(function (res) {
      return res.json().then(function (body) { return { status: res.status, body: body }; });
    });
  }

  function action(name, payload) { return api('/api/admin/' + name, payload); }

  /* --------------------------- bubble sweep ----------------------------- */
  var SWEEP =
    '.btn, .icon-btn, .side-link, .role-tab, .chip, .social-btn, .drawer-link,' +
    '.media-tile .del, .nav-pill, .btn-mini';

  doc.addEventListener('pointerdown', function (event) {
    var target = event.target;
    if (!target || !target.closest) return;
    var host = target.closest(SWEEP);
    if (!host || host.disabled) return;
    if (!reduceMotion) {
      var rect = host.getBoundingClientRect();
      var size = Math.max(rect.width, rect.height) * 1.15;
      var bubble = doc.createElement('span');
      bubble.className = 'nk-bubble';
      bubble.style.width = size + 'px';
      bubble.style.height = size + 'px';
      bubble.style.left = (event.clientX || rect.left + rect.width / 2) - rect.left + 'px';
      bubble.style.top = (event.clientY || rect.top + rect.height / 2) - rect.top + 'px';
      host.appendChild(bubble);
      bubble.addEventListener('animationend', function () {
        if (bubble.parentNode) bubble.parentNode.removeChild(bubble);
      });
      window.setTimeout(function () { if (bubble.parentNode) bubble.parentNode.removeChild(bubble); }, 800);
    }
    host.classList.add('is-press');
    window.setTimeout(function () { host.classList.remove('is-press'); }, 220);
  }, { passive: true });

  /* ==================================================================== *
   * IMAGE PIPELINE (3 MB HD → canvas → 1920px WebP q0.90)
   * ==================================================================== */
  function loadImage(file) {
    return new Promise(function (resolve, reject) {
      var url = URL.createObjectURL(file);
      var img = new Image();
      img.onload = function () { URL.revokeObjectURL(url); resolve(img); };
      img.onerror = function () { URL.revokeObjectURL(url); reject(new Error('Could not read that image file.')); };
      img.src = url;
    });
  }

  function renderToCanvas(img, maxEdge) {
    var w = img.naturalWidth || img.width;
    var h = img.naturalHeight || img.height;
    var scale = Math.min(1, maxEdge / Math.max(w, h));
    var tw = Math.max(1, Math.round(w * scale));
    var th = Math.max(1, Math.round(h * scale));
    var canvas = doc.createElement('canvas');
    canvas.width = tw;
    canvas.height = th;
    var ctx = canvas.getContext('2d');
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(img, 0, 0, tw, th);
    return canvas;
  }

  function approxBytes(dataUrl) {
    var idx = dataUrl.indexOf(',');
    return Math.floor(((dataUrl.length - idx - 1) * 3) / 4);
  }

  function prepareImage(file) {
    if (!/^image\//.test(file.type)) {
      return Promise.reject(new Error('Only image files are supported (JPG, PNG, WebP).'));
    }
    if (file.size > MAX_UPLOAD) {
      return Promise.reject(new Error('"' + file.name + '" is ' + (file.size / 1048576).toFixed(2) + ' MB — the maximum is 3 MB.'));
    }
    return loadImage(file).then(function (img) {
      var canvas = renderToCanvas(img, TARGET_W);
      var webp = canvas.toDataURL('image/webp', WEBP_QUALITY);
      if (webp.indexOf('data:image/webp') !== 0) {
        return { data: canvas.toDataURL('image/jpeg', 0.9), width: canvas.width, height: canvas.height };
      }
      var quality = WEBP_QUALITY;
      var data = webp;
      while (approxBytes(data) > MAX_UPLOAD && quality > 0.62) {
        quality -= 0.06;
        data = canvas.toDataURL('image/webp', quality);
      }
      return { data: data, width: canvas.width, height: canvas.height };
    });
  }

  function setProgress(key, percent) {
    var bar = $('[data-prog="' + key + '"]');
    if (!bar) return;
    bar.hidden = percent <= 0 || percent >= 100;
    var inner = bar.querySelector('i');
    if (inner) inner.style.width = Math.max(0, Math.min(100, percent)) + '%';
  }

  function uploadPhoto(file, options) {
    var opts = options || {};
    return prepareImage(file).then(function (prepared) {
      return api('/api/media', {
        data: prepared.data,
        label: opts.label || file.name.replace(/\.[^.]+$/, '').slice(0, 120),
        gallery_id: opts.galleryId || null,
        kind: opts.kind || 'gallery',
      }).then(function (out) {
        if (!out.body || !out.body.ok) throw new Error((out.body && out.body.error) || 'Upload failed');
        return out.body.data;
      });
    });
  }

  /* ==================================================================== *
   * 4. DASHBOARD
   * ==================================================================== */
  function initDashboard() {
    if (!IS_DASHBOARD) return;

    var views = $$('.portal-view');
    var links = $$('[data-view-link]');
    var titleEl = $('#view-title');
    var subEl = $('#view-sub');

    var viewTitles = {
      overview: 'Dashboard',
      school: 'School Identity',
      storage: 'Storage Pool',
      accounts: 'Co-Admins & Logins',
      teachers: 'Teachers',
      salary: 'Salary',
      attendance: 'Attendance',
      notices: 'Notice Board',
      classes: 'Classes',
      gallery: 'Gallery Sections',
      enquiries: 'Admission Enquiries',
      social: 'Social & Contact',
      profile: 'My Profile',
      account: 'Security',
    };

    function showView(key) {
      views.forEach(function (v) { v.hidden = v.getAttribute('data-view') !== key; });
      links.forEach(function (l) { l.classList.toggle('is-active', l.getAttribute('data-view-link') === key); });
      if (titleEl) titleEl.textContent = viewTitles[key] || 'Dashboard';
      if (subEl) {
        subEl.textContent =
          key === 'storage'
            ? '2,000 MB combined across 4 Cloudflare accounts'
            : key === 'gallery'
              ? 'Photos route automatically to the first vault with space'
              : BOOT.shell.schoolName;
      }
      if (window.innerWidth <= 920) closeSide();
      if (history.replaceState) history.replaceState(null, '', '#' + key);
    }

    links.forEach(function (link) {
      link.addEventListener('click', function () { showView(link.getAttribute('data-view-link')); });
    });

    var hash = (location.hash || '').replace('#', '');
    if (hash && viewTitles[hash]) showView(hash);

    /* --------------------------- side drawer --------------------------- */
    var side = $('#portal-side');
    var sideToggle = $('#side-toggle');
    var scrim = $('#scrim');

    function openSide() {
      if (side) side.classList.add('is-open');
      if (scrim) scrim.classList.add('is-open');
    }
    function closeSide() {
      if (side) side.classList.remove('is-open');
      if (scrim) scrim.classList.remove('is-open');
    }
    if (sideToggle) {
      sideToggle.style.display = 'inline-grid';
      sideToggle.addEventListener('click', openSide);
    }
    if (scrim) scrim.addEventListener('click', closeSide);

    /* ----------------------------- logout ------------------------------ */
    function logout() {
      api('/api/logout', {}).then(function () { window.location.href = '/portal'; }).catch(function () {
        window.location.href = '/portal';
      });
    }
    ['logout-btn', 'logout-btn-2'].forEach(function (id) {
      var btn = doc.getElementById(id);
      if (btn) btn.addEventListener('click', logout);
    });

    /* --------------------------- confirm modal ------------------------- */
    var confirmModal = $('#confirm-modal');
    var confirmText = $('#confirm-text');
    var confirmYes = $('#confirm-yes');
    var pendingConfirm = null;

    function askConfirm(message, onYes) {
      if (!confirmModal) { if (window.confirm(message)) onYes(); return; }
      if (confirmText) confirmText.textContent = message;
      pendingConfirm = onYes;
      confirmModal.classList.add('is-open');
      var sc = $('#scrim');
      if (sc) sc.classList.add('is-open');
    }
    if (confirmYes) {
      confirmYes.addEventListener('click', function () {
        var fn = pendingConfirm;
        pendingConfirm = null;
        confirmModal.classList.remove('is-open');
        var sc = $('#scrim');
        if (sc) sc.classList.remove('is-open');
        if (fn) fn();
      });
    }
    $$('[data-close]').forEach(function (el) {
      el.addEventListener('click', function () {
        if (confirmModal) confirmModal.classList.remove('is-open');
        var sc = $('#scrim');
        if (sc) sc.classList.remove('is-open');
      });
    });

    /* ------------------------- generic forms --------------------------- */
    function formStatus(formEl, message, kind) {
      var el = formEl.querySelector('[data-form-status]');
      if (!el) return;
      el.textContent = message || '';
      el.style.color = kind === 'err' ? '#b7232f' : kind === 'ok' ? '#1c7f42' : '#8b7659';
    }

    function formValues(formEl) {
      var out = {};
      $$('input, select, textarea', formEl).forEach(function (input) {
        if (!input.name) return;
        out[input.name] = input.type === 'checkbox' ? (input.checked ? 1 : 0) : input.value;
      });
      $$('[data-class-picker]', formEl).forEach(function (picker) {
        out.class_ids = $$('.chip.is-on', picker).map(function (c) {
          return Number(c.getAttribute('data-pick-class'));
        });
      });
      return out;
    }

    function reloadWithMessage(message) {
      try { sessionStorage.setItem('nk_flash', message); } catch (e) { /* ignore */ }
      window.location.reload();
    }

    try {
      var flash = sessionStorage.getItem('nk_flash');
      if (flash) {
        sessionStorage.removeItem('nk_flash');
        showToast(flash, 'ok');
      }
    } catch (e) { /* ignore */ }

    var FORM_ACTIONS = {
      settings: 'settings',
      'create-user': 'user.create',
      'create-teacher': 'teacher.create',
      assignment: 'assignment.create',
      salary: 'salary.create',
      attendance: 'attendance.create',
      notice: 'notice.create',
      'class-update': 'class.update',
      gallery: 'gallery.create',
      event: 'event.create',
      password: null, // handled separately
      vaults: null,   // handled separately
    };

    $$('form[data-form]').forEach(function (formEl) {
      formEl.addEventListener('submit', function (event) {
        event.preventDefault();
        var kind = formEl.getAttribute('data-form');
        var values = formValues(formEl);

        if (kind === 'password') {
          if ((values.new_password || '').length < 8) return formStatus(formEl, 'Use at least 8 characters.', 'err');
          if (values.new_password !== values.confirm_password) return formStatus(formEl, 'Passwords do not match.', 'err');
          formStatus(formEl, 'Updating…');
          api('/api/password', {
            current_password: values.current_password,
            new_password: values.new_password,
          }).then(function (out) {
            if (out.body && out.body.ok) {
              formStatus(formEl, 'Password updated ✓', 'ok');
              formEl.reset();
              showToast('Password updated', 'ok');
            } else {
              formStatus(formEl, (out.body && out.body.error) || 'Failed', 'err');
            }
          });
          return;
        }

        if (kind === 'vaults') {
          formStatus(formEl, 'Saving vault configuration…');
          action('vault.save', { vaults: values }).then(function (out) {
            if (out.body && out.body.ok) {
              formStatus(formEl, 'Saved ✓ re-checking connections…', 'ok');
              showToast('Vault configuration saved', 'ok');
              window.setTimeout(function () { window.location.reload(); }, 900);
            } else {
              formStatus(formEl, (out.body && out.body.error) || 'Failed', 'err');
            }
          });
          return;
        }

        var endpoint = FORM_ACTIONS[kind];
        if (!endpoint) return;
        formStatus(formEl, 'Saving…');
        action(endpoint, values).then(function (out) {
          if (out.body && out.body.ok) {
            formStatus(formEl, 'Saved ✓', 'ok');
            var data = out.body.data || {};
            var msg =
              kind === 'create-user' || kind === 'create-teacher'
                ? 'Login created — they must set a new password at first sign-in'
                : kind === 'notice'
                  ? 'Notice published'
                  : 'Saved';
            if (kind === 'notice' || kind === 'create-user' || kind === 'create-teacher' || kind === 'gallery' || kind === 'event' || kind === 'create-teacher') {
              reloadWithMessage(msg);
            } else {
              showToast(msg, 'ok');
              if (kind === 'class-update' || kind === 'settings') {
                window.setTimeout(function () { window.location.reload(); }, 700);
              }
            }
            if (kind === 'salary' || kind === 'attendance' || kind === 'assignment') {
              window.setTimeout(function () { window.location.reload(); }, 700);
            }
            void data;
          } else {
            formStatus(formEl, (out.body && out.body.error) || 'Failed to save', 'err');
          }
        }).catch(function () {
          formStatus(formEl, 'Network problem — please retry.', 'err');
        });
      });
    });

    /* --------------------------- class pickers ------------------------- */
    $$('[data-pick-class]').forEach(function (chip) {
      chip.addEventListener('click', function () { chip.classList.toggle('is-on'); });
    });

    /* -------------------------- class edit load ------------------------ */
    $$('[data-edit-class]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var formEl = $('form[data-form="class-update"]');
        if (!formEl) return;
        formEl.id.value = btn.getAttribute('data-edit-class');
        formEl.name.value = btn.getAttribute('data-name') || '';
        formEl.age_group.value = btn.getAttribute('data-age') || '';
        formEl.summary.value = btn.getAttribute('data-summary') || '';
        formEl.active.value = btn.getAttribute('data-active') || '1';
        showView('classes');
        formEl.name.focus({ preventScroll: true });
        formEl.scrollIntoView({ behavior: reduceMotion ? 'auto' : 'smooth', block: 'center' });
      });
    });

    /* --------------------------- delete actions ------------------------ */
    function bindDelete(selector, endpoint, key, messageFn) {
      $$(selector).forEach(function (btn) {
        btn.addEventListener('click', function () {
          var id = btn.getAttribute(selector.replace('[', '').replace(']', '').split('=')[0]);
          var name = btn.getAttribute('data-name') || '';
          askConfirm(messageFn(name), function () {
            showToast('Deleting…');
            action(endpoint, { id: Number(id) }).then(function (out) {
              if (out.body && out.body.ok) {
                reloadWithMessage('Deleted successfully');
              } else {
                showToast((out.body && out.body.error) || 'Delete failed', 'err');
              }
            });
          });
        });
      });
    }

    bindDelete('[data-delete-teacher]', 'teacher.delete', 'id', function (name) {
      return 'Delete ' + (name || 'this teacher') + '? This also removes their salary records, attendance, class assignments, uploaded photos and active sessions. This cannot be undone.';
    });
    bindDelete('[data-delete-user]', 'user.delete', 'id', function (name) {
      return 'Delete the login for ' + (name || 'this user') + '? They will be signed out immediately.';
    });
    bindDelete('[data-delete-notice]', 'notice.delete', 'id', function (name) {
      return 'Delete the notice “' + (name || '') + '”?';
    });
    bindDelete('[data-delete-salary]', 'salary.delete', 'id', function () { return 'Delete this salary record?'; });
    bindDelete('[data-delete-attendance]', 'attendance.delete', 'id', function () { return 'Delete this attendance record?'; });
    bindDelete('[data-delete-enquiry]', 'enquiry.delete', 'id', function (name) {
      return 'Delete the enquiry from ' + (name || 'this parent') + '?';
    });
    bindDelete('[data-delete-assignment]', 'assignment.delete', 'id', function () { return 'Remove this class assignment?'; });
    bindDelete('[data-delete-event]', 'event.delete', 'id', function (name) { return 'Delete the event “' + (name || '') + '”?'; });

    $$('[data-delete-media]').forEach(function (btn) {
      btn.addEventListener('click', function (event) {
        event.stopPropagation();
        var mediaId = btn.getAttribute('data-delete-media');
        askConfirm('Delete this photo? Its chunks are removed from the storage vault it lives on.', function () {
          fetch('/api/media/' + encodeURIComponent(mediaId), {
            method: 'DELETE',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ csrf: CSRF }),
          })
            .then(function (res) { return res.json(); })
            .then(function (body) {
              if (body && body.ok) reloadWithMessage('Photo deleted');
              else showToast((body && body.error) || 'Delete failed', 'err');
            })
            .catch(function () { showToast('Network problem', 'err'); });
        });
      });
    });

    $$('[data-toggle-notice]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        action('notice.toggle', {
          id: Number(btn.getAttribute('data-toggle-notice')),
          field: btn.getAttribute('data-field'),
          value: Number(btn.getAttribute('data-value')),
        }).then(function (out) {
          if (out.body && out.body.ok) reloadWithMessage('Notice updated');
          else showToast((out.body && out.body.error) || 'Failed', 'err');
        });
      });
    });

    $$('[data-reset-user]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var id = btn.getAttribute('data-reset-user');
        var name = btn.getAttribute('data-name');
        askConfirm('Reset the password for ' + name + '? A temporary password will be generated and shown once.', function () {
          action('user.reset', { id: Number(id) }).then(function (out) {
            if (out.body && out.body.ok) {
              var pw = out.body.data && out.body.data.temporary_password;
              askConfirm('Temporary password for ' + name + ':  ' + pw + '\n\nShare it with them — they must change it at next sign-in.', function () {
                reloadWithMessage('Password reset');
              });
            } else {
              showToast((out.body && out.body.error) || 'Reset failed', 'err');
            }
          });
        });
      });
    });

    $$('[data-assign-teacher]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var formEl = $('form[data-form="assignment"]');
        if (!formEl) return;
        formEl.teacher_id.value = btn.getAttribute('data-assign-teacher');
        showView('teachers');
        formEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
      });
    });

    /* ---------------------------- media drops -------------------------- */
    $$('input[data-file]').forEach(function (input) {
      var kind = input.getAttribute('data-file');
      var galleryId = input.getAttribute('data-gallery');
      var drop = input.closest('.drop');
      var key = kind === 'gallery' ? 'gallery-' + galleryId : kind;

      if (drop) {
        ['dragenter', 'dragover'].forEach(function (evt) {
          drop.addEventListener(evt, function (e) {
            e.preventDefault();
            drop.classList.add('is-over');
          });
        });
        ['dragleave', 'drop'].forEach(function (evt) {
          drop.addEventListener(evt, function (e) {
            e.preventDefault();
            drop.classList.remove('is-over');
          });
        });
        drop.addEventListener('drop', function (e) {
          var files = e.dataTransfer && e.dataTransfer.files;
          if (files && files.length) handleFiles(Array.prototype.slice.call(files), kind, galleryId, key);
        });
      }

      input.addEventListener('change', function () {
        var files = Array.prototype.slice.call(input.files || []);
        if (files.length) handleFiles(files, kind, galleryId, key);
        input.value = '';
      });
    });

    function handleFiles(files, kind, galleryId, key) {
      var queue = files.slice();
      var done = 0;
      var failed = [];
      var statusEl = galleryId ? $('[data-upload-status="' + galleryId + '"]') : null;

      function next() {
        if (!queue.length) {
          setProgress(key, 0);
          if (done) reloadWithMessage(done + ' photo' + (done > 1 ? 's' : '') + ' uploaded');
          if (failed.length) showToast(failed[0], 'err');
          return;
        }
        var file = queue.shift();
        var basePercent = (done / files.length) * 100;
        setProgress(key, Math.max(4, basePercent));
        if (statusEl) statusEl.textContent = 'Compressing ' + file.name + ' → Full HD WebP…';

        uploadPhoto(file, { kind: kind === 'gallery' ? 'gallery' : kind, galleryId: Number(galleryId) || null })
          .then(function (res) {
            done += 1;
            setProgress(key, ((done / files.length) * 100) | 0);
            if (statusEl) {
              statusEl.textContent =
                'Uploaded to Shard ' + res.shard + ' · ' + (res.bytes / 1024).toFixed(0) + ' KB in ' + res.chunks + ' chunk(s)';
            }
            next();
          })
          .catch(function (err) {
            failed.push(err && err.message ? err.message : 'Upload failed');
            setProgress(key, ((done + 1) / files.length) * 100);
            next();
          });
      }
      next();
    }

    $$('[data-reset-media]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var key = btn.getAttribute('data-reset-media');
        var formEl = $('form[data-form="settings"]');
        if (!formEl) return;
        formStatus(formEl, 'Resetting…');
        action('settings', { [(key === 'logo' ? 'logo_media_id' : key === 'hero' ? 'hero_media_id' : 'about_media_id')]: '' }).then(function (out) {
          if (out.body && out.body.ok) reloadWithMessage('Reverted to bundled artwork');
          else formStatus(formEl, (out.body && out.body.error) || 'Failed', 'err');
        });
      });
    });

    /* --------------------------- storage tools ------------------------- */
    var refresh = $('[data-action="refresh-pool"]');
    if (refresh) {
      refresh.addEventListener('click', function () {
        showToast('Re-checking vaults…');
        window.location.reload();
      });
    }

    var testBtn = $('[data-action="test-vaults"]');
    if (testBtn) {
      testBtn.addEventListener('click', function () {
        var formEl = $('form[data-form="vaults"]');
        showToast('Testing vault connections…');
        action('vault.test', { vaults: formEl ? formValues(formEl) : {} }).then(function (out) {
          if (out.body && out.body.ok) {
            var results = (out.body.data && out.body.data.results) || [];
            var okCount = results.filter(function (r) { return r.ok; }).length;
            showToast(okCount + ' of 3 vaults reachable', okCount ? 'ok' : 'err');
            results.forEach(function (r) { showToast('Vault ' + r.vault + ': ' + r.message, r.ok ? 'ok' : 'err'); });
          } else {
            showToast((out.body && out.body.error) || 'Test failed', 'err');
          }
        });
      });
    }

    showView((location.hash || '#overview').replace('#', '') || 'overview');
  }


  /* ------------------------------- boot -------------------------------- */
  initDashboard();
})();
