# Nanhe Kadam Public School — full-stack website + portal

A production-ready, zero-lag school website and multi-role portal that runs **entirely on
Cloudflare Workers + D1** (no R2, no paid storage, no billing risk), pooling **4 free
Cloudflare accounts into 2,000 MB** of media storage for **3 MB HD photo uploads**.

| | |
|---|---|
| **School** | Nanhe Kadam Public School — Chorawa Icha, near Sudha Factory, Bihar |
| **Classes** | Play Class → Class 5 (9 classes) |
| **Opened** | 11 November 2026 (opening-day photos are pre-seeded) |
| **Primary Worker** | `nanhe-kadam` → `https://nanhe-kadam.empathy-life-jelly.workers.dev` |
| **Primary D1** | `nanhe-kadam-db` (`40010739-626b-4441-87bd-ffcf2331c67a`) |
| **Super Admin** | `Rakesh@1` / `rakesh@7632` (forced password change on first sign-in) |

---

## 1. Quick start

```bash
npm install
npm run dev          # http://localhost:8787 — real worker code, in-memory D1 seeded
npm run typecheck    # tsc, zero errors
npm test             # 92 tests, real SQL against SQLite
npm run embed        # inline CSS/JS/images into frontend/embedded.ts
bash deploy.sh       # deploy account 1
```

The local dev server runs the **actual Worker entry point** against an in-memory SQLite
database seeded from `migrations/0001_reset.sql`, so local and production behave the same.

`deploy.sh` is safe to run on the live `40010739-626b-4441-87bd-ffcf2331c67a` database:
`0001_reset.sql` turns `PRAGMA foreign_keys` off, drops every table with
`DROP TABLE IF EXISTS` (children first), turns enforcement back on and re-seeds. No
"table already exists", no FK failures, no stale chunks — and the same script re-seeds
the 9 classes, the Super Admin and the opening-ceremony gallery on every run.

---

## 2. The 4-account, 2,000 MB D1 storage pool

```
Account 1 (this Worker)   Shard 1   500 MB D1   school tables + first media shard
Account 2 (vault-worker)  Shard 2   500 MB D1   remote Storage Vault
Account 3 (vault-worker)  Shard 3   500 MB D1   remote Storage Vault
Account 4 (vault-worker)  Shard 4   500 MB D1   remote Storage Vault
                                   ─────────
                                    2,000 MB free
```

### How a 3 MB photo is stored

1. **Browser** (`frontend/portal.js`) draws the file onto a `<canvas>` at
   **maxWidth 1920 px**, encodes **`image/webp` at quality 0.90** → typically
   250–850 KB, so faces and event details stay razor-sharp. If a highly detailed
   frame is still above 3 MB the quality steps down until it fits.
2. **Upload** posts the data URL to `POST /api/media` (3 MB hard ceiling, MIME
   allow-list, CSRF + same-origin + session checks).
3. **Routing**: the Worker picks the first shard below its **430 MB soft ceiling**
   (70 MB headroom inside the free 500 MB tier) — Shard 1 → 2 → 3 → 4.
4. **Chunking**: payloads are split into **512 KB raw chunks**. Base64 of 512 KB is
   **683 KB**, i.e. under the 700 KB chunk budget and comfortably under **D1's
   1 MB per-row limit** — `SQLITE_TOOBIG` can never occur. Verified by unit tests and
   by an end-to-end 3 MB upload test.
5. **Location** is recorded in `media_index (id, shard_id, storage_key, mime,
   size_bytes, chunk_count, …)`.
6. **Reads**: `GET /api/media/:id` transparently streams from the owning shard
   (`Cache-Control: public, max-age=3600`, ETag, `nosniff`).
7. **Deletes / replaces** remove every chunk on the owning shard first, then the
   index row — zero orphaned space.

### Super Admin → Storage Pool

Live meter showing `Used MB / 2,000 MB across 4 Cloudflare Accounts`, a per-account
usage bar, photo counts, connection state, and fields to paste each Vault Worker URL
and secret with a **Test all connections** button.

---

## 3. Connecting your other three free accounts

```bash
cd vault-worker
npx wrangler login                # log in with Gmail account #2
bash deploy-vault.sh 2            # creates D1, applies schema, sets secret, deploys

npx wrangler login                # account #3
bash deploy-vault.sh 3

npx wrangler login                # account #4
bash deploy-vault.sh 4
```

Each run prints the Worker URL and secret. Paste them into
**Portal → Storage Pool → Vault 2/3/4**, save, then hit **Test all connections**.
Until they are configured the pool simply stays on Shard 1 — nothing breaks.

---

## 4. Security model

| Control | Implementation |
|---|---|
| Password hashing | PBKDF2-SHA256, **exactly 100,000 iterations** (Cloudflare's hard cap). Never 210,000 — that returns a 500. |
| Session | `nk_sess` cookie — `HttpOnly; Secure; SameSite=Strict`, HMAC-SHA256 signed, backed by the D1 `sessions` table, 12 h expiry, rotated on password change. |
| Portal gating | `/portal/dashboard`, `/portal-app.js` and `/dashboard.css` resolve the session **server-side**; unauthenticated → `302 /portal` (or `401` for a script/CSS fetch), never a byte of dashboard HTML, JS or CSS. |
| CSRF | Stateless `<exp>.<nonce>.<hmac>` tokens bound to the session id, 2 h TTL, required on every mutating request (419 on failure). |
| Same-origin | `Origin`/`Referer` check on all POST/DELETE admin routes. |
| Brute force | D1 fixed-window rate limits: 8 attempts / 10 min per username, 20 per IP; 5 enquiries / 10 min per IP; duplicates suppressed for 10 min. |
| SQL | 100 % parameterised `db.prepare(...).bind(...)`. Column names in dynamic SQL come from allow-lists only. |
| XSS | Every interpolated value passes `escapeHtml`; inline JSON is escaped for `</script>`; strict CSP with a per-response nonce. |
| Headers | Every route (HTML, JS, CSS, images, JSON, 404): CSP **without** `unsafe-inline`/`unsafe-eval` and with a per-response nonce on documents, `X-Frame-Options: DENY`, `nosniff`, `Referrer-Policy: no-referrer`, `Permissions-Policy`, HSTS, `frame-ancestors 'none'`, `Cross-Origin-Opener-Policy`, Trusted Types (`require-trusted-types-for 'script'`). |
| No leaks | CSS and JS are split into public / sign-in / dashboard bundles, minified with esbuild, comments stripped, `sourcemap: false`, mangled identifiers on the gated bundle. Client code never uses `innerHTML` (Trusted Types safe). |
| Error hygiene | 404/403/500 render one generic page; `scrubError()` rewrites any 5xx text mentioning SQLite, D1, bindings or stack frames before it can reach a client. |
| Shard secrets | `VAULT_2/3/4_SECRET` are compared as SHA-256 digests in constant time (`timingSafeEqual`, byte-loop fallback); a bad secret gets a uniform `404 Not found`, not a hint. |
| Isolation | `/`, `/public.js`, `/style.css`, `/portal` contain zero admin/dashboard/role/schema markup — asserted byte-for-byte by `tests/security-audit.test.ts`. |
| Audit | Every privileged action lands in `audit_log` with user, target, IP and timestamp. |

> Rotate secrets before going live:
> `printf '%s' "$(openssl rand -base64 32)" | npx wrangler secret put SESSION_SECRET`
> (same for `CSRF_SECRET`).

---

## 5. Roles

**Super Admin** — school identity & map & images, 4-account storage pool, Co-Admin and
Teacher logins, teachers/salary/attendance, notices, 9 classes, 3 gallery sections,
events, enquiries, social toggles, own password.

**Co-Admin** — everything content-related (identity, map, notices, classes, gallery
uploads, enquiries, teachers, salary, attendance). **Blocked** in UI *and* API from
creating/editing/deleting Super Admin or Co-Admin accounts, and from the storage pool.

**Teacher** — own profile, assigned classes (Play Class → Class 5), salary history,
class notices, gallery uploads (3 MB HD). Teacher HTML never contains staff or
account markup.

Deleting a teacher is **atomic and cascading**: teacher + `teacher_salaries` +
`teacher_attendance` + `teacher_assignments` + their `media` (index rows *and* shard
chunks) + `sessions` in one `db.batch`, with salary aggregates updating immediately.

---

## 6. Interaction design (120 FPS)

* **3D tactile controls** — glossy top-to-bottom gradient, `inset 0 2px 3px rgba(255,255,255,.55)`
  top highlight, `0 5px 0 <darker>` bevel lip plus a soft ambient shadow, on every
  button, nav pill, social toggle, role tab, class card and action control.
* **Hover** lifts `translate3d(0,-2px,0)` inside `@media (hover:hover)`.
* **Press** compresses into the bevel: `translate3d(0,3px,0) scale3d(.975,.975,1)`
  and springs back on `cubic-bezier(.22,1,.36,1)`.
* **Bubble sweep** — a delegated `pointerdown` listener (passive) spawns
  `<span class="nk-bubble">` at the exact `(clientX, clientY)`, expanding
  `scale3d(0,0,1) → scale3d(2.6,2.6,1)` with opacity `0.55 → 0` over 520 ms, plus a
  diagonal light sheen. **Only `transform` and `opacity` animate** — never width,
  height, top/left, margin or box-shadow keyframes — with `will-change` and
  `pointer-events:none` on the bubble layer.
* **Scroll reveal** — `IntersectionObserver` adds `reveal-ready` to `<html>` first, so
  content is *never* hidden when JS is slow or unavailable; plus a 2.5 s safety net.
* **Margin lock** — `overflow-x:hidden`, `width/max-width:100%`, `overscroll-behavior-x:none`,
  `touch-action:pan-y`, universal `box-sizing`, and `min-width:0` on layout containers.
  Verified at 390 px: `scrollWidth === clientWidth`.
* **Mascots** — the bunny's eyes track the cursor while typing a username, both paws
  cover its eyes when the password field is focused, one paw peeks when "show
  password" is tapped, it bounces on success and head-shakes on failure. The stickman
  waves, points at the form on hover, then jumps and throws confetti when a parent
  submits an enquiry.

---

## 7. Opening ceremony photos (11 Nov 2026)

The three real photographs you supplied were restored with a non-generative pipeline
(`/home/user/tools/enhance2.py`): letterbox bars cropped, LAB-domain local tone mapping
to open dim interiors, highlight roll-off on window glare, grey-world white balance,
vibrance and detail sharpening. No face was warped or regenerated, so every person stays
exactly who they are.

| File | Source | Result |
|---|---|---|
| `public/opening1.jpg` | puja ceremony | 1106 × 1600 · 156 KB |
| `public/opening2.jpg` | Director, Principal & guests | 1700 × 833 · 160 KB |
| `public/opening3.jpg` | full stage group photo | 1400 × 1045 · 285 KB |

They are seeded as **Shard 0** assets (`static:opening1.jpg` …) in the gallery section
**“Grand Opening – 11 Nov 2026”** and in the `events` table with `date = '2026-11-11'`,
so they appear live the moment you deploy — and remain fully replaceable/deletable in
**Portal → Gallery Sections**.

---

## 8. Verification

```
npm run embed        → 5 minified assets, no sourcemaps
npm run typecheck    → clean (Worker build + dev build)
npm test             → 92 passed (4 files)
```

Coverage highlights: PBKDF2 iteration cap and the seeded Super Admin hash, session
signing/tamper rejection, CSRF binding and expiry, HTML/JSON escaping, 3 MB chunk
sizing and byte-perfect reassembly, zero-orphan deletes, pool capacity maths, SSR
content, “Mera” absence, public/portal isolation, portal redirects for forged cookies,
role-mismatch rejection, Co-Admin RBAC on both HTML and API, enquiry validation and
storage, media streaming, and the 413 for oversize uploads.

`tests/security-audit.test.ts` is a dedicated leak audit. It reads the real bytes of
every public route and fails the build if a response ever contains an admin path,
dashboard markup, SQL/table name, shard or vault identifier, sourcemap reference or
developer comment — and it asserts the gated assets (`/portal-app.js`,
`/dashboard.css`, `/portal/dashboard`) return **302/401 with an empty body** unless the
signed session cookie also validates against the D1 `sessions` table.

---

## 9. Project layout

```
backend/src/
  index.ts              router + static/asset serving
  env.ts, platform.d.ts minimal Worker typings
  lib/  crypto.ts db.ts media.ts auth.ts http.ts data.ts util.ts
  routes/  auth.ts public.ts admin.ts media.ts
  views/  public.ts login.ts dashboard.ts icons.ts mascots.ts
frontend/
  style.css             public design system only
  portal.css            sign-in page styles (bunny, login card)
  dashboard.css         app-shell styles — served only to a signed-in session
  public.js             bubble sweep, reveals, drawers, enquiry + confetti
  portal.js             sign-in bundle: bunny + login/password forms only
  portal-app.js         dashboard bundle: uploads + every /api/admin call
  embedded.ts           generated by scripts/embed.mjs
migrations/
  0001_reset.sql        schema + Super Admin + 9 classes + 3 notices + opening seed
  0002_media_seed.sql   idempotent opening-gallery verification
vault-worker/
  index.ts              Storage Vault Worker (deploy to accounts 2/3/4)
  schema.sql, wrangler.toml, deploy-vault.sh
scripts/  embed.mjs assets.mjs dev-server.mjs hash-password.mjs
tests/    d1-shim.ts env.ts auth.test.ts media-chunking.test.ts routes.test.ts
          security-audit.test.ts
public/   logo, hero (signed “Nanhe Kadam / PUBLIC SCHOOL”), about, class1–class9, opening1–3
```

Generate a new password hash at any time:

```bash
node scripts/hash-password.mjs "YourNewPassword"   # always 100,000 iterations
```
