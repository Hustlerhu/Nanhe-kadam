#!/usr/bin/env bash
# ===========================================================================
#  Nanhe Kadam Public School — Primary Worker deployment (Account 1)
#
#    bash deploy.sh
#
#  What it does:
#    1. checks Node + wrangler
#    2. embeds CSS/JS/images into frontend/embedded.ts
#    3. typechecks and runs the test suite
#    4. applies D1 migrations (schema + opening-ceremony seed)
#    5. deploys the Worker to https://nanhe-kadam.empathy-life-jelly.workers.dev
#
#  PBKDF2 note: every password hash uses EXACTLY 100,000 iterations because
#  Cloudflare Workers rejects higher counts with a 500 error.
# ===========================================================================
set -euo pipefail

BLUE='\033[0;34m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
say()  { printf "${BLUE}▸${NC} %s\n" "$1"; }
ok()   { printf "${GREEN}✓${NC} %s\n" "$1"; }
warn() { printf "${YELLOW}!${NC} %s\n" "$1"; }
die()  { printf "${RED}✗${NC} %s\n" "$1"; exit 1; }

cd "$(dirname "$0")"

DB_NAME="nanhe-kadam-db"
WORKER_NAME="nanhe-kadam"
BASE_URL="https://nanhe-kadam.empathy-life-jelly.workers.dev"

printf "\n${GREEN}Nanhe Kadam Public School — deploy${NC}\n"
printf "worker : %s\nd1     : %s\nurl    : %s\n\n" "$WORKER_NAME" "$DB_NAME" "$BASE_URL"

command -v node >/dev/null 2>&1 || die "Node.js 18+ is required"
say "Node $(node --version)"

if [ ! -d node_modules ]; then
  say "Installing dependencies…"
  npm install --no-audit --no-fund
fi

command -v npx >/dev/null 2>&1 || die "npx is required (npm i -g npm)"

say "Embedding CSS, JS and bundled imagery…"
npm run embed

say "Typechecking…"
npm run typecheck || die "typecheck failed"
ok "types clean"

say "Running tests…"
npm test --silent || die "tests failed"
ok "tests passed"

say "Checking the D1 database exists…"
if ! npx wrangler d1 info "$DB_NAME" >/dev/null 2>&1; then
  warn "D1 '$DB_NAME' not found — creating it now"
  npx wrangler d1 create "$DB_NAME" || die "could not create the D1 database"
  warn "A new database was created. Copy its database_id into wrangler.toml, then re-run."
  exit 1
fi
ok "database present"

# ---------------------------------------------------------------------------
#  Teardown note
#  migrations/0001_reset.sql starts with PRAGMA foreign_keys = OFF followed by
#  DROP TABLE IF EXISTS … for every table (children first). That makes this
#  script safe to run on a live database with existing rows: no FK errors, no
#  "table already exists", and no stale media chunks left behind.
# ---------------------------------------------------------------------------
say "Applying D1 schema (migrations/0001_reset.sql — FK-safe teardown + reseed)…"
npx wrangler d1 execute "$DB_NAME" --remote --file=migrations/0001_reset.sql -y
ok "schema + seed applied (tables reset cleanly)"

say "Verifying opening-ceremony gallery (migrations/0002_media_seed.sql)…"
npx wrangler d1 execute "$DB_NAME" --remote --file=migrations/0002_media_seed.sql -y
ok "Grand Opening – 11 Nov 2026 photos in place"

say "Setting Worker secrets…"
# These are also declared in wrangler.toml [vars] as bootstrap defaults so the
# very first deploy works. Rotating them here is the production-hardened path.
if [ -n "${SESSION_SECRET:-}" ]; then
  printf '%s' "$SESSION_SECRET" | npx wrangler secret put SESSION_SECRET
  ok "SESSION_SECRET updated from environment"
else
  warn "SESSION_SECRET not set in the environment — using the wrangler.toml bootstrap value"
fi
if [ -n "${CSRF_SECRET:-}" ]; then
  printf '%s' "$CSRF_SECRET" | npx wrangler secret put CSRF_SECRET
  ok "CSRF_SECRET updated from environment"
else
  warn "CSRF_SECRET not set in the environment — using the wrangler.toml bootstrap value"
fi

say "Deploying Worker…"
npx wrangler deploy
ok "deployed"

say "Smoke-testing the deployment…"
for p in "/" "/style.css" "/public.js" "/portal"; do
  code="$(curl -s -o /dev/null -w '%{http_code}' "${BASE_URL}${p}" || echo 000)"
  if [ "$code" = "200" ]; then printf "   %-14s 200\n" "$p"; else warn "$p returned $code"; fi
done
dash_code="$(curl -s -o /dev/null -w '%{http_code}' "${BASE_URL}/portal/dashboard" || echo 000)"
if [ "$dash_code" = "302" ] || [ "$dash_code" = "401" ]; then
  printf "   /portal/dashboard %s (correctly gated)\n" "$dash_code"
else
  warn "/portal/dashboard returned $dash_code — expected 302/401!"
fi
app_code="$(curl -s -o /dev/null -w '%{http_code}' "${BASE_URL}/portal-app.js" || echo 000)"
if [ "$app_code" = "302" ] || [ "$app_code" = "401" ]; then
  printf "   /portal-app.js    %s (dashboard bundle gated)\n" "$app_code"
else
  warn "/portal-app.js returned $app_code — expected 302/401!"
fi

printf "\n${GREEN}Done.${NC}\n"
printf "  Website  : %s\n" "$BASE_URL"
printf "  Portal   : %s/portal\n" "$BASE_URL"
printf "  Super Admin login: Rakesh@1  (you must set a new password on first sign-in)\n\n"
printf "Next (optional, for 2,000 MB total storage):\n"
printf "  1. cd vault-worker && npx wrangler login      (2nd Gmail account)\n"
printf "  2. bash deploy-vault.sh                       (deploys Vault 2)\n"
printf "  3. Paste the printed URL + secret into Portal → Storage Pool\n\n"
